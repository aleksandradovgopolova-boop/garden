# Garden Chronicle — From a social garden to narrow bridges

**Дата:** 16 июля 2026  
**Тип:** turning point  
**Связано:** R-008, R-010, R-012, R-014

## What we thought

Garden might become a shared space where close people see practices, support progress and grow together.

## What caused doubt

Research showed:

- support must match the actual need;
- accountability can become control;
- sharing completion can expand into surveillance;
- peer spaces produce belonging and co-rumination;
- comparison affects people differently;
- community requires real moderation;
- partners and helpers need their own boundaries;
- relationship status does not create valid consent.

## How the understanding changed

Garden should not build a social network around inner life.

It can create:

- a prepared request;
- one-time narrow sharing;
- a trusted-person role;
- later, a carefully bounded shared practice.

Private reflection remains private.

## Unresolved

- whether Trusted Person belongs in Alpha;
- whether S1 prepared requests are enough;
- how to support mutual practices after conflict;
- whether a small moderated circle is strategically important;
- how crisis contact should work;
- how shared-data deletion works after separation;
- whether AI should facilitate any relational dialogue.

## Consequences

- Social Architecture Model created;
- proposed GDR-014 created;
- community moved outside Alpha;
- no social comparison;
- coercive-control red-team becomes mandatory;
- human bridge is clarified as user-controlled preparation, not automatic disclosure.
