# Garden Chronicle — Безопасность раньше памяти

**Дата:** 15 июля 2026  
**Тип:** foundational boundary  
**Связано:** R-010, R-011, R-012, GDR-012

## Что мы думали

Чем больше Garden помнит, тем лучше понимает человека. Приватность можно будет закрыть шифрованием, настройками и политикой перед запуском.

## Что вызвало сомнение

Аудит показал:

- свободный текст почти неизбежно содержит чувствительные данные;
- AI создаёт новые inferred data, которых пользователь не вводил;
- logs, embeddings and summaries образуют скрытые копии истории;
- provider, employee and connector access расширяют контур риска;
- prompt injection превращает внешний текст в путь к данным и действиям;
- deletion одной строки в UI не удаляет derived stores;
- кризисная функция опасна, если продукт обещает больше, чем способен обеспечить;
- согласие не исправляет манипулятивную или небезопасную механику.

## Как изменилось понимание

Безопасность Garden определяется не количеством мер защиты вокруг уже придуманной функции.

Она определяется способностью сказать:

> Эти данные нам не нужны. Этот вывод мы не будем делать. Эту память не сохраним. Эту функцию пока не запустим.

## Решения, предложенные после R-012

- DPIA до real-data pilot;
- 18+ Alpha;
- no clinical claims;
- no passive crisis monitoring;
- no production-data training;
- no raw-content analytics;
- no default employee browsing;
- deletion graph including embeddings and summaries;
- privacy zones and strict provider gate;
- independent security, privacy and crisis review;
- GDR-012.

## Что пока не решено

- local-first vs secure cloud architecture;
- конкретный LLM provider;
- EU hosting and transfer strategy;
- exact retention periods;
- staffed human escalation;
- regulatory classification;
- future support for minors;
- cost and team required for the safety program.

## Последствие для Alpha

Alpha не начинается с максимальной персонализации. Она начинается с минимального потока данных, no-memory/no-tracking options и доказуемого удаления.
