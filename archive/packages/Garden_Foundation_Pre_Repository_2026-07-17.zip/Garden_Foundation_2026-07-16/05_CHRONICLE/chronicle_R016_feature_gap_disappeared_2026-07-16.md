# Garden Chronicle — The feature gap disappeared

**Дата:** 16 июля 2026  
**Тип:** market turning point  
**Связано:** R-006–R-016

## What we thought

Garden could stand out by combining:

- AI journaling;
- rituals;
- patterns;
- gentle reminders;
- a visual garden;
- long-term memory.

## What the market showed

Every part already exists:

- AI journals offer long-term memory, patterns and voice;
- habit apps offer rituals and self-care;
- trackers offer experiments and correlations;
- companions offer emotional continuity;
- meditation platforms add AI;
- second brains offer connected personal knowledge.

## How understanding changed

Garden cannot be a unique bundle of familiar features.

Its distinction must be behavioral:

- what the product refuses to do;
- how it handles uncertainty;
- how it treats misses;
- how it forgets;
- how it returns responsibility;
- how it distinguishes coping from source change;
- whether it lets the user leave.

## What remains unresolved

- whether restraint is visible enough to buy;
- category language;
- willingness to pay;
- acquisition;
- whether users want flexible practices;
- whether Garden is a company or a product philosophy;
- whether general-purpose AI is sufficient.

## Consequences

- the complete ecosystem is not Alpha;
- the wedge becomes one direction → one practice → one review;
- GDR-016 proposed;
- product-market validation becomes mandatory before foundation expansion;
- R-017 will complete the philosophical cycle.
