# Garden Chronicle — Сад перестал быть объяснением человека

**Дата:** 15 июля 2026  
**Тип:** turning point  
**Связано:** R-003, R-006, R-013, GDR-013

## Что мы думали

Сад может стать целостной моделью жизни: практики — растения, контекст — почва, развитие — рост, завершение — сезон.

## Что вызвало сомнение

Исследование показало:

- metaphors highlight and hide;
- one image can empower one person and burden another;
- growth can become obligation;
- bloom can become status;
- weeds can become rejection of feelings and people;
- natural language can hide human-made injustice;
- AI gardener can become authority over the person;
- actual nature evidence does not transfer to garden metaphor.

## Как изменилось понимание

Garden remains a name, atmosphere and optional lens.

It is not:

- psychology;
- diagnosis;
- total ontology;
- progress score;
- theory of good life.

Literal language becomes a first-class product layer.

## Что пока не решено

- retain external term `AI Gardener` or not;
- how rich the default metaphor should be;
- whether users need immersive visualization;
- how the Russian and English versions differ;
- whether practices should still be represented as plants;
- how to visualize completion without decay;
- whether Mycorrhiza belongs in Alpha.

## Последствия

- Layered Metaphor Model created;
- proposed GDR-013 created;
- visual system requires audit;
- Alpha must work with nature visuals disabled;
- R-015 will test structural-problem individualization.
