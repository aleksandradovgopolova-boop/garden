# Garden Chronicle — Relief stopped pretending to be a solution

**Дата:** 16 июля 2026  
**Тип:** turning point  
**Связано:** R-001, R-008, R-012, R-015

## What we thought

Garden helps a person find a small caring action in almost any difficult situation.

## What caused doubt

Research showed:

- the action available to the user is not always the action required to solve the problem;
- individual interventions are easier to build and measure;
- this creates lifestyle drift;
- resource inequality changes what advice is feasible;
- workplace stress may be produced by workload, control and management;
- self-care can help someone survive while allowing the harmful system to remain untouched;
- structural language can also erase agency if used carelessly.

## How the understanding changed

Garden now separates:

- relief;
- protection;
- preparation;
- adaptation;
- source-directed change;
- exit.

A small caring action remains important. It no longer receives credit for solving what it cannot solve.

## Unresolved

- how much structural mapping belongs in everyday UX;
- how to maintain local resources;
- how Garden handles legal uncertainty;
- whether collective action belongs in product scope;
- how to avoid political or ideological overreach;
- how B2B use can ever be safe;
- how to recognize abuse without harmful certainty.

## Consequences

- Multilevel Action Model created;
- GDR-015 proposed;
- every recurring distress flow needs a source check;
- employer resilience use becomes a no-go for Alpha;
- R-016 must evaluate competitors for structural blind spots.
