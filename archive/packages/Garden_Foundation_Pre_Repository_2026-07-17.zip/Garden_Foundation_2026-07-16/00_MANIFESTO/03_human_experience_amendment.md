# Garden Canon — Human Experience Amendment

**Дата:** 16 июля 2026  
**Статус:** `accepted amendment`

## 1. Human-centered product principle

Garden is not a compliance exercise built from research.

Research is a form of care used by humans who want to create a better experience for other humans.

Scientific precision and emotional beauty are not opponents.

Garden must preserve both:

- intellectual honesty;
- warmth, play, imagination and delight.

## 2. Ritual as user language

The user-facing core object is `Ritual`.

A ritual may be:

- one-time;
- recurring;
- seasonal;
- symbolic;
- practical;
- resting;
- completed.

Internally, engineering may use `Practice` as a parent schema. This technical abstraction must not flatten the emotional meaning of the ritual.

## 3. Garden as core world

The visual garden is part of the core product proposition.

It is not:

- a hidden score;
- a compliance dashboard;
- a punishment system;
- an AI-owned model of the person.

It is:

- a creative sandbox;
- a visual memory;
- a personal world;
- a source of calm and play;
- a representation controlled by its owner.

## 4. Ownership invariant

The person controls:

- placement;
- form;
- naming;
- decoration;
- transformation;
- archiving;
- deletion;
- empty space.

No object decays because the user did not return.

## 5. Research purpose

Research must answer:

> How can this experience become more humane, useful, beautiful and safe?

It must not automatically answer:

> How can we reduce the experience to the least risky functional interface?
