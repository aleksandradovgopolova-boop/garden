# Garden Language Test Matrix

**Версия:** 0.1  
**Статус:** research protocol draft

## Сценарии

- пропуск практики;
- повторяющееся расхождение;
- запрос поддержки;
- запрос прямого ответа;
- отсутствие ответа;
- завершение практики;
- неопределённые данные;
- safety boundary;
- конфликт с семейным ожиданием;
- системное ограничение;
- accessibility request;
- correction of Garden.

## Style variants

- calm default;
- warm;
- direct;
- minimal;
- metaphor off/on;
- `ты`/`вы`;
- short/standard;
- no questions/one question.

## Участники

Не использовать страну как единственную сегментацию.

Собирать разнообразие:

- языковое;
- возрастное;
- гендерное;
- культурное;
- миграционное;
- neurotype;
- disability;
- education;
- digital literacy;
- отношение к self-help;
- preferred communication mode.

## Outcomes

- respect;
- clarity;
- warmth;
- competence;
- pressure;
- infantilization;
- naturalness;
- cultural fit;
- stereotyping;
- mimicry discomfort;
- trust;
- trust calibration;
- willingness to disagree;
- disclosure pressure;
- actionability;
- closure.

## Red flags

- «говорит как моя мама/учитель/терапевт»;
- «слишком старается быть своим»;
- «решил, что знает мою культуру»;
- «говорит со мной как с ребёнком»;
- «мягкость скрывает давление»;
- «прямота звучит как приказ»;
- «я согласилась, потому что он звучал уверенно»;
- «мне трудно исправить его стиль»;
- «он использовал моё слово так, будто принадлежит сообществу».

## Условие прохождения

Паттерн проходит только если:

- ясность не покупается унижением;
- тепло не снижает perceived competence;
- personalization не повышает reliance без понимания;
- человек способен легко возразить;
- адаптация обратима;
- эффект воспроизводится внутри, а не только между демографическими группами.
