# Garden Material Token Architecture v0.1

**Статус:** `implementation proposal`

```yaml
material:
  wood:
    base_colour:
    grain_scale:
    roughness:
    specular:
    edge_softness:
    sound:
    motion:
    ageing_options:
    contrast_floor:
  stone:
  soil:
  water:
  vegetation:
  ceramic:
  fabric:
  metal:
  paper:
  glass:

quality_level:
  low:
    texture:
    reflection:
    motion:
  medium:
  high:

accessibility:
  material_labels:
  reduced_texture:
  static_motion:
  contrast_boundary:
  sound_off:
```

## Rules

- material state does not map to ritual lifecycle;
- ageing is always explicit and reversible;
- no automatic dirt, cracks, rust or fading;
- texture is never the only differentiator;
- low-quality rendering preserves object identity;
- UI materials remain separate from world materials.
