# Garden World Architecture v1

**Дата:** 16 июля 2026  
**Статус:** `working architecture`

## Core hierarchy

```text
Garden
├── Terrain
├── Places
│   ├── Rituals
│   ├── Objects
│   ├── Memories
│   └── Ambient Settings
├── Paths
├── Archive
├── World History
└── World Settings
```

## Garden invariants

- Garden belongs to one user.
- AI cannot own or control it.
- Absence never harms the garden.
- Visual state is not a wellbeing score.
- The user may reset visuals without deleting rituals.
- The user may export, archive and delete.

## Terrain

Alpha uses one compact terrain:

- clearing;
- light grove;
- meadow edge;
- pond-side;
- hill-and-path.

Terrain is aesthetic, not psychological.

## Places

A place may:

- have a name or remain unnamed;
- exist without a ritual;
- contain several rituals;
- stay empty;
- be transformed or archived.

No place receives an automatic psychological meaning.

## Paths

Paths connect places, but do not define progress.

A dead end, loop or decorative path is valid.

## Garden objects

Types:

- plant;
- tree;
- stone;
- bench;
- lantern;
- water element;
- bridge;
- path detail;
- small structure;
- decoration;
- archive relic;
- ambient-life marker.

Rules:

- no decay after absence;
- free movement and deletion;
- AI changes nothing without confirmation;
- rarity never equals value;
- object type never encodes mental state.

## Ritual and object separation

A ritual exists independently of its object.

Allowed:

- one ritual → one object;
- one ritual → several objects;
- one place → several rituals;
- object without ritual;
- ritual without object in literal mode.

Completing a ritual does not require deleting its object.

## Creation models to test

### Ritual-first

Important direction → ritual → visual object → place.

### Place-first

Place → personal meaning → ritual or object.

Alpha must test both before choosing the dominant model.

## Ritual lifecycle in the world

- seeded;
- active;
- adapting;
- resting;
- integrated;
- completed;
- released;
- archived.

There is no failed state.

Visual transformation is always user-chosen.

## World history

Save:

- creation;
- movement;
- renaming;
- chosen transformation;
- archive;
- restoration.

Do not save:

- inferred mood;
- AI explanations of motives;
- hidden psychological profile.

## Ambient world

### Light

Static, user-selected or optionally real-time.

### Weather

User-selected, gently random or optional local weather.

Never inferred from mood or ritual completion.

### Sound

Explicitly enabled, independently controlled, no sudden cues.

### Animals

Independent ambient life:

- no feeding;
- no suffering;
- no quests;
- no AI persona;
- no emotional debt.

## Empty states

> «Сад может начинаться с одного места. Или с пустоты».

> «Здесь пока ничего нет. Это тоже часть сада».

> «Сад может жить без активных ритуалов».

## Accessibility

- literal labels;
- keyboard alternative;
- list view;
- high contrast;
- reduced motion;
- sound controls;
- screen-reader descriptions;
- zoom;
- simplified terrain.

## Alpha scope

Build:

- one garden;
- one terrain;
- up to three places;
- up to three rituals;
- 8–12 object templates;
- free placement;
- basic archive;
- one ambient setting;
- snapshot;
- reset.

Delay:

- multiple gardens;
- multiplayer;
- economy;
- crafting;
- social visits;
- seasonal FOMO;
- procedural generation.

## Final invariant

> Every world mechanic must increase ownership, meaning, beauty or freedom. If it mainly increases return frequency, it does not belong in Garden.
