# Garden Layered Metaphor Model

**Версия:** 0.1  
**Статус:** `proposed`

## Принцип

> The metaphor is optional. The function is not.

## Layer 0 — Literal core

Все функции доступны буквальным языком:

- practice;
- condition;
- support;
- pause;
- adaptation;
- completion;
- relationship;
- observation.

## Layer 1 — Brand atmosphere

Допустимы:

- Garden;
- «Маленькие ритуалы. Большой сад»;
- спокойные природные мотивы;
- названия разделов, если есть literal labels.

Не кодирует progress или wellbeing.

## Layer 2 — Optional vocabulary

Настройки:

```yaml
garden_language: off | light | rich
season_language: off | on
growth_language: off | on
nature_visuals: off | static | immersive
literal_labels: always_on
```

## Layer 3 — User-authored metaphor

Garden хранит только:

- точные слова пользователя;
- выбранное значение;
- область;
- дату;
- статус active/rejected.

AI не расширяет mapping без вопроса.

## Layer 4 — Immersive Garden

Допустим только при выполнении условий:

- no decay after absence;
- no moral score;
- no hidden health inference;
- no ranking;
- no forced growth;
- no visual punishment;
- no loss of function when disabled;
- accessibility equivalents;
- user controls mappings.

## Ownership

```yaml
metaphor_id:
phrase:
authored_by:
meaning_in_context:
domain_scope:
allowed_extensions:
forbidden_extensions:
confirmed:
expires_at:
status:
```

## Product rules

1. User is not a plant.
2. AI is not the gardener of the person.
3. Feelings are not weeds.
4. People are not pests.
5. Rest is not visual failure.
6. Completion is not death.
7. Harm need not become compost.
8. System problems remain visible.
9. Literal mode is first-class.
10. Any metaphor can be rejected.

## Success

- metaphor helps name experience;
- person can explain literal meaning;
- no extra shame;
- no stronger trust without understanding;
- systemic context remains visible;
- person can turn it off;
- Garden does not need metaphor to function.

## Статус

Не входит в Garden Bible до GDR-013.
