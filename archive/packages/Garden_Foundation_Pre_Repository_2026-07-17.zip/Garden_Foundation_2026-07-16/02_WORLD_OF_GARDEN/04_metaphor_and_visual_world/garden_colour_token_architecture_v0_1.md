# Garden Colour Token Architecture v0.1

**Статус:** `implementation proposal`

## System separation

```yaml
ui:
  background:
  surface:
  surface_elevated:
  text_primary:
  text_secondary:
  border:
  focus:
  selected:
  destructive:
  disabled:

world:
  sky:
  atmospheric_light:
  terrain_primary:
  terrain_secondary:
  vegetation_dark:
  vegetation_mid:
  vegetation_light:
  water_deep:
  water_surface:
  stone:
  wood:
  metal:
  fabric:

accent:
  primary:
  secondary:
  warm:
  cool:

semantic:
  focus:
    color:
    outline:
    icon:
  selected:
    color:
    outline:
    handle:
  error:
    color:
    icon:
    label:
```

## Rules

- semantic status never depends on hue alone;
- all interactive tokens tested across world palettes;
- user-selected world accent cannot break UI contrast;
- high-contrast mode has equal design status;
- destructive colour remains secondary to copy and position;
- archive uses context and labels, not automatic desaturation.
