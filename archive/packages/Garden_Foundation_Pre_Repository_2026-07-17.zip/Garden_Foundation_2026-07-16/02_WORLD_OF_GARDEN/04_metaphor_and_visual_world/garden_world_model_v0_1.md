# Garden World Model v0.1

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Hierarchy

```text
Garden
├── Terrain
├── Places
│   ├── Rituals
│   ├── Objects
│   ├── Memories
│   └── Ambient rules
├── Paths
├── Archive
└── World settings
```

## Garden

The persistent user-owned world.

## Place

A named or unnamed area with:

```yaml
place_id:
name:
terrain_type:
boundaries:
user_meaning:
rituals:
objects:
memories:
ambient_settings:
created_by:
created_at:
```

## Object

```yaml
object_id:
type:
appearance:
position:
rotation:
scale:
user_meaning:
ritual_link:
memory_link:
state:
```

## Ritual link

A ritual can:

- live in one place;
- move;
- be represented by multiple objects only if user chooses;
- detach from object;
- complete while object remains.

## Ambient life

Ambient elements:

- do not need care;
- do not report user state;
- do not block actions;
- do not carry hidden scores.

## World state

Only user-authored or explicit aesthetic state.

No inferred mood state.

## Creation models to test

### Ritual-first

Ritual → object → place.

### Place-first

Place → meaning → ritual/object.

### Free sandbox

Place/object first, ritual optional.

## Alpha recommendation

Test ritual-first and place-first.

Do not build full free sandbox before comprehension testing.
