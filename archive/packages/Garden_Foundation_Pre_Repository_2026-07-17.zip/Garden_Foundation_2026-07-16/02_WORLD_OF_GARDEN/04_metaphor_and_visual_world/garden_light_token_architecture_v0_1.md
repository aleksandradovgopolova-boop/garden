# Garden Light Token Architecture v0.1

**Статус:** `implementation proposal`

```yaml
scene:
  dawn:
    ambient_intensity:
    key_intensity:
    key_angle:
    colour_temperature:
    shadow_softness:
  daylight:
  overcast:
  dusk:
  night:

material_response:
  foliage:
    subsurface:
    specular:
  water:
    reflection:
    transparency:
  stone:
    roughness:
  wood:
    roughness:
    warmth:
  glass:
    transmission:

ui:
  day_surface:
  night_surface:
  overlay:
  text:
  border:
  focus:

motion:
  enabled:
  speed:
  amplitude:
  transition_duration:

accessibility:
  static_scene:
  reduced_motion:
  max_glare:
  high_contrast:
```

## Rules

- scene tokens never map to ritual lifecycle;
- UI contrast is validated independently;
- reduced motion removes dynamic light patterns;
- user can override local-time mode;
- local light placement cannot hide essential controls.
