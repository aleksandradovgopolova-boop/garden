# Garden Ambient Creature Architecture v0.1

```yaml
ambient_creature:
  creature_id: string
  species_type: bird | fish | insect | amphibian | fictional
  fictional_or_real: fictional | real
  habitat:
  activity_period:
  motion_profile:
  sound_profile:
  recurrence_probability:
  persistent_identity: false
  direct_gaze: false
  reacts_to_user: false
  care_required: false
  hunger: false
  illness: false
  death: false
  absence_effect: none
  collectible: false
  rarity_tier: null
  monetized: false
  ai_role: none
  controls:
    visible:
    sound:
    motion:
    density:
```

## Rules

- no state depends on ritual completion;
- no persistent identity in Alpha;
- no missed sightings or notifications;
- no suffering;
- no personality profiling;
- no AI messages through animals.
