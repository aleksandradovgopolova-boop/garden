# Garden Metaphor Safety Matrix

**Версия:** 0.1  
**Статус:** working standard

| Image | Potential value | Main risk | Default |
|---|---|---|---|
| Garden as space | Coexistence, attention, context | Total-life ontology | Allowed lightly |
| Seed | Beginning, possibility | Small must become large | Optional |
| Soil | Conditions and resources | Naturalizes structural inequality | Allowed for practice context |
| Water/light | Resources | Simplifies complex needs | Optional |
| Growth | Change | Endless improvement imperative | Off by default in evaluation |
| Bloom | Visibility, expression | Beauty/productivity score | Brand art only, no status |
| Fruit/harvest | Outcome | Worth equals usefulness | Avoid as progress metric |
| Season | Change, limited resource | Determinism and passive waiting | User-controlled |
| Dormancy | Invisible process, rest | Romanticizes depression/distress | Conditional |
| Roots | History, belonging | Essentialism and family obligation | User-authored |
| Transplanting | Context change | Life as simple relocation | User-authored |
| Pruning | Limits, focus | Violence, relationship simplification | Restricted |
| Weeds | Unwanted competition | Rejection of feelings/people | Prohibited for inner states/people |
| Pests | External threat | Dehumanization | Prohibited for people |
| Disease | Need for intervention | Medicalization/diagnosis | Prohibited as wellbeing status |
| Decay | Natural change | Punishment and mortality cue | No absence feedback |
| Compost | Transformation | Forced post-traumatic growth | User-authored only |
| Mycorrhiza | Interdependence | False science/altruism narrative | Explicitly metaphorical |
| Gardener | Care and agency | Control hierarchy | User only, conditional |
| AI gardener | Guidance | Ownership/dependency | Internal name, not relational claim |

## Required test

For every use:

- literal translation;
- rejected-use response;
- cultural review;
- accessibility review;
- systemic-context check;
- medical-claim check;
- moral-score check;
- AI-authority check.
