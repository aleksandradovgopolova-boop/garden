# Garden Temporal Architecture v0.1

**Статус:** `implementation proposal`

```yaml
garden_time:
  mode: timeless | manual | local_year | slow_year | fictional_cycle
  timezone: iana_timezone | null
  season_model: four_season | wet_dry | local | fictional | none
  calendar_visibility: hidden | relative | month_year | exact | epoch
  frozen: boolean
  ambient_progression: boolean
  last_user_override_at: datetime | null

epoch:
  epoch_id: uuid
  name: string
  start_event_id: uuid
  end_event_id: uuid | null
  description: string | null
  user_created: boolean
  ai_suggested: boolean
  exact_dates_visible: boolean

ritual_time:
  cadence:
  reminder:
  review:
  automatic_lifecycle_transition: false

absence_policy:
  decay: false
  backlog: false
  missed_state: false
  permanent_ambient_changes: false
  guilt_copy: false
```

## Rules

- exact timestamps remain in audit history;
- epoch grouping never deletes raw chronology;
- AI cannot create an epoch without confirmation;
- no object changes because of inactivity;
- freeze applies to atmosphere, not audit time;
- reminders respect timezone and quiet hours.
