# Garden Sound Architecture v0.1

**Статус:** `implementation proposal`

```yaml
soundscape:
  master:
    enabled: boolean
    volume: number
  ambience:
    air:
    foliage:
    water:
    weather:
    animals:
    distant_world:
    density: silent | minimal | living | custom
  music:
    enabled: boolean
    track_id: string | null
    volume: number
  interaction:
    enabled: boolean
    material_feedback: boolean
    navigation_feedback: boolean
  accessibility:
    speech_enabled: boolean
    earcons_enabled: boolean
    ducking: boolean
    mono: boolean
  comfort:
    normalized_loudness: boolean
    dynamic_range: low | standard
    reduced_density: boolean
```

## Rules

- no sound depends on ritual completion;
- no distress sounds;
- no essential audio-only information;
- speech ducks decorative audio;
- review mode defaults to music off;
- safety mode disables decorative layers;
- microphone is not used.
