# PRV-001 — Private by Default

Garden begins private. Sharing is explicit, bounded and revocable.
