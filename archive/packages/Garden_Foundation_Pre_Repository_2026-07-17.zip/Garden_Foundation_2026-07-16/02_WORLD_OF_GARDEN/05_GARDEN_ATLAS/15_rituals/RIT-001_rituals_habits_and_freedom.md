# Atlas RIT-001 — Rituals, Habits and Freedom

**ID:** RIT-001  
**Раздел:** Rituals  
**Статус:** `design principles`

## Distinctions

- task;
- habit;
- routine;
- ritual.

## Alpha boundaries

- no streak;
- no failed occurrence;
- no quality score;
- no required logging;
- no automatic lifecycle;
- no AI-created ritual without confirmation;
- no frequency morality.

## Alpha capabilities

- retrospective creation;
- holistic components;
- optional occurrence;
- optional reflection;
- lineage;
- rest;
- transform;
- preserve;
- archive;
- end.

## Core principle

A ritual may exist outside Garden and without being recorded.
