# Atlas M-001 — Material Language

**ID:** M-001  
**Раздел:** Materials  
**Статус:** `design principles`

## Core dimensions

- roughness;
- gloss;
- softness;
- hardness;
- transparency;
- weight;
- movement;
- temperature association;
- age;
- sound;
- contextual expectation.

## Candidate material families

### Primary

- soil;
- wood;
- stone;
- water;
- vegetation.

### Secondary

- ceramic;
- fabric;
- metal;
- paper;
- glass.

## Accepted candidates

- materially legible stylisation;
- behaviour before microdetail;
- user-authored patina;
- no decay after absence;
- progressive fidelity;
- material labels for accessibility.

## Open

- exact rendering style;
- material palette families;
- whether users can mix all materials freely;
- repair mechanics;
- environmental footprint measurement.
