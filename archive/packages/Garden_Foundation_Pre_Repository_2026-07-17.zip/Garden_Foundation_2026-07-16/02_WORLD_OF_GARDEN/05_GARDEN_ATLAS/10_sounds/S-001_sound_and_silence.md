# Atlas S-001 — Sound and Silence

**ID:** S-001  
**Раздел:** Sounds  
**Статус:** `design principles`

## Layers

- ambient soundscape;
- music;
- interaction sounds;
- accessibility audio.

## Alpha modes

- Silent;
- Minimal;
- Living;
- Custom.

## Accepted candidates

- sound off remains complete;
- independent layer controls;
- no obvious short loops;
- no music by default in review;
- no animal calls for attention;
- material interaction sounds;
- assistive speech priority;
- no microphone analysis.

## Open

- default density;
- whether optional music belongs in Alpha;
- spatial audio after Alpha;
- user-imported sound;
- safe procedural sound generation.
