# ONB-001 — First Place

The first proof of value is leaving and returning to a preserved place.
