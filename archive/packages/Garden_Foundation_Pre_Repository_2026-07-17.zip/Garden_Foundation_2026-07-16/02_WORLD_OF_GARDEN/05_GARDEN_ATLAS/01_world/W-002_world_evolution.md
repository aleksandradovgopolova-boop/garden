# Atlas W-002 — World Evolution

## Change classes

- perceptual;
- ambient;
- reversible configuration;
- user-authored persistent;
- history;
- system-authored persistent.

## Alpha modes

- Stable;
- Living;
- Curated;
- Manual;
- Frozen.

## Boundaries

- no autonomous growth;
- no decay;
- no absence effects;
- no silent redesign;
- persistent change requires authorship;
- snapshots, variants and change log.
