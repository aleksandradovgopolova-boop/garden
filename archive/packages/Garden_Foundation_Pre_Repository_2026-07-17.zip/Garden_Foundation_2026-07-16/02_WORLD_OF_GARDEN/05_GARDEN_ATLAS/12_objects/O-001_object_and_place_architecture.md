# Atlas O-001 — Object and Place Architecture

**ID:** O-001  
**Раздел:** Objects / Architecture  
**Статус:** design principles

## Семейства

- rest;
- passage;
- orientation;
- gathering;
- containment;
- observation;
- memory;
- atmosphere.

## Уровни взаимодействия

- L0 visual;
- L1 inspect;
- L2 link;
- L3 configure;
- L4 spatial action.

## Решения-кандидаты

- place как главная единица композиции;
- user-authored meaning;
- разделение object/ritual lifecycle;
- ограниченные стабильные landmarks;
- отсутствие универсальной символики;
- не каждый объект интерактивен;
- отсутствие object economy в Alpha.
