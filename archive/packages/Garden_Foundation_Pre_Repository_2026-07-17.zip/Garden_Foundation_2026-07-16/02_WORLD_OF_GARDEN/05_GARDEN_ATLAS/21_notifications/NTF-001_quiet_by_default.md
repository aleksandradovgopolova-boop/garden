# NTF-001 — Quiet by Default

No guilt, re-engagement pressure or anthropomorphic reminders.
