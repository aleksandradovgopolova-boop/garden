# Atlas A-001 — Ambient Living Beings

**Статус:** design principles

## Alpha accepts

- ambient wildlife;
- limited recurring visitor experiments.

## Alpha excludes

- digital pets;
- care;
- hunger;
- death;
- speaking animals;
- collection economy;
- rarity;
- AI animal persona.

## Candidate creatures

- fictional small bird;
- fish;
- butterfly or moth;
- frog.

## Controls

- on/off;
- density;
- sound;
- motion;
- insects separately.

> Life may exist without belonging to the user.
