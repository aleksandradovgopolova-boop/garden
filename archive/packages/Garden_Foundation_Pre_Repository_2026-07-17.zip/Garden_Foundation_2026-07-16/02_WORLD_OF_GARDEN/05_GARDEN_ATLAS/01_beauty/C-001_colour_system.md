# Atlas C-001 — Colour System

**ID:** C-001  
**Раздел:** Beauty / Light  
**Статус:** `design principles`

## Dimensions

- hue;
- lightness;
- chroma;
- contrast;
- surround;
- material;
- illumination;
- object context.

## Accepted candidates

- no moral colour coding;
- palette families;
- user-selected intensity;
- equal-status light and dark worlds;
- accessible high-contrast theme;
- semantic tokens separated between UI and world;
- colour plus shape/label/icon.

## Open

- canonical default palette;
- number of palette families;
- whether world palette may vary by place;
- relationship between light engine and palette;
- safe monetization of cosmetics.
