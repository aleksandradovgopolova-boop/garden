# Atlas B-001 — Beauty of Place

**ID:** B-001  
**Раздел:** Beauty  
**Статус:** `design hypothesis set`  
**Последнее обновление:** 16 июля 2026

## Core model

A place may feel beautiful when it balances:

- coherence;
- complexity;
- legibility;
- mystery;
- familiarity;
- personal authorship;
- sensory congruence.

## Garden decision candidates

- asymmetrical balance;
- coherent but incomplete starting garden;
- complexity grows mainly through user choices;
- mystery without FOMO;
- no universal cultural aesthetic claims;
- ownership measured separately from first-impression beauty.

## Open questions

- How much empty space feels inviting?
- Which styles feel childish or adult?
- How much motion creates life without distraction?
- Does authorship compensate for lower polish?
