# Atlas L-001 — Light System

**ID:** L-001  
**Раздел:** Light  
**Статус:** `design principles`

## Functions

- spatial depth;
- material readability;
- atmosphere;
- time;
- focus;
- accessibility.

## Accepted candidates

- separate world/UI light;
- user-selectable scenes;
- optional local-time mode;
- full night usability;
- static and reduced-motion modes;
- user-owned local lights;
- no moral state mapping.

## Open

- default scene;
- scene-transition duration;
- HDR support;
- fictional vs local-time cycle;
- number of local lights in Alpha.
