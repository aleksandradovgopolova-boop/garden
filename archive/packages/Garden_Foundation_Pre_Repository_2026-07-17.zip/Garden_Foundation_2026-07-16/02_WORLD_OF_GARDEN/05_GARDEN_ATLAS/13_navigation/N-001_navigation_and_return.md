# Atlas N-001 — Navigation and Return

**ID:** N-001  
**Раздел:** Navigation  
**Статус:** `design principles`

## Modes

- spatial;
- direct;
- list-only;
- reduced-motion.

## Alpha capabilities

- quiet overview;
- place list;
- schematic map;
- global search;
- recent;
- user favorites;
- deep links;
- breadcrumbs;
- clear View/Edit modes.

## Boundaries

- no forced travel;
- no fog of war;
- no completion map;
- no automatic favorite inference;
- no guilt on return;
- every spatial destination has direct access;
- accessibility is equal-status.
