# Atlas P-005 — Formal Garden: Axis, Power and Spectacle

**Статус:** evidence + critical design reference

## Core

Formal gardens use geometry, axes, water, sculpture and controlled views to demonstrate order and often power.

## Garden may learn

- coherent composition;
- spatial rooms;
- strong sightlines;
- integration of landscape and architecture.

## Garden rejects

- one correct order;
- user as guest in designer-owned world;
- hierarchy as human value;
- beauty as obedience.
