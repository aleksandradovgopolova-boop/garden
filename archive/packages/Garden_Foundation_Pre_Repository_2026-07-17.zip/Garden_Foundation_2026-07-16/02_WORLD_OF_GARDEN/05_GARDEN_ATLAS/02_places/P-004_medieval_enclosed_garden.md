# Atlas P-004 — Medieval Enclosed Garden: Shelter and Use

**Статус:** evidence + design implications

## Core

- enclosed courtyards provided protected open-air space;
- gardens combined rest, practical plants, symbolism and institutional life;
- reconstructions remain partly interpretive.

## Garden may learn

- small protected scale;
- rest places;
- practical and beautiful together;
- interior courtyard as one place type.

## Garden must not copy

- monastic discipline;
- religious symbolism without context;
- enclosure as digital isolation.
