# Atlas P-002 — Chinese Scholar Garden: Movement and Named Views

**Статус:** evidence + design implications

## Core

- gardens can operate as miniature landscapes;
- rocks, water, paths, pavilions, painting, poetry and calligraphy form one cultural system;
- views unfold through movement;
- places may have names and inscriptions.

## Garden may learn

- place-first architecture;
- named viewpoints;
- partial revelation;
- integration of text and space;
- world understood over time.

## Garden must not copy

- scholar-garden symbols as neutral decoration;
- Daoist/Confucian meanings without context;
- exoticized rocks, roofs or calligraphy.
