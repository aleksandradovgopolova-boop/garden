# Atlas P-008 — Domestic Garden: Everyday Care and Memory

**Статус:** open research seed

## Core

Everyday gardens may combine utility, family memory, food, improvisation, cultural continuity and modest beauty.

## Garden may learn

- small scale;
- ordinary objects;
- mixed utility and beauty;
- imperfect authorship;
- personal history over prestige.

## Open

More research is needed beyond elite and canonical garden histories.
