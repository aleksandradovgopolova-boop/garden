# Atlas P-003 — Japanese Garden Traditions: Path, Frame and Season

**Статус:** evidence + design implications

## Core

Japanese garden traditions are plural. Temple rock gardens, tea gardens, stroll gardens and seasonal viewing spaces serve different purposes.

## Garden may learn

- threshold before focused activity;
- emptiness;
- framing;
- sequence;
- temporary display;
- seasonality without score.

## Garden must not copy

- “Zen” as generic minimalism;
- rock garden as universal calm symbol;
- tea ritual stripped of discipline and history;
- Japanese aesthetics as default humane design.
