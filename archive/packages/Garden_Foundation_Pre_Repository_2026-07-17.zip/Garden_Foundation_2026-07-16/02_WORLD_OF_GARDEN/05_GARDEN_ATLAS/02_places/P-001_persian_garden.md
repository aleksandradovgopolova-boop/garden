# Atlas P-001 — Persian Garden: Water, Order and Enclosure

**Статус:** evidence + design implications

## Core

- four-part organization appears prominently across Persian-garden history;
- water serves irrigation, ornament, sound and spatial order;
- the garden can function as an image of a protected ideal world;
- the tradition adapted across climates and historical periods.

## Garden may learn

- water as infrastructure and atmosphere;
- coherent whole;
- protected interior;
- paths and channels as spatial grammar.

## Garden must not copy

- Paradise symbolism without context;
- mandatory four-part layout;
- religious cosmology as generic wellness;
- Persian identity as decorative theme.
