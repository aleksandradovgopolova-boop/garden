# Atlas P-007 — Public Garden: Access and Belonging

**Статус:** open research seed

## Core questions

- Who may enter?
- Who feels watched?
- Who sets rules?
- Can a person stay without spending?
- Can people be present without performing?

## Garden implication

Future social spaces require access, moderation, privacy and the right to remain peripheral.
