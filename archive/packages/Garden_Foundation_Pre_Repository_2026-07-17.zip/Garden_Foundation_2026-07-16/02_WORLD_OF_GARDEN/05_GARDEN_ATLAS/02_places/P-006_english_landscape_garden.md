# Atlas P-006 — English Landscape Garden: Constructed Naturalness

**Статус:** evidence + critical design reference

## Core

Apparently natural views were created through extensive design and land transformation.

## Garden may learn

- asymmetrical balance;
- soft boundaries;
- sequence of views;
- hidden technical infrastructure.

## Garden rejects

- pretending design is neutral nature;
- hiding power and constraints;
- presenting elite landscape as universal comfort.
