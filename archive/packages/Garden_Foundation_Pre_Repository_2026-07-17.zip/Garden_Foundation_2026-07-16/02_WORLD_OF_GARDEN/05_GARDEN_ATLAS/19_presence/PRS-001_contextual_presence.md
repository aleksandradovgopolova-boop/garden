# PRS-001 — Contextual Presence

People may be present in specific places, rituals or memories. No social graph.
