# ALP-001 — Alpha Constitution

Alpha tests authorship, continuity and voluntary return.
