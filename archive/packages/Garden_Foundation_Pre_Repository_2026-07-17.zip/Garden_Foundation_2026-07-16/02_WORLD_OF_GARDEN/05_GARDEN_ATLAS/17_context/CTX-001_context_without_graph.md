# Atlas CTX-001 — Context Without a Graph

**ID:** CTX-001  
**Раздел:** Context  
**Статус:** `design principles`

## Garden relation model

Allowed:

- located in;
- contains;
- used in;
- remembered with;
- derived from;
- version of;
- belongs to lineage.

Prohibited in Alpha:

- arbitrary semantic edges;
- backlinks;
- graph view;
- clusters;
- automatic related content;
- inferred themes;
- custom relation ontology.

## Product boundary

Garden holds situated experience.

«Нити» organize and connect ideas.

The data models remain separate.
