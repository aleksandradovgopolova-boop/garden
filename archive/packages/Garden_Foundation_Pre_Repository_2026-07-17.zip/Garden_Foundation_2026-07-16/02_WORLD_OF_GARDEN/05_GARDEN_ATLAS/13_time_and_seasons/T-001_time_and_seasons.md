# Atlas T-001 — Time and Seasons

**ID:** T-001  
**Раздел:** Time and Seasons  
**Статус:** `design principles`

## Time layers

- calendar;
- subjective;
- event;
- autobiographical;
- world;
- ritual;
- epoch.

## Time modes

- timeless;
- manual;
- local year;
- slow year;
- fictional cycle;
- personal epochs.

## Accepted candidates

- no time-based decay;
- no absence backlog;
- optional seasons;
- user-created epochs;
- exact dates always recoverable;
- freeze time;
- world changes ambiently, not permanently;
- no lifecycle transition from inactivity alone.

## Open

- default time mode;
- exact season models;
- epoch visualization;
- memory distortion risks;
- local calendar support;
- whether Alpha should include epochs.
