# EMO-001 — Expression Without Diagnosis

Garden holds expression but does not infer hidden emotional truth.
