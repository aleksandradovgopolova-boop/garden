# Garden Atlas

**Дата создания:** 16 июля 2026  
**Статус:** `living knowledge system`

Garden Atlas — связная энциклопедия мира Garden.

Каждая статья отвечает:

1. Что известно.
2. Какие подходы существуют.
3. Что это может значить для Garden.
4. Что мы решили.
5. Что остаётся неизвестным.
6. Как это проверить.

## Разделы

Beauty, Places, Plants, Trees, Water, Light, Weather, Materials, Animals, Sounds, Architecture, Objects, Time and Seasons, Rituals, Memory.

## Правило

> Атлас не превращает культурную традицию, эстетическую теорию или научный результат в универсальный закон вкуса.
