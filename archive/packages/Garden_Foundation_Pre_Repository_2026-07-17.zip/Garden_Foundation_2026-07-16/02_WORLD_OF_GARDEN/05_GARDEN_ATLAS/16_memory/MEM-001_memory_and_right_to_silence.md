# Atlas MEM-001 — Memory and the Right to Silence

## Core boundaries

- not a second brain;
- not a knowledge graph;
- not a note system;
- not an autobiography engine;
- not «Нити».

## Alpha capabilities

- manual memory;
- one primary place link;
- optional ritual or object link;
- media;
- later reflection;
- search;
- hide;
- archive;
- export;
- delete.

## Prohibited

- automatic resurfacing;
- “On this day”;
- importance ranking;
- inferred emotional meaning;
- graph view;
- automatic related memories.
