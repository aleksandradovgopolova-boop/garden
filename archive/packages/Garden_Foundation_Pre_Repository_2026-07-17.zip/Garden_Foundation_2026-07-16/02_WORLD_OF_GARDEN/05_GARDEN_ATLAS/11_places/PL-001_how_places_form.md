# Atlas PL-001 — How Places Form

**ID:** PL-001  
**Раздел:** Places  
**Статус:** `design principles`

## Place components

- boundary;
- center;
- path;
- view;
- refuge;
- landmark;
- atmosphere;
- use;
- history.

## Alpha templates

- Open clearing;
- Sheltered edge;
- Water place;
- Workshop;
- Crossing;
- Empty ground.

## Accepted candidates

- attachment is not a KPI;
- emptiness is legitimate;
- naming is optional;
- direct navigation always exists;
- visual and data privacy are distinct;
- templates describe spatial qualities, not personality;
- place lifecycle is user-controlled;
- places private in Alpha.

## Open

- default starting place;
- ritual-first vs place-first;
- place size limits;
- later shared places;
- map and navigation model.
