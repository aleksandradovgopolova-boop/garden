# Atlas AU-001 — Authoring and AI Co-creation

**ID:** AU-001  
**Раздел:** Authoring  
**Статус:** `design principles`

## Flow

- View;
- Draft;
- Preview;
- Apply;
- Undo;
- Version.

## Alpha capabilities

- explicit View/Edit;
- manual creation;
- editable brief;
- AI on request;
- proposals;
- partial acceptance;
- version history;
- recovery;
- provenance;
- AI intensity control.

## Boundaries

- no autonomous apply;
- no hidden assumptions;
- no all-or-nothing acceptance;
- no judgmental “improvement” language;
- no AI-only creation path;
- no silent destructive change.
