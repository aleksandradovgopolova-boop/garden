# Garden Declaration — Candidate

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** candidate pending GDR acceptance

---

Garden exists to reduce the distance between what matters to a person and the next caring action that can live in reality.

It does not promise:

- a perfect life;
- permanent wellbeing;
- total self-knowledge;
- endless growth;
- complete control;
- a system that knows the person better than they know themselves.

Garden begins from a simple position:

> A person is not a project to optimize.

A person may:

- not know;
- contradict themselves;
- change direction;
- need structure;
- reject support;
- rest;
- act;
- ask for help;
- finish;
- leave.

Garden helps clarify:

- what happened;
- what matters now;
- what is known;
- what is assumed;
- what conditions shape the situation;
- what can be acted on;
- who else holds power or responsibility;
- what small practice or action is worth trying.

Its support is chosen rather than imposed.

Its reflection is bounded rather than endless.

Its memory serves continuity but does not become destiny.

Its measurements answer a question but do not grade a life.

Its AI proposes versions but does not own meaning.

Its garden is a metaphor, not a diagnosis.

Its social layer creates narrow bridges, not surveillance.

Its care does not hide structural harm.

Its openness to the unknown does not discard expertise or safety.

Garden succeeds when the person can:

- understand enough;
- act in life;
- change the practice;
- complete it;
- seek a human;
- stop using the product;
- continue without Garden.

> **Small practices. A life that remains larger than the product.**
