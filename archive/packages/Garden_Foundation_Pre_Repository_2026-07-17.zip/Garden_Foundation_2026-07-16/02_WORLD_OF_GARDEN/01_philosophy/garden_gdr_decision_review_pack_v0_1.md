# Garden GDR Decision Review Pack

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** owner decision preparation  
**Scope:** GDR-005–GDR-017

---

## 1. Purpose

This document does not silently accept any decision.

It provides:

- a recommendation;
- required amendments;
- dependencies;
- Alpha implication;
- owner decision field.

Allowed owner decisions:

- `accept`;
- `accept_with_amendment`;
- `defer`;
- `reject`;
- `reopen_research`.

---

## 2. Recommended bundle decision

The 13 GDRs form a coherent system and can be accepted as one foundation bundle **with targeted amendments**.

Recommended overall status:

> `accept_with_amendments`

The amendments do not change the central direction. They reduce onboarding burden, Alpha scope and hidden authority.

---

## 3. Decision table

| GDR | Topic | Recommendation | Required amendment | Alpha |
|---|---|---|---|---|
| 005 | Voice and calibrated trust | Accept with amendment | Replace “benevolent demandingness” with benevolent precision; one calm adult default | Core |
| 006 | Practice as core entity | Accept | Test user-facing term; ritual remains brand/type | Core |
| 007 | Bounded reflection | Accept | No material change | Core |
| 008 | Chosen support | Accept | Use progressive disclosure; no complex full contract at onboarding | Core |
| 009 | Explicit voice, no identity inference | Accept with amendment | Lightweight override first; full Voice Contract later | Core, minimal |
| 010 | AI does not own interpretation | Accept | No material change | Core |
| 011 | Measurement is intervention | Accept | No-tracking comparator mandatory | Core |
| 012 | Privacy/security as boundary | Accept with governance condition | Formal acceptance requires named privacy and security reviewers | Launch gate |
| 013 | Metaphor as optional lens | Accept with amendment | Review the user-facing name `AI Gardener`; literal mode first-class | Core brand |
| 014 | Narrow social bridges | Accept, defer implementation | Alpha limited to prepared offline request; one-time share only if necessary | Mostly later |
| 015 | Relief vs source change | Accept with amendment | Use lightweight source check; full L1–L5 map only when relevant | Core guardrail |
| 016 | Compete on agency architecture | Accept | One direction → one practice → one review | Strategy |
| 017 | Productive unknowing | Accept, experimental implementation | Principle enters Canon; Fresh Eyes feature tested after core wedge | Later experiment |

---

## 4. Individual review

### GDR-005 — Voice and calibrated trust

**Recommendation:** `accept_with_amendment`

Keep:

- adult voice;
- epistemic calibration;
- real choice;
- no fake intimacy;
- no obedience praise;
- conversation ends after clarity.

Amend:

- replace internal phrase `доброжелательная требовательность` with `доброжелательная точность`;
- default is calm and concise, not “warm companion”;
- directness is user-selected or contextually justified;
- warmth never changes factual or safety content.

**Owner decision:** `__________`

---

### GDR-006 — Practice as core entity

**Recommendation:** `accept`

Keep:

- practice as base object;
- ritual as optional type/quality;
- one-off, recurring, temporary and completed forms;
- no failed status.

Amend only implementation language:

- test whether Russian users understand `практика`;
- retain slogan independently from object schema.

**Owner decision:** `__________`

---

### GDR-007 — Bounded reflection

**Recommendation:** `accept`

This is a central safety and product decision.

Core invariants:

- permission;
- concrete anchor;
- one question;
- maximum two hypotheses;
- alternatives;
- stop rules;
- closure;
- no daily deep-reflection norm.

**Owner decision:** `__________`

---

### GDR-008 — Chosen support

**Recommendation:** `accept_with_implementation_simplification`

Keep:

- support belongs to current user choice;
- no punishment;
- no escalation after silence;
- no hard commitments;
- changed circumstances can override old plans;
- support should become less necessary.

Amend:

- onboarding should not show a full contract form;
- ask only what is necessary for the current practice;
- reveal advanced support settings when requested.

**Owner decision:** `__________`

---

### GDR-009 — Explicit voice preferences

**Recommendation:** `accept_with_amendment`

Keep:

- no adaptation by gender, age, country or diagnosis;
- no automatic sociolect mimicry;
- fixed ethics;
- visible and deletable preferences.

Amend:

- initial options limited to `короче`, `теплее`, `прямее`;
- no mandatory voice configuration;
- accessibility adaptation may be proactive when based on interface needs, not identity assumptions.

**Owner decision:** `__________`

---

### GDR-010 — AI does not own interpretation

**Recommendation:** `accept`

This is a foundational invariant.

Required:

- epistemic level;
- provenance;
- correction;
- no diagnosis/identity claims;
- no hidden profile;
- no persuasion through memory;
- no interpretation that cannot be rejected.

**Owner decision:** `__________`

---

### GDR-011 — Measurement is intervention

**Recommendation:** `accept`

Required:

- no total score;
- no streak;
- missingness visible;
- no passive mental-state inference in Alpha;
- purpose-bound and temporary measurement;
- no-tracking as a full product mode and Alpha comparator.

**Owner decision:** `__________`

---

### GDR-012 — Privacy/security as product boundary

**Recommendation:** `accept_with_governance_condition`

The owner can accept the philosophical and product boundary now.

Operational launch acceptance additionally requires:

- named privacy owner;
- named security owner;
- legal review;
- DPIA;
- provider DPA/no-training;
- deletion proof;
- incident process;
- crisis review.

No project owner alone should waive these gates.

**Owner decision:** `__________`

---

### GDR-013 — Metaphor as optional lens

**Recommendation:** `accept_with_amendment`

Keep:

- brand and slogan;
- literal equivalent;
- no dying garden;
- no weeds/pests/illness as human feedback;
- no mandatory growth;
- no metaphor-based score.

Amend:

- review `AI Gardener` as a user-facing role;
- default copy should be lightly metaphorical rather than immersive;
- visual Garden is not part of the first wedge.

**Owner decision:** `__________`

---

### GDR-014 — Narrow social bridges

**Recommendation:** `accept`, implementation mostly `defer`

Keep as architecture:

- share coordination, not interior;
- no social graph;
- no comparison;
- no automatic miss disclosure;
- separate consent and safe exit.

Alpha recommendation:

- include `Prepared Connection` only;
- possibly test one-time selected share;
- do not build Trusted Person account linking yet;
- no shared practices, circles or community.

**Owner decision:** `__________`

---

### GDR-015 — Relief vs source-directed change

**Recommendation:** `accept_with_progressive_disclosure`

Keep:

- cause/control/responsibility distinction;
- relief is not resolution;
- resource/power/safety check;
- no employer resilience surveillance.

Amend:

- do not display a five-level analysis in every ordinary flow;
- trigger lightweight source check on recurring distress, low control, coercion or organizational issues;
- use current verified external resources only when needed.

**Owner decision:** `__________`

---

### GDR-016 — Compete on agency architecture

**Recommendation:** `accept`

Strategy:

- not an AI journal;
- not a wellbeing super-app;
- one-direction/one-practice wedge;
- generic AI as comparator;
- no content arms race;
- no companion persona;
- no business model dependent on emotional reliance.

**Owner decision:** `__________`

---

### GDR-017 — Productive unknowing

**Recommendation:** `accept principle; defer full feature`

Canon principle:

- facts and safety constraints remain;
- conventions and identity stories can be questioned;
- use reversible probes;
- seek expertise where risk is high;
- past does not get an automatic veto.

Alpha:

- language and experiment design may use the principle;
- full Fresh Eyes mode should not enlarge the first wedge.

**Owner decision:** `__________`

---

## 5. Bundle invariants after acceptance

If the bundle is accepted, the following become non-negotiable until a superseding GDR:

1. Practice is the core object.
2. Garden never defines the good life.
3. AI output about a person is corrigible and bounded.
4. No total wellbeing score.
5. No streak as the core motivation system.
6. No hidden psychological profile.
7. No provider training on production content.
8. No employee browsing by default.
9. No dying garden or relational punishment.
10. No social feed or public comparison in Alpha.
11. Relief is not presented as source change.
12. Garden may become less necessary.
13. Past behavior does not become identity.
14. Safety and consent override growth and exploration.

---

## 6. Owner sign-off

```yaml
bundle_decision:
decided_by:
date:
accepted_gdrs:
accepted_with_amendment:
deferred:
rejected:
notes:
```
