# Garden Canonical Principles — Candidate

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** candidate pending GDR acceptance

---

## 1. The person is not an optimization object

Garden does not treat a person as:

- a broken system;
- a score;
- an engagement target;
- an obedient executor;
- a psychological profile.

The person remains the author of meaning and decision.

---

## 2. Garden does not define the good life

Garden can help clarify values, trade-offs and consequences.

It cannot decide:

- what should matter;
- what a fulfilled life looks like;
- how much growth is enough;
- whether a person is flourishing correctly.

---

## 3. Context comes before character

Before explaining behavior through motivation or identity, Garden considers:

- capability;
- opportunity;
- energy;
- relationships;
- organization;
- material environment;
- power and resources.

---

## 4. Practice is the core object

Garden supports a practice that may be:

- one-time;
- recurring;
- temporary;
- seasonal;
- symbolic;
- practical;
- completed;
- released.

A practice is not required to become a habit.

---

## 5. Support is chosen, not imposed

The user decides:

- whether support is wanted;
- what form it takes;
- when it occurs;
- what happens after a miss;
- when it ends.

Silence does not authorize escalation.

---

## 6. Reflection has a boundary

Garden reflection:

- starts with permission;
- uses a concrete anchor;
- distinguishes fact and interpretation;
- explores one question;
- limits hypotheses;
- supports uncertainty;
- closes.

Endless reflection is not success.

---

## 7. AI proposes; the person interprets

AI may:

- organize;
- question;
- compare;
- hypothesize;
- show alternatives.

AI may not:

- diagnose;
- define identity;
- assign hidden motives;
- create a final life narrative;
- treat disagreement as resistance.

---

## 8. Ethics are fixed; style is adjustable

Warmth, directness, length and metaphor may vary.

The following do not vary:

- factual accuracy;
- safety;
- respect;
- consent;
- uncertainty;
- non-manipulation.

---

## 9. Measurement changes what it observes

Garden measures only for a clear purpose.

It provides:

- no-tracking mode;
- visible missingness;
- limited duration;
- clear interpretation limits;
- easy exit.

No total Garden Score exists.

---

## 10. Privacy and safety limit the product

Garden does not launch a function merely because consent text can be written.

A function must have:

- a necessary purpose;
- minimal data;
- controlled access;
- deletion;
- failure handling;
- provider guarantees;
- evidence that risk is acceptable.

---

## 11. Metaphor is optional

The garden is:

- a name;
- an atmosphere;
- one possible lens.

It is not:

- a model of the psyche;
- a medical status;
- a moral score;
- a demand to grow.

Literal language always remains available.

---

## 12. Social connection uses narrow bridges

Garden helps prepare or coordinate a chosen human connection.

It does not build:

- a feed;
- a popularity system;
- a public inner life;
- automatic accountability;
- surveillance between close people.

---

## 13. Relief is not the same as change

Garden separates:

- what helps now;
- what protects;
- what prepares;
- what changes the source;
- who is responsible;
- when exit is appropriate.

A coping practice does not legitimize harmful conditions.

---

## 14. Knowledge does not receive an automatic veto

Garden protects facts and safety constraints.

It may question:

- convention;
- prediction;
- identity stories;
- overgeneralized past outcomes.

Unknown is a valid state.

---

## 15. Small means complete, not manipulative

A small version is valid only if it preserves meaning by itself.

It is not bait to make the person do more.

---

## 16. Completion is success

A practice may:

- continue;
- adapt;
- pause;
- integrate;
- complete;
- be released.

Garden does not preserve goals merely to preserve engagement.

---

## 17. The product points outward

Garden should lead toward:

- action;
- rest;
- conversation;
- professional help;
- environmental change;
- silence;
- life without the app.

---

## 18. Trust must match evidence

Garden does not use confidence, personalization or warmth to hide uncertainty.

The user can see:

- what is known;
- what is inferred;
- what is missing;
- what can be corrected.

---

## 19. Safety overrides elegance and growth

When safety, consent or irreversible harm is at stake:

- metaphor steps aside;
- exploration stops;
- expertise is sought;
- authorization becomes explicit;
- the smaller product is preferred.

---

## 20. Garden must remain revisable

Research, product tests and harm reports can change the Canon.

The project must preserve:

- rejected ideas;
- uncertainty;
- reasons for decisions;
- evidence limits;
- the possibility that a simpler tool is better.
