# Garden Foundation Dependency Map

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** assembly working document

---

## 1. Dependency chain

```text
R-001 Change
  ├─> GDR-006 Practice
  ├─> GDR-008 Chosen Support
  └─> GDR-015 Multilevel Action

R-002 Care vs Control
  ├─> GDR-005 Voice
  ├─> GDR-008 Support
  └─> GDR-014 Social Bridges

R-003 Nature
  └─> GDR-013 Optional Metaphor

R-004 Language
  ├─> GDR-005 Voice
  ├─> GDR-009 Voice Personalization
  └─> GDR-010 Interpretation

R-005 Good Life
  ├─> GDR-010 Interpretation
  ├─> GDR-011 Measurement
  └─> Canon: no universal flourishing score

GDR-006 Practice
  ├─> GDR-007 Reflection
  ├─> GDR-008 Support
  ├─> GDR-011 Measurement
  └─> GDR-016 Market Wedge

GDR-007 Reflection
  └─> GDR-010 AI Interpretation

GDR-009 Voice
  └─> GDR-010 AI Interpretation

GDR-010 Interpretation
  ├─> Memory Governance
  ├─> GDR-012 Privacy/Security
  └─> GDR-017 Productive Unknowing

GDR-011 Measurement
  └─> GDR-012 Data Architecture

GDR-012 Privacy/Security
  ├─> GDR-014 Social Architecture
  └─> Alpha launch gates

GDR-013 Metaphor
  └─> Alpha literal/metaphor layers

GDR-014 Social
  └─> Human Bridge implementation

GDR-015 Multilevel Action
  └─> Alpha recurring-distress guardrail

GDR-016 Market
  ├─> Alpha scope
  └─> Comparator strategy

GDR-017 Productive Unknowing
  ├─> Memory retrieval order
  └─> Later Fresh Eyes experiment
```

---

## 2. Decisions that must be accepted before Canon

- GDR-005;
- GDR-006;
- GDR-007;
- GDR-008;
- GDR-009;
- GDR-010;
- GDR-011;
- GDR-013;
- GDR-015;
- GDR-016.

GDR-012 can enter Canon as a boundary, but operational approval requires accountable reviewers.

GDR-014 and GDR-017 can be accepted philosophically while their features remain deferred.

---

## 3. Decisions that block Alpha design

### Hard blockers

- GDR-006 — core object;
- GDR-007 — reflection mechanics;
- GDR-008 — support mechanics;
- GDR-010 — AI role;
- GDR-011 — measurement;
- GDR-012 — privacy/security;
- GDR-016 — wedge.

### Guardrail blockers

- GDR-005 — voice;
- GDR-009 — style;
- GDR-013 — metaphor;
- GDR-015 — structural context.

### Non-blocking for first Alpha implementation

- GDR-014 social account features;
- GDR-017 full Fresh Eyes mode.

---

## 4. Architecture dependencies

### Practice object requires

- Current Direction;
- meaning;
- context;
- form/version;
- support setting;
- review;
- lifecycle status.

### Reflection requires

- event or question anchor;
- permission;
- epistemic labels;
- stop rules;
- memory decision.

### Memory requires

- provenance;
- author;
- domain;
- expiry;
- sensitivity;
- correction;
- deletion;
- allowed use.

### Measurement requires

- explicit purpose;
- no-tracking path;
- missingness state;
- retention;
- burden review.

### AI requires

- mode;
- source boundaries;
- output validation;
- tool authorization;
- safety route;
- no hidden cross-domain retrieval.

---

## 5. Sequencing

### Sequence 1 — Canon

GDR decisions → Declaration → Bible → Principles → Anti-Goals.

### Sequence 2 — Language

GDR-005 + 009 + 010 + 013 + 017 → Garden Language v2.

### Sequence 3 — Product

GDR-006 + 007 + 008 + 011 + 015 → Product Model v2.

### Sequence 4 — Safety

GDR-010 + 011 + 012 + 014 → Privacy, Security and Human Safety Architecture.

### Sequence 5 — Alpha

GDR-016 + all hard blockers → Alpha Blueprint v2.

---

## 6. Change-control rule

A feature cannot bypass an upstream decision.

Examples:

- a dashboard cannot add a score without reopening GDR-011;
- an AI companion persona cannot ship without reopening GDR-005, 010 and 016;
- a shared practice cannot expose private notes without reopening GDR-012 and 014;
- a dying visual garden cannot ship without reopening GDR-013;
- employer reporting cannot ship without reopening GDR-012 and 015.
