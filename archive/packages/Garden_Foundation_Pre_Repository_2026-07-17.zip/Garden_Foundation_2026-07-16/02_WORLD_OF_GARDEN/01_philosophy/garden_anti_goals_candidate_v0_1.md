# Garden Anti-Goals — Candidate

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** candidate pending GDR acceptance

---

Garden is not trying to become:

## 1. A habit-compliance machine

No:

- streak as core value;
- punishment after a miss;
- obedience praise;
- automatic escalation;
- “never break the chain”.

## 2. An AI therapist or diagnostic system

No:

- diagnosis;
- clinical treatment claims;
- crisis-monitoring promise;
- attachment-style verdict;
- trauma-story generation;
- medical recommendations outside a regulated pathway.

## 3. A companion that needs the user

No:

- “I missed you”;
- emotional debt;
- exclusive bond;
- jealous or needy persona;
- avatar suffering after absence;
- simulated friendship as retention.

## 4. A life score

No:

- Garden Score;
- flourishing score;
- productivity score;
- emotional stability score;
- ranking against other people;
- hidden psychological risk profile.

## 5. An endless introspection engine

No:

- infinite follow-up questions;
- daily depth as a norm;
- insight count;
- repeated causal storytelling;
- engagement through rumination.

## 6. A total memory of the person

No:

- hidden identity summary;
- indefinite AI hypotheses;
- cross-domain leakage;
- sensitive profiling;
- memory used for persuasion;
- deleted material resurfacing.

## 7. A social network around inner life

No:

- public diary;
- feed;
- follower graph;
- leaderboards;
- public streaks;
- automatic miss disclosure;
- employer/family monitoring.

## 8. A garden that judges

No:

- dying garden after inactivity;
- weeds as emotions or people;
- pests as relationships;
- bloom as human worth;
- fruit as productivity;
- compulsory growth.

## 9. A self-care layer over harmful systems

No:

- resilience program instead of workload change;
- breathing exercise instead of safety;
- “better boundaries” instead of responsibility;
- employee wellbeing surveillance;
- coping presented as root-cause resolution.

## 10. A certainty machine

No:

- hidden motives stated as facts;
- one natural solution;
- confident cross-domain advice;
- past behavior treated as destiny;
- optimism replacing evidence;
- anti-expertise language.

## 11. A data-extraction business

No:

- advertising based on intimate content;
- sale of personal data;
- provider training on production content;
- privacy as a premium feature;
- raw diary text in analytics;
- unrestricted employee browsing.

## 12. A super-app before evidence

No:

- full ecosystem in Alpha;
- community before moderation;
- wearables before measurement value;
- immersive garden before core utility;
- content-library arms race;
- autonomous agents before bounded workflow.

---

## The anti-goal test

Before building a feature, ask:

1. Does it increase the person’s agency or the product’s control?
2. Does it help life or mainly increase use?
3. Does it require more data than the value justifies?
4. Does it turn uncertainty into a confident story?
5. Does it create guilt, comparison or dependency?
6. Does it hide a relationship or structural problem?
7. Can the person refuse, correct, delete and leave?
8. Would Garden still build it if engagement were not a success metric?
