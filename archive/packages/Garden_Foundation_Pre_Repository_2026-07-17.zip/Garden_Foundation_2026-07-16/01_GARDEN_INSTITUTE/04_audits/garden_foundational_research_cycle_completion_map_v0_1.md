# Garden Foundational Research Cycle — Completion Map

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** cycle complete; assembly pending

## Research status

| ID | Question | Core product consequence | Status |
|---|---|---|---|
| R-001 | Why people change | Context and capability before motivation | Completed/audited |
| R-002 | Care vs control | Support must preserve autonomy | Completed/audited |
| R-003 | Why nature calms us | Real nature, digital nature and metaphor separated | Completed/audited |
| R-004 | Inner dialogue and Garden voice | Adult, precise, non-parental language | Completed/audited |
| R-005 | What is a good life and who decides | Garden does not define flourishing | Completed |
| R-006 | Ritual, habit, routine and practice | Practice becomes core object | Completed |
| R-007 | Reflection vs rumination | Bounded reflection with stop rules | Completed |
| R-008 | Support action without control | Chosen Support Contract | Completed |
| R-009 | Language across cultures and contexts | Fixed ethics, adjustable style | Completed |
| R-010 | AI and self-understanding | AI does not own interpretation | Completed |
| R-011 | Measurement effects | No total score; measurement is intervention | Completed |
| R-012 | Privacy, security and safety | Safety as product boundary | Completed |
| R-013 | Garden metaphor | Optional lens, literal core | Completed |
| R-014 | Social layer | Narrow bridges, not social network | Completed |
| R-015 | Personal vs structural problem | Relief distinguished from source change | Completed |
| R-016 | Market and whitespace | Compete on agency architecture | Completed |
| R-017 | Power of not knowing | Productive unknowing and Fresh Eyes | Completed |

## Proposed decisions awaiting owner review

- GDR-005 — calibrated trust and voice;
- GDR-006 — practice as core entity;
- GDR-007 — bounded reflection;
- GDR-008 — chosen support;
- GDR-009 — explicit voice preferences;
- GDR-010 — AI does not own interpretation;
- GDR-011 — measurement is intervention;
- GDR-012 — privacy/security as product boundaries;
- GDR-013 — metaphor as optional lens;
- GDR-014 — narrow social bridges;
- GDR-015 — relief vs source change;
- GDR-016 — compete on agency architecture;
- GDR-017 — productive unknowing.

## Foundation Assembly plan

### Phase A — Evidence and contradiction audit

1. Merge Source Registry addenda.
2. Audit source status, retractions, licensing and recency.
3. Build claim graph.
4. Identify contradictions across R-001–R-017.
5. Separate evidence, synthesis, design hypothesis and normative decision.

### Phase B — Decision review

1. Present each GDR with consequences.
2. Accept, reject or revise.
3. Record owner rationale.
4. Create dependency map.
5. Freeze Foundation v1 decisions.

### Phase C — Canon

Create:

- Garden Declaration;
- Garden Bible v4;
- Ethics Constitution;
- Anti-Goals;
- Product Principles;
- Garden Language;
- Safety Constitution;
- Evidence Standard.

### Phase D — Product model

Finalize:

- Current Direction;
- Practice;
- Meaningful Minimum;
- Support Contract;
- Bounded Reflection;
- Memory;
- Measurement;
- Multilevel Action;
- Fresh Eyes;
- Social Bridge.

### Phase E — Alpha Blueprint

1. Single wedge and target situation.
2. End-to-end user flow.
3. AI role and tool architecture.
4. Data-flow diagram and DPIA.
5. Security/privacy launch gates.
6. Failure and crisis states.
7. Literal and metaphor layers.
8. Alpha backlog.

### Phase F — Experiment plan

Comparators:

- plain note;
- reminder;
- habit tracker;
- generic AI chat.

Primary outcomes:

- real-world action;
- agency;
- low pressure;
- calibrated trust;
- adaptation and completion;
- low dependence;
- value beyond comparator.

### Phase G — Build/no-build decision

Proceed only if:

- problem resonance is real;
- wedge is understood;
- incremental value exists;
- safety gates are feasible;
- business model does not require dependence;
- scope fits available team/resources.

## Rule after cycle completion

No new foundational research is added by default.

A new R-series item requires one of:

- unresolved launch-blocking contradiction;
- new regulated capability;
- critical evidence gap;
- owner decision changing the product’s category;
- serious harm discovered in testing.

All other questions move to:

- product discovery;
- experiment;
- Observatory;
- GDR;
- implementation research.
