# Garden Foundation Assembly — Contradiction and Consistency Audit

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** assembly working document  
**Scope:** R-001–R-017, GDR-005–GDR-017, Philosophy v0.1, Alpha Blueprint v1

---

## 1. Executive conclusion

The foundational research program is substantially coherent.

No critical contradiction was found between the central ethical conclusions of R-001–R-017. Most studies independently converge on the same product position:

> Garden may structure attention, questions, practices and support, but it must not claim ownership over the person’s meaning, behavior, data, relationships or life direction.

The main inconsistency is not inside the research. It is between the research and older product documents—especially `garden_alpha_blueprint_v1.md`.

### Assembly verdict

- Research cycle: coherent enough to assemble.
- Proposed GDRs: mutually compatible with several scope amendments.
- Philosophy v0.1: directionally correct but outdated in terminology and metaphor strength.
- Alpha Blueprint v1: **superseded candidate; not launch-ready**.
- Security/privacy: launch-blocking until operational owners and gates exist.
- Next action: accept/revise GDRs, create Canon v1, rebuild Alpha Blueprint v2.

---

## 2. Central convergence across the research

### Human position

The person is:

- an adult subject, not an optimization object;
- allowed contradiction, uncertainty, rest and changed decisions;
- not reducible to a score, habit history or AI profile;
- influenced by relationships, resources and systems;
- entitled to reject Garden’s language and interpretation.

### AI position

AI is:

- a bounded co-interpreter;
- a source of questions and options;
- required to distinguish fact and hypothesis;
- corrigible;
- non-exclusive;
- not a therapist, judge, oracle, friend or gardener of the person.

### Action position

Action is:

- chosen rather than enforced;
- sensitive to capability, opportunity and context;
- permitted to adapt, pause, complete or be released;
- separated into relief and source-directed change;
- sometimes a safe experiment rather than a permanent commitment.

### Data position

Data are:

- purpose-bound;
- minimal;
- user-visible;
- correctable and deletable;
- not automatically psychological facts;
- not collected merely because personalization is possible.

### Product position

Success includes:

- real-world action;
- better calibrated understanding;
- lower pressure;
- safe adaptation;
- completion;
- reduced need for Garden.

---

## 3. High-priority contradictions requiring correction

### C-01 — `Ritual` as core entity vs `Practice` as core entity

**Current documents**

- Philosophy v0.1 and Alpha v1 use ritual as the main object.
- GDR-006 proposes practice as the base entity and ritual as one possible quality/type.

**Risk**

- ritual implies repetition, symbolism and specialness;
- excludes one-off, seasonal and instrumental actions;
- conflicts with the market wedge and product model.

**Resolution**

- Canon and Alpha v2 use `practice` as the core entity.
- The slogan «Маленькие ритуалы. Большой сад» may remain brand language.
- User-facing terminology should be tested rather than assumed.
- Existing ritual documents are marked historical/superseded where necessary.

---

### C-02 — Alpha v1 marked “ready to launch” vs unaccepted decisions and missing launch gates

**Current documents**

Alpha v1 says:

> `Статус: готов к подготовке и запуску`.

R-012/GDR-012 require:

- DPIA;
- provider review;
- threat model;
- deletion verification;
- no-training guarantee;
- cross-user isolation;
- crisis review;
- accountable security/privacy owners.

**Risk**

The project may treat ethical research as guidance while launching an architecture that has not implemented it.

**Resolution**

Alpha v1 status becomes:

> `superseded candidate / do not launch`.

Alpha v2 cannot be called launch-ready until all P0 gates are assigned and verified.

---

### C-03 — Default daily measurement vs minimal purpose-bound measurement

**Current documents**

Alpha v1 includes:

- daily form;
- daily status;
- daily contextual classification;
- return within 48 hours after a miss as a metric.

GDR-011 requires:

- no-tracking as a full mode;
- temporary purpose-bound measurement;
- explicit measurement contract;
- missingness not interpreted as failure;
- burden/reactivity evaluation.

**Risk**

- creates a de facto streak without displaying one;
- changes attention;
- confounds support with measurement;
- makes re-engagement a product goal.

**Resolution**

Alpha v2 includes at least:

- no-tracking/simple note comparator;
- user-selected review cadence;
- event recording optional;
- no 48-hour return metric;
- explicit burden and unwanted-prompt measures.

---

### C-04 — Fixed 14-day “living with a ritual” vs flexible practice lifecycle

**Current documents**

Alpha v1 gives all participants one 14-day repeated ritual.

GDR-006 defines practices as:

- one-off;
- recurring;
- temporary;
- seasonal;
- adapting;
- resting;
- integrated;
- completed;
- released.

**Risk**

The research design may prove only that Garden supports two-week repeated actions, while the product claims a wider model.

**Resolution**

The initial wedge may still use a 10–14 day observation window, but:

- the practice itself need not be daily;
- completion may happen before day 14;
- non-repetition can be valid;
- time window is a study frame, not the meaning of the practice.

---

### C-05 — “Insight about self” as primary outcome vs bounded interpretation

**Current documents**

Alpha v1 primary outcome asks whether the user formulates a useful observation about self.

R-010 warns against:

- identity narratives;
- AI-created coherence;
- insight count;
- unverified psychological interpretation.

**Risk**

The study rewards the production of personal explanations regardless of accuracy or practical value.

**Resolution**

Primary outcome becomes a combination of:

- distinction between fact and version;
- chosen real-world action;
- useful adaptation or closure;
- calibrated trust;
- ability to disagree;
- value relative to comparator.

“Insight” remains optional and must be traceable to evidence.

---

### C-06 — Researcher review of sensitive conversations vs privacy boundaries

**Current documents**

Alpha v1 proposes:

- Telegram/chat;
- researcher table;
- human checking of sensitive responses before sending.

R-012 requires:

- no default employee reading;
- purpose-limited access;
- DPIA;
- consented research governance;
- no raw-content analytics;
- explicit crisis boundary.

**Risk**

Concierge support becomes broad human access to intimate data without an operational access model.

**Resolution**

Alpha v2 specifies:

- what the researcher sees;
- why;
- how long;
- who is authorized;
- how consent and withdrawal work;
- how data are redacted;
- where data are stored;
- when human review occurs;
- what cannot be promised.

---

### C-07 — Garden metaphor as life model vs optional lens

**Current documents**

Philosophy v0.1 says:

> «Garden использует образ сада, потому что жизнь…»

R-013 says the garden is:

- an optional lens;
- not ontology;
- not a psychological model;
- not a score.

**Risk**

The brand metaphor becomes a truth claim about human life.

**Resolution**

Canon wording changes to:

> Garden offers the garden as one optional way to notice context, time and interdependence.

Literal mode is always first-class.

---

### C-08 — `AI Gardener` role vs prohibition on AI as gardener of the person

**Current documents**

The project repeatedly uses `AI Gardener`.

R-013 prohibits positioning AI as the gardener of the person.

**Risk**

- hierarchy;
- parental care;
- implied authority over pruning/growth;
- relational attachment.

**Resolution**

- `AI Gardener` remains an internal temporary label only.
- User-facing role name must be tested.
- The system is described as a guide/interface/tool, not the caretaker of the user.
- No copy implies that AI grows, prunes or saves the person.

---

### C-09 — “Benevolent demandingness” vs adult non-parental voice

**Current documents**

Philosophy uses:

> «доброжелательная требовательность».

R-004/R-009 emphasize:

- non-parental language;
- no moral supervision;
- no praise for obedience;
- real choice.

**Risk**

The phrase can authorize pressure under a caring tone.

**Resolution**

Replace the internal principle with:

> **доброжелательная точность**  
> уважать человека, не скрывая фактов и границ.

Challenge is allowed only through transparent evidence and requested directness.

---

### C-10 — Default tone modes vs explicit low-burden voice contract

**Current documents**

Alpha v1 asks every participant to choose one of four tone modes.

GDR-009 proposes explicit choice but warns that the contract itself may add burden.

**Risk**

Onboarding becomes configuration-heavy and implies that tone personalization is core value.

**Resolution**

- one calm adult default;
- one lightweight override: “короче / теплее / прямее”;
- full Voice Contract available later;
- no inference from demographics or diagnosis.

---

### C-11 — Replacement question risks moral suspicion

**Current Alpha copy**

> «Она действительно поддержала ту же потребность или скорее помогла избежать ритуала?»

**Risk**

- false binary;
- hidden suspicion;
- treats avoidance as likely failure;
- may increase self-surveillance.

**Resolution**

Use bounded neutral form:

> «Что дала эта замена? Этого было достаточно на сегодня или ты хочешь что-то изменить в следующий раз?»

---

### C-12 — Re-engagement as benefit vs beneficial disengagement

**Current documents**

Alpha v1 values return after a miss.

R-008/R-016 treat disengagement as potentially:

- beneficial;
- completion;
- integration;
- product exit.

**Risk**

Product retention silently replaces human outcome.

**Resolution**

Classify non-return:

- completed;
- integrated;
- paused;
- no longer relevant;
- burdened;
- harmed;
- lost;
- unknown.

Return rate is descriptive, not a primary success metric.

---

### C-13 — Personal coping loop vs multilevel action

**Current documents**

Alpha v1 focuses on adapting a personal ritual.

R-015 requires source checks for recurring distress and separation of relief from source change.

**Risk**

The product may help users tolerate a harmful context.

**Resolution**

Alpha v2 includes a lightweight context check:

- What is under your control?
- What depends on another person or system?
- Is this practice relief, preparation or source-directed change?

Full structural mapping is not required in every flow.

---

### C-14 — Historical personalization vs Fresh Eyes

**Current documents**

Garden intends to use longitudinal context.

R-017 warns that memory can become a personal Einstellung effect.

**Risk**

Past failed attempts become an identity ceiling.

**Resolution**

Alpha v2 should not rely on long-term memory.  
Future product must support:

- source-aware history;
- no-history view;
- optional Fresh Eyes;
- safety history retained even when soft conclusions are bracketed.

---

### C-15 — Market scope vs product scope

**Current documents**

Older material describes a broad ecosystem: garden, trees, seasons, Mycorrhiza, social mechanics and AI.

R-016 recommends:

> one direction → one practice → one bounded review.

**Risk**

The project attempts to build philosophy as a full platform before proving incremental value.

**Resolution**

Freeze non-wedge features until comparator evidence exists.

---

## 4. Tensions that are productive rather than contradictory

### T-01 — Warmth vs calibrated distance

Both are needed.

Resolution:

- warm acknowledgment;
- no simulated relationship;
- explicit limits;
- no emotional debt.

### T-02 — Memory vs right to become different

Both are needed.

Resolution:

- memory supports continuity;
- provenance, expiry and correction;
- no identity summaries;
- optional Fresh Eyes.

### T-03 — Structure vs autonomy

Both are needed.

Resolution:

- clear bounded formats;
- meaningful choice;
- easy exit;
- no punishment.

### T-04 — Personal action vs structural causation

Both are needed.

Resolution:

- immediate relief;
- responsible actor visible;
- source-directed options;
- right-sized agency.

### T-05 — Expertise vs beginner’s mind

Both are needed.

Resolution:

- hard constraints stay;
- conventions can be questioned;
- high-stakes expertise gate;
- reversible probes.

### T-06 — Product usefulness vs designed obsolescence

This is a genuine business tension, not a research contradiction.

Resolution:

- validate willingness to pay for trustworthy bounded value;
- do not solve the tension with dependency mechanics.

---

## 5. Documents to supersede or revise

### Supersede candidate

- `garden_alpha_blueprint_v1.md`

### Major revision required

- `garden_philosophy_v0_1.md`
- `garden_voice_v0_1.md`
- `garden_project_map_research_market_v0_1.md`

### Integrate into Canon

- GDR-005–GDR-017 after owner decision;
- product models R-006–R-017;
- security requirements;
- knowledge architecture.

### Preserve as historical context

- all Chronicle entries;
- previous Alpha v1;
- ritual-first wording;
- early AI Gardener framing.

---

## 6. Assembly decision

Proceed to:

1. GDR review and default recommendations.
2. Canonical Principles candidate.
3. Alpha v1 → v2 change specification.
4. Garden Bible v4 draft only after owner decision status is explicit.
