# Garden Current State — 16 July 2026

**Status:** foundational research complete; decision assembly in progress

## What Garden is currently becoming

Garden is a proposed **agency-preserving sensemaking and practice system**.

It is intended to help an adult:

- clarify a current direction;
- distinguish facts, needs, assumptions and conditions;
- choose a small real-world practice or other action;
- select support without surrendering ownership;
- review experience without endless reflection;
- adapt, pause, complete or release;
- retain useful context without becoming trapped by a profile.

## What has been completed

- 17 foundational research studies;
- source addenda and claim registries;
- 13 proposed GDRs;
- voice, practice, reflection, support, memory, measurement, metaphor, social, structural and uncertainty models;
- market landscape and initial wedge;
- privacy/security threat model and preliminary launch gates.

## What is not yet completed

- owner acceptance of GDR-005–GDR-017;
- unified Source Registry audit;
- Garden Bible v4;
- final Ethics Constitution;
- final Garden Language;
- Alpha Blueprint v2;
- operational DPIA;
- provider/vendor decision;
- security and privacy ownership;
- tested crisis protocol;
- prototype validation;
- business-model evidence.

## Current build status

> **Do not launch Alpha v1.**

The current Alpha Blueprint predates major research decisions and is not aligned with:

- practice as core entity;
- minimal measurement;
- bounded interpretation;
- governed memory;
- privacy/safety gates;
- structural context;
- market wedge.

## Recommended next sequence

1. Accept/revise GDR bundle.
2. Freeze Canon v1.
3. Draft Alpha Blueprint v2.
4. Run concept and comparator tests.
5. Complete privacy/security feasibility.
6. Decide build / narrow / stop.
