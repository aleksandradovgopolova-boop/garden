# Garden Competitive Landscape — July 2026

**Версия:** 0.1  
**Статус:** market working document

| Product | Category | Core promise | Primary mechanics | AI role | Main engagement logic | Garden lesson |
|---|---|---|---|---|---|---|
| Rosebud | AI journal | Adapted reflection and personal growth | conversation, prompts, patterns, voice, memory | reflective companion/interpreter | ongoing journaling and subscription | Better AI prompts are not whitespace |
| Reflection | AI journal/coach | Guidance, clarity and flourishing | journal, voice, AI coach, guides, insights | coach and insight layer | guided programs and unlimited premium AI | Do not compete on guide library |
| Mindsera | AI journal/thinking | Mental wellbeing and thinking skills | frameworks, emotions, patterns, rituals, habits, voice | thinking copilot | daily rituals and analysis | Ritual + AI insight already exists |
| Liven | self-discovery suite | Understand and transform yourself | mood, habits, courses, AI assistant | companion | broad toolkit and programs | All-in-one transformation is generic |
| Day One | private journal | Capture life for the long term | multimedia, search, sync, export, E2EE | limited/emerging | durable archive | Privacy and ownership are benchmarks |
| Apple Journal | system journal | Reflect on everyday moments | on-device suggestions, media, prompts | on-device suggestion engine | notifications and memory capture | Private contextual prompts are platform territory |
| Daylio | mood micro-journal | Track mood and activities quickly | icons, activities, goals, charts | minimal | daily logging, goals | Fast logging competes with deep reflection |
| How We Feel | emotion education | Name and navigate feelings | emotion vocabulary, check-ins, strategies, health trends | pattern support | repeated check-in | Good language can coexist with tracking burden |
| Bearable | health tracker | Understand symptoms and factors | scales, factors, correlations, experiments | analytics | data completeness and reports | Do not imply causal insight from personal data |
| Exist | personal analytics | Understand behavior through correlations | integrations, tags, experiments, correlations | analytics | continuous data collection | «What makes me happy?» is a crowded analytics claim |
| Finch | gamified self-care | Care for yourself by caring for a pet | goals, exercises, rewards, pet, friends, streaks | personalization | avatar attachment and rewards | Garden must reject relational guilt |
| Fabulous | routine coaching | Transform life through routines | coachings, routines, goals, content, journal | guidance | programs and routine repetition | Avoid universal routine prescriptions |
| Habitica | gamified tasks | Treat life like a game | XP, health, rewards, pets, groups, streaks | none/limited | reward and penalty | Clear anti-reference for Garden |
| Stoic | wellness toolkit | Understand emotions and overcome obstacles | morning/evening journal, mood, breath, meditation, AI mentors | coach/mentor | daily ritual and toolkit | Broad toolkit is not enough |
| Calm | meditation/sleep | Stress relief and better sleep | meditations, stories, soundscapes | limited | content consumption | Garden cannot win via content scale |
| Headspace Ebb | AI + content platform | Empathetic reflection with activities | conversation, risk classification, content recommendation | AI companion/router | ongoing chat and library | Requires real safety operations |
| Wysa | digital mental health | Anonymous AI and guided support | structured chat, exercises, coaching, care integration | mental-health support | care continuum | Different clinical/institutional model |
| Ash | AI mental-health support | Long-term psychology-focused support | voice/text, patterns, weekly insights, memory | purpose-built mental-health companion | conversation and longitudinal growth | Direct therapy-adjacent competition must be avoided |
| Replika | AI companion | AI friend to do life with | avatar, memory, relationship, chat | friend/partner | emotional bond | Garden’s relationship boundary is strategic |
| Pi | general AI companion | Emotionally intelligent help to think and plan | conversation, personalization, memory | companion/assistant | repeated chat | General AI is a free/low-friction substitute |
| Character.AI | roleplay companion | Lifelike characters and social sandbox | characters, memory/context, roleplay | persona | immersive conversation | Emotional immersion creates safety risk |
| Reflect | AI PKM | Intellectual thought partner | linked notes, AI, voice, search | knowledge assistant | knowledge capture | Use object ideas, not PKM overhead |
| Capacities | PKM | A studio for the mind | objects, links, daily notes, AI | knowledge assistant | long-term knowledge system | Garden must remain lighter and life-oriented |
| General AI chat | universal substitute | Ask anything, build your own workflow | conversation, files, memory, tools | flexible | platform usage | Garden needs executable constraints and dedicated UX |

## Closest strategic cluster

1. Rosebud  
2. Reflection  
3. Mindsera  
4. Liven  
5. Headspace Ebb  
6. Stoic  
7. Finch

## Garden anti-reference cluster

- Habitica: penalty and gamification.
- Replika: relational dependency.
- Bearable/Exist: correlation overreach.
- employer Ebb deployments: institutional data-governance risk.
- generic PKM: capture and organization burden.

## White-space scorecard

| Dimension | Common market state | Garden target |
|---|---|---|
| Core object | entry, habit, mood, task, chat | chosen practice in context |
| AI role | coach, companion, interpreter | bounded co-interpreter |
| Success | engagement, streak, score, disclosure | real-life action, adaptation, completion |
| Reflection | open-ended chat/journal | bounded loop with closure |
| Memory | more context = better | governed, visible, expiring |
| Measurement | daily score/trends | optional, purpose-bound |
| Motivation | rewards/reminders | chosen support |
| Problem model | individual coping | multilevel action |
| Social | feed, friends, coach access | narrow bridges |
| Privacy | policy and encryption claims | architecture and user control |
| Product relationship | always there | designed to become less necessary |
