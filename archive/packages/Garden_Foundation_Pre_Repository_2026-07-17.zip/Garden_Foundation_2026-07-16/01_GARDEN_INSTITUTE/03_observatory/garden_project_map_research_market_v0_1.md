# Garden Project Map, Research Program & Market Observatory

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Статус:** первый собранный инвентарь и исследовательская карта  
**Концепция:** «Маленькие ритуалы. Большой сад»

---

# 1. Что изменилось в архитектуре Garden

После обнаружения Flourishing App стало ясно, что шести контуров Garden недостаточно.

Garden должен иметь не только:

1. Garden Bible;
2. Garden Language;
3. Garden Institute;
4. Garden Product;
5. Garden Decisions;
6. Garden Chronicle;

но и отдельный седьмой контур:

## 7. Garden Observatory — рынок и внешняя среда

**Отвечает на вопросы:**

- какие продукты уже решают похожие задачи;
- какие новые категории возникают;
- какие продуктовые паттерны становятся стандартом;
- какие научные идеи превращаются в коммерческие продукты;
- где конкуренты действительно создают ценность;
- где рынок создаёт вред, давление, зависимость или псевдонаучные обещания;
- какие свободные пространства остаются для Garden;
- какие изменения рынка могут потребовать пересмотра стратегии.

Garden Observatory не определяет, каким должен быть Garden.  
Он помогает видеть, где находится проект и какие альтернативы уже существуют.

---

# 2. Обновлённая структура проекта

```text
garden/
├── README.md
├── CURRENT_STATE.md
├── MAP.md
│
├── 00_bible/
├── 01_language/
│
├── 02_institute/
│   ├── research_operating_model.md
│   ├── research_program.md
│   ├── research_map.md
│   ├── question_registry.md
│   ├── evidence_registry.md
│   ├── theory_map.md
│   ├── research/
│   ├── experiments/
│   ├── findings/
│   ├── critiques/
│   └── research_backlog.md
│
├── 03_product/
├── 04_decisions/
├── 05_chronicle/
│
├── 06_sources/
│   ├── README.md
│   ├── source_registry.md
│   ├── bibliography.md
│   ├── evidence_cards/
│   ├── measures_and_scales/
│   ├── licenses_and_usage/
│   ├── papers/
│   ├── books/
│   ├── institutional_sources/
│   ├── market_sources/
│   ├── user_evidence/
│   └── raw_materials/
│
├── 07_observatory/
│   ├── README.md
│   ├── market_definition.md
│   ├── category_map.md
│   ├── competitor_registry.md
│   ├── feature_matrix.md
│   ├── positioning_map.md
│   ├── business_models.md
│   ├── market_signals.md
│   ├── design_patterns.md
│   ├── risk_patterns.md
│   ├── competitors/
│   ├── adjacent_products/
│   ├── research_translation_platforms/
│   └── quarterly_snapshots/
│
├── 08_seeds/
└── 99_archive/
```

---

# 3. Важное разделение: Institute, Sources и Observatory

## Garden Institute

Формулирует исследовательские вопросы, анализирует доказательства и превращает знания в проверяемые продуктовые гипотезы.

## Garden Sources

Хранит первичные материалы и карточки источников:

- статьи;
- систематические обзоры;
- книги;
- шкалы;
- данные;
- юридические условия использования;
- интервью;
- отзывы пользователей;
- страницы продуктов.

## Garden Observatory

Изучает рынок как самостоятельный объект:

- конкурентов;
- продуктовые категории;
- позиционирование;
- механики;
- бизнес-модели;
- интерфейсные паттерны;
- динамику рынка;
- провалы и риски.

**Правило:** страница конкурента не является научным доказательством.  
Научная статья не является доказательством наличия рынка.  
Отзыв пользователя не является универсальной истиной, но может показать реальную боль.

---

# 4. Инвентарь найденных материалов Garden

## 4.1. Найдено в виде отдельных файлов

| ID | Документ | Текущий статус | Целевое расположение |
|---|---|---|---|
| SYS-001 | `garden_knowledge_system_v1.md` | рабочая архитектура | корень + `00_governance/` или `README` |
| ROM-001 | `research_operating_model.md` | действующая первая версия | `02_institute/` |
| R-001 | `research_01_why_people_change.md` | первая рабочая версия | `02_institute/research/` |
| R-002 | `research_02_care_vs_control.md` | первая рабочая версия | `02_institute/research/` |
| R-003 | `research_03_why_nature_calms_us.md` | первая рабочая версия | `02_institute/research/` |
| ALPHA-D1 | `garden_alpha_blueprint_v1.md` | exploratory draft | `03_product/alpha/drafts/` |

## 4.2. Известно из предыдущих решений, но отдельный файл пока не найден

| Материал | Что известно | Действие |
|---|---|---|
| Garden Bible / версия 4 | существовал собранный канон: декларация, Anti-Goals, этика, принципы, продуктовая рамка | восстановить как набор документов, не одним монолитом |
| Исследование 04 — язык внутреннего диалога | его выводы использовались в Garden Language и CARE | восстановить отдельный файл R-004 |
| Garden Declaration | использовалась как часть актуального канона | восстановить |
| Anti-Goals | сформированы и цитировались | восстановить |
| Ethics Constitution | сформирована как обязательный слой | восстановить |
| GDR-001–003 | упоминались как существующие | найти или восстановить по истории обсуждений |
| Garden Language | есть принципы, режимы тона, CARE и антипримеры | собрать в самостоятельную систему |
| Garden Chronicle | создан только формат и первая запись | начать реальную хронологию с истоков проекта |
| Mycorrhiza Engine | концепция существует, но остаётся гипотезой | хранить в Product / hypotheses |
| Garden Pause | проработана как отдельная механика | восстановить отдельную карточку механики |
| Product model | деревья, ритуалы, сезоны, связи, садовник | собрать и разделить канон и гипотезы |

## 4.3. Статус Alpha

`garden_alpha_blueprint_v1.md` сохраняется как сильная продуктовая гипотеза, но не является утверждённым следующим этапом.

`GDR-004` внутри него имеет статус:

```text
proposed
```

---

# 5. Текущее состояние Garden по контурам

## Garden Bible

**Готовность:** фрагментарно высокая, структурно не собрана.

Уже определены:

- «Маленькие ритуалы. Большой сад»;
- помощь человеку в понимании себя без лишения свободы;
- автономная забота;
- маленькая версия как полноценное действие;
- право адаптировать, заменить или отпустить ритуал;
- Garden ведёт в жизнь, а не удерживает внутри;
- отказ от стыда, серий и наказания;
- сад как модель нелинейной живой системы;
- запрет на подмену терапии;
- запрет на диагностирование и ложную причинность;
- успех как перенос способности понимать себя за пределы продукта.

Необходимо:

- отделить канонические решения от гипотез;
- восстановить доказательную связь каждого принципа;
- собрать версию Bible 1.0 в новой архитектуре.

## Garden Language

**Готовность:** есть сильное ядро, нет корпуса и правил эксплуатации.

Уже определены:

- тёплый, спокойный, прямой и минималистичный режимы;
- доброжелательная требовательность;
- CARE;
- язык факта, а не приговора личности;
- выбор формата поддержки;
- антистыдовый возврат;
- право не обсуждать;
- метафора должна исчезать в серьёзных ситуациях.

Необходимо:

- восстановить R-004;
- исследовать язык поддержки, агентность, стыд и культурные различия;
- создать словарь;
- собрать 100–200 тестовых диалогов;
- сделать language lint / чек-лист;
- проверить язык на пользователях.

## Garden Institute

**Готовность:** создана операционная модель, начат исследовательский корпус.

Уже есть:

- Research Operating Model;
- иерархия доказательств;
- Productization Gate;
- двухконтурная оценка пользы и эмоциональной цены;
- R-001, R-002, R-003;
- частично R-004.

Необходимо:

- полная исследовательская программа;
- evidence registry;
- карта теоретиков;
- критический корпус;
- методика обновления исследований;
- обязательные исследования до Alpha.

## Garden Product

**Готовность:** сильный концептуальный слой, преждевременно детализированная Alpha.

Уже есть:

- модель сада;
- ритуал;
- маленькая версия;
- сезоны;
- адаптация;
- Garden Pause;
- Mycorrhiza Engine как гипотеза;
- AI Gardener;
- черновой Alpha Blueprint.

Необходимо:

- пересобрать product model после исследований;
- сформировать несколько конкурирующих core experience;
- не считать текущую Alpha единственным вариантом.

## Garden Decisions

**Готовность:** система описана, реестр не собран.

Необходимо:

- найти или восстановить GDR-001–003;
- создать decision index;
- проверить реальный статус всех решений;
- не присваивать `accepted` без явного утверждения.

## Garden Chronicle

**Готовность:** есть правило, нет полной истории.

Необходимо:

- восстановить хронологию возникновения Garden;
- собрать ключевые формулировки;
- сохранить повороты и отброшенные ветки;
- связать Chronicle с GDR и версиями Bible.

## Garden Observatory

**Готовность:** создаётся сейчас.

Первый объект:

```text
OBS-001 — Flourishing App
```

---

# 6. Предварительное определение рынка Garden

Garden находится не в одном существующем рынке, а на пересечении нескольких категорий:

1. habit and routine apps;
2. self-care and wellness apps;
3. journaling and reflection;
4. AI companions and AI coaches;
5. mental wellbeing tools;
6. purpose and intentional living;
7. positive psychology and flourishing;
8. quantified self and personal analytics;
9. digital gardens / second-brain metaphors;
10. research translation platforms.

Поэтому прямой поиск «главного конкурента Garden» даст ложный результат.  
Нужно изучать **конкурирующие способы решения одной человеческой задачи**.

Рабочая задача Garden:

> Помочь человеку замечать, какая забота и какое действие ему сейчас действительно нужны, поддерживать связь с важными направлениями жизни и учиться понимать собственные закономерности без давления и зависимости от продукта.

---

# 7. Карта конкурентных категорий

## Категория A. Научная модель хорошей жизни

Примеры:

- Flourishing App;
- Human Flourishing Program;
- Greater Good in Action;
- VIA Character Strengths;
- positive psychology intervention platforms.

Что изучаем:

- как определяется хорошая жизнь;
- какие сферы считаются универсальными;
- как научные модели переводятся в интерфейс;
- не превращается ли жизнь в оценочную шкалу;
- кто получает право определять норму.

## Категория B. Намерение, смысл и жизненные направления

Примеры:

- Tangle;
- purpose discovery products;
- coaching and life-wheel systems.

Что изучаем:

- ежедневные намерения;
- связь действия с идентичностью и смыслом;
- социальную поддержку;
- риск навязывания «правильной» цели;
- роль AI в интерпретации жизненного назначения.

## Категория C. Ритуалы, привычки и поведение

Примеры:

- Fabulous;
- Habitify;
- Streaks;
- Coach.me;
- Tiny Habits-like products.

Что изучаем:

- формирование действия;
- якоря и контекст;
- маленькие шаги;
- streaks;
- уведомления;
- внешний контроль;
- возврат после пропуска.

## Категория D. Геймифицированная забота

Примеры:

- Finch;
- Habitica;
- self-care pets.

Что изучаем:

- мотивацию через персонажа;
- эмоциональную привязанность;
- выполнение ради аватара;
- коллекционирование;
- наказание за отсутствие;
- инфантилизацию;
- пользу для людей с низким ресурсом.

## Категория E. Journaling и AI reflection

Примеры:

- Rosebud;
- Mindsera;
- Reflection;
- Stoic;
- Day One / Apple Journal / Pixel Journal.

Что изучаем:

- диалоговую рефлексию;
- поиск паттернов;
- еженедельные инсайты;
- эмоциональные оценки;
- риск ложной интерпретации;
- зависимость от мгновенного ответа;
- приватность;
- перенос понимания пользователю.

## Категория F. AI mental wellbeing

Примеры:

- Wysa;
- Woebot;
- Youper;
- Flourish Science;
- KRIYA как исследовательский прототип.

Что изучаем:

- границы клинического и неклинического;
- кризисные сценарии;
- модели безопасности;
- роль человека;
- доказательства эффективности;
- медицинские заявления;
- зависимость и замещение помощи.

## Категория G. Спокойствие, внимание и восстановление

Примеры:

- Calm;
- Headspace;
- Endel;
- breathing and mindfulness apps.

Что изучаем:

- короткие паузы;
- сенсорные интерфейсы;
- восстановление внимания;
- экран как переход, а не место назначения;
- подписочные модели удержания.

## Категория H. Quantified self и персональная аналитика

Примеры:

- Daylio;
- Exist;
- Gyroscope;
- health dashboards;
- contextual AI journaling.

Что изучаем:

- связь событий и состояний;
- корреляции;
- влияние визуализации на самовосприятие;
- тревожное самонаблюдение;
- ложную причинность;
- объяснимость.

---

# 8. Первый конкурентный реестр

| ID | Продукт | Категория | Близость к Garden | Главный вопрос |
|---|---|---|---|---|
| OBS-001 | Flourishing App | research translation / wellbeing framework | высокая концептуальная, низкая механическая | кто определяет хорошую жизнь и как исследование становится практикой |
| OBS-002 | Tangle | purpose / intentional living / social | высокая | может ли технология поддерживать смысл, не присваивая его |
| OBS-003 | Rosebud | AI journal + habits + insights | высокая | как AI соединяет записи, цели и паттерны |
| OBS-004 | Mindsera | AI reflection and cognitive analysis | высокая | где заканчивается рефлексия и начинается зависимость от интерпретации |
| OBS-005 | Reflection | AI journal + coach | высокая | как устроена guided reflection и профессиональная интеграция |
| OBS-006 | Finch | gamified self-care pet | высокая как анти-референс и сегмент | помогает ли забота о персонаже заботиться о себе |
| OBS-007 | Fabulous | behavior change and routines | средняя | как продукт превращает поведенческую науку в давление |
| OBS-008 | Stoic | journal, routines, mood and philosophy | средняя | как философия становится ежедневным продуктовым ритуалом |
| OBS-009 | Wysa | AI mental wellbeing | средняя, важна для safety | как строятся границы, безопасность и гибрид с человеком |
| OBS-010 | Flourish Science | generative AI wellbeing interventions | высокая исследовательская | какие эффекты может дать персонализированная AI-поддержка |
| OBS-011 | KRIYA | research prototype | очень высокая исследовательская | как перейти от оценки данных к совместной интерпретации |
| OBS-012 | Apple / Pixel Journal | contextual journaling | средняя, платформенная угроза | как системные платформы используют фото, события и сенсоры |

---

# 9. OBS-001 — Flourishing App

## 9.1. Что это

Flourishing позиционируется как публичная платформа, которая переводит и распространяет идеи Human Flourishing Program Гарвардского университета.

Она:

- объясняет модель человеческого flourishing;
- организует содержание по шести сферам;
- предлагает исследовательски обоснованные упражнения;
- предоставляет доступ к измерительным инструментам;
- подчёркивает образовательный, а не клинический характер;
- рассматривает будущий мобильный формат.

По текущей версии это скорее **research translation hub**, чем полноценный персональный wellbeing-продукт.

## 9.2. Шесть сфер

1. Happiness & Life Satisfaction.
2. Mental & Physical Health.
3. Meaning & Purpose.
4. Character & Virtue.
5. Close Social Relationships.
6. Financial & Material Stability.

Это важный референс для Garden, потому что он тоже рассматривает жизнь как взаимосвязанную систему, а не один показатель.

## 9.3. Продуктовые элементы

- объяснение доменов;
- рефлексивные вопросы;
- Flourishing Measure;
- Meaning Measure;
- Gratitude Measure;
- Character Strengths;
- упражнения gratitude, savoring и best possible self;
- план расширения в mobile experience.

## 9.4. Что у Flourishing сильнее Garden сейчас

- ясно обозначенный научный корень;
- видимая связь с институциональной исследовательской программой;
- валидированные измерительные инструменты;
- структурированный перевод науки для широкой аудитории;
- готовая модель целостного благополучия;
- аккуратное разграничение образовательного и клинического.

## 9.5. Что Garden не должен копировать автоматически

### Нормативность

Формула «все стороны жизни хороши» предполагает образ хорошей жизни.  
Garden должен исследовать, может ли он вообще оценивать жизнь человека по универсальной модели.

### Character & Virtue

Оценка характера и добродетели может незаметно превратить продукт заботы в моральный экзамен.

### Общий score

Даже если авторы рекомендуют смотреть на домены отдельно, пользовательский интерфейс легко превращает сложную жизнь в рейтинг.

### Best Possible Self

Практика может вдохновлять, но у части людей усиливает разрыв между реальным и идеальным собой.

### Универсальные домены

Их кросс-культурная применимость требует отдельного анализа.

### Использование шкал

Harvard Flourishing Measure имеет условия лицензирования: некоммерческое использование доступно по CC BY-NC 4.0 с атрибуцией, а коммерческое использование управляется отдельно. Garden не должен встроить шкалу до юридической и методологической проверки.

## 9.6. Чем Garden может отличаться

Flourishing отвечает:

> Из каких областей складывается хорошая жизнь и как их измерять?

Garden потенциально отвечает:

> Как человеку заметить, что сейчас происходит в его собственной жизни, и выбрать следующий заботливый шаг, не передавая продукту право определять, какой должна быть его жизнь?

Это пока гипотеза позиционирования, а не окончательный вывод.

## 9.7. Статус конкурентности

```text
Прямой конкурент сейчас: нет.
Концептуальный сосед: да.
Источник и research benchmark: да.
Потенциальный будущий конкурент: да, если появится персонализированный мобильный цикл.
```

## 9.8. Новые исследовательские вопросы

- Что такое flourishing и имеет ли Garden право использовать эту рамку?
- Есть ли универсальные сферы хорошей жизни?
- Как измерение благополучия меняет отношение человека к себе?
- Может ли целостная модель поддерживать свободу, а не нормализацию?
- Нужны ли Garden деревья, заданные системой, или человек должен создавать собственные?
- Нужно ли вообще давать оценку всему саду?
- Как отличить рефлексию от самоаудита?
- Как учитывать материальные условия и не сводить всё к индивидуальным ритуалам?
- Как Garden будет работать с характером, смыслом, верой и отношениями, не становясь моральным авторитетом?

## 9.9. Решение для Garden

Flourishing App входит сразу в три реестра:

```text
07_observatory/research_translation_platforms/
06_sources/institutional_sources/
02_institute/question_registry/
```

---

# 10. Исследовательская программа Garden Institute

## Направление A. Что такое хорошая жизнь

Вопросы:

- flourishing;
- wellbeing;
- eudaimonia;
- happiness;
- meaning;
- capabilities;
- quality of life;
- культурная и нормативная критика.

Необходимое исследование:

```text
R-005 — Кто определяет хорошую жизнь?
```

## Направление B. Ритуал, привычка и изменение

Вопросы:

- ритуал против привычки;
- автоматизация;
- смысл;
- повторение;
- контекст;
- пропуск;
- восстановление;
- идентичность.

Необходимое исследование:

```text
R-006 — Чем ритуал отличается от привычки и задачи?
```

## Направление C. Рефлексия и понимание себя

Вопросы:

- journaling;
- expressive writing;
- self-reflection;
- insight;
- rumination;
- narrative identity;
- sensemaking;
- metacognition.

Необходимое исследование:

```text
R-007 — Когда рефлексия помогает, а когда превращается в руминацию?
```

## Направление D. Забота, требовательность и агентность

Продолжение R-002:

- self-compassion;
- autonomy;
- accountability;
- supportive confrontation;
- shame;
- self-criticism;
- learned helplessness;
- psychological reactance.

Необходимое исследование:

```text
R-008 — Как поддерживать действие, не присваивая управление?
```

## Направление E. Язык

- внутренний диалог;
- motivational interviewing;
- nonviolent communication;
- therapeutic alliance без имитации терапии;
- tone adaptation;
- cultural pragmatics;
- gender and infantilization;
- uncertainty language.

Необходимое исследование:

```text
R-009 — Какой язык сохраняет взрослую субъектность человека?
```

## Направление F. AI и совместная интерпретация

- AI journaling;
- co-interpretation;
- explainability;
- sycophancy;
- emotional dependency;
- anthropomorphism;
- epistemic authority;
- memory;
- calibrated uncertainty.

Необходимое исследование:

```text
R-010 — Может ли AI помогать человеку понимать себя, не становясь главным толкователем?
```

## Направление G. Измерение и самонаблюдение

- self-tracking;
- measurement reactivity;
- Goodhart's law;
- mood scoring;
- dashboards;
- quantified self;
- false causality;
- missing data;
- anxiety from tracking.

Необходимое исследование:

```text
R-011 — Что измерение делает с человеком?
```

## Направление H. Приватность и безопасность

- sensitive personal data;
- journal privacy;
- third-party AI processing;
- local/on-device processing;
- deletion and export;
- crisis boundaries;
- mental health regulation;
- consent;
- vulnerable users.

Необходимое исследование:

```text
R-012 — Какая архитектура данных допустима для Garden?
```

## Направление I. Природа, сезонность и визуальная метафора

Продолжение R-003:

- digital nature;
- soft fascination;
- seasonality;
- ecological metaphors;
- restorative environments;
- cultural attitudes to nature;
- accessibility.

Необходимое исследование:

```text
R-013 — Когда садовая метафора помогает, а когда искажает опыт?
```

## Направление J. Социальность и отношения

- support;
- accountability partners;
- social comparison;
- privacy boundaries;
- collective rituals;
- community wellbeing;
- loneliness;
- belonging.

Необходимое исследование:

```text
R-014 — Нужны ли Garden другие люди?
```

## Направление K. Материальные и системные условия

- capability approach;
- social determinants;
- scarcity;
- work conditions;
- disability;
- caregiving;
- inequality;
- limits of individual self-help.

Необходимое исследование:

```text
R-015 — Где заканчивается личный ритуал и начинается проблема среды?
```

## Направление L. Рынок и продуктовая категория

Необходимое исследование:

```text
R-016 — Market & Competitor Landscape of Garden
```

---

# 11. Что обязательно исследовать до Alpha

Приоритет P0:

1. `R-005` — хорошая жизнь и нормативность;
2. `R-006` — ритуал против привычки;
3. `R-007` — рефлексия против руминации;
4. `R-009` — язык взрослой субъектности;
5. `R-010` — AI, интерпретация и зависимость;
6. `R-011` — влияние измерения;
7. `R-012` — приватность и безопасность;
8. `R-016` — рынок и конкуренты.

Приоритет P1:

9. `R-013` — границы садовой метафоры;
10. `R-014` — социальность;
11. `R-015` — системные ограничения;
12. кросс-культурная применимость модели.

R-001–R-003 сохраняются, но после появления source registry должны пройти аудит источников.

---

# 12. Система источников Garden

## 12.1. Уровни источников

### S1. Первичные институциональные и научные источники

- peer-reviewed papers;
- официальные исследовательские программы;
- валидированные шкалы;
- протоколы исследований;
- наборы данных;
- официальные регуляторные документы.

### S2. Систематические обзоры и метаанализы

Используются для оценки общего состояния доказательств.

### S3. Теоретические и философские работы

Нужны для понятий, нормативных допущений и критики, но не доказывают эффективность функции.

### S4. Качественные исследования

Интервью, дневниковые исследования, ethnography и HCI.

### S5. Рыночные источники

- официальные сайты;
- App Store / Google Play;
- privacy policy;
- terms;
- pricing;
- release notes;
- company blogs;
- investor materials;
- вакансии;
- патенты.

### S6. Пользовательские свидетельства

- отзывы;
- Reddit;
- интервью;
- видеообзоры;
- support communities;
- удалённые отзывы и жалобы.

### S7. Журналистские и критические источники

Нужны для независимой проверки заявлений и обнаружения рисков.

### S8. Garden Evidence

- наши интервью;
- прототипные тесты;
- дневники;
- эксперименты;
- продуктовые данные;
- incident reports.

---

# 13. Карточка источника

Каждый источник получает ID и карточку:

```yaml
source_id: SRC-0001
title:
authors:
year:
source_type:
domain:
url_or_location:
access_date:
peer_reviewed:
study_design:
sample:
population:
country:
main_claim:
what_the_source_actually_supports:
what_it_does_not_support:
limitations:
conflicts_of_interest:
replication_status:
evidence_quality:
relevance_to_garden:
possible_product_implications:
ethical_or_legal_notes:
license:
related_research:
```

---

# 14. Правила работы с источниками

1. Не использовать сайт конкурента как доказательство научной эффективности.
2. Не использовать одну статью как основание для продуктового канона.
3. Проверять, кто финансировал исследование.
4. Отдельно отмечать исследования, выполненные создателями продукта.
5. Проверять выборку, страну, возраст и контекст.
6. Не переносить клинические выводы на здоровую популяцию автоматически.
7. Не переносить групповой средний эффект на конкретного человека.
8. Различать валидность измерения и полезность показа его результата пользователю.
9. Хранить отрицательные и неоднозначные результаты.
10. Проверять лицензию шкал до продуктового использования.
11. Не смешивать философское утверждение с эмпирическим.
12. Проводить source audit перед обновлением Bible.

---

# 15. Стартовый корпус источников

## Human flourishing

- Harvard Human Flourishing Program.
- Tyler J. VanderWeele, *On the Promotion of Human Flourishing*.
- Global Flourishing Study.
- Flourishing Measure и психометрические работы.
- Comprehensive Measure of Meaning.
- Capability Approach: Amartya Sen, Martha Nussbaum.
- критика positive psychology и универсальных моделей wellbeing.

## Behavior change

- Self-Determination Theory.
- COM-B / Behaviour Change Wheel.
- implementation intentions.
- habit formation research.
- identity-based behavior.
- self-efficacy.
- ecological and contextual behavior models.

## Self-compassion and shame

- Kristin Neff.
- Paul Gilbert / Compassion Focused Therapy.
- systematic reviews of self-compassion interventions.
- research on self-criticism, shame and motivation.

## Reflection and journaling

- expressive writing research;
- reflective practice;
- narrative identity;
- rumination vs reflection;
- metacognition;
- HCI research on digital journaling.

## AI wellbeing and reflection

- KRIYA;
- MindScape;
- trials of generative AI wellbeing interventions;
- research on sycophancy and emotional reliance;
- privacy audits of mental health apps;
- AI companion safety and anthropomorphism.

## Nature and restoration

- Attention Restoration Theory;
- Stress Reduction Theory;
- systematic reviews of nature exposure;
- digital and virtual nature;
- restorative environment measurement.

## Ethics and power

- ethics of care;
- Foucault and normalization;
- persuasive technology;
- autonomy and dark patterns;
- digital wellbeing;
- data dignity and intimate privacy.

---

# 16. Методика конкурентного исследования

Для каждого продукта изучаем девять слоёв.

## 1. Promise

Что продукт обещает изменить в жизни человека?

## 2. Human model

Каким он считает человека:

- ленивым;
- нуждающимся в мотивации;
- уязвимым;
- рациональным;
- развивающимся;
- нуждающимся в наставнике;
- способным выбирать самостоятельно?

## 3. Core loop

Что пользователь делает снова и снова?

## 4. Motivation architecture

- streak;
- reward;
- guilt;
- identity;
- meaning;
- social support;
- companion attachment;
- curiosity;
- insight.

## 5. Reflection model

Что продукт показывает и кто интерпретирует данные?

## 6. Language

Как продукт говорит после успеха, пропуска и ухудшения?

## 7. Evidence

Какие исследования заявлены и что они реально доказывают?

## 8. Safety and privacy

Какие данные собираются, куда передаются и как удаляются?

## 9. Business model

За что платит пользователь и не конфликтует ли выручка с благополучием?

---

# 17. Артефакты Market & Competitor Research

Результатом R-016 должны стать:

1. market definition;
2. category map;
3. 20–30 competitor cards;
4. feature and mechanism matrix;
5. positioning map;
6. language comparison;
7. evidence claims audit;
8. privacy and safety matrix;
9. business model map;
10. anti-pattern catalog;
11. whitespace opportunities;
12. implications for Garden;
13. quarterly market watch.

---

# 18. Вторая запись Garden Chronicle

## 15 июля 2026 — Flourishing расширяет границы проекта

### Что произошло

Была обнаружена Flourishing App — платформа, переводящая исследования human flourishing в домены, измерения и практики.

### Что мы думали раньше

Garden Institute рассматривался прежде всего как внутренний исследовательский контур продукта.

### Что вызвало сомнение

Рынок уже содержит проекты, которые сами строят публичную исследовательскую инфраструктуру и превращают научные модели хорошей жизни в доступные продукты.

### Как изменилось понимание

Garden нужно исследовать не только отдельные приложения, но и:

- исследовательские программы;
- публичные переводчики науки;
- валидированные шкалы;
- нормативные модели хорошей жизни;
- способы превращения исследований в продукт.

### Последствия

- создаётся Garden Observatory;
- Source Library становится самостоятельной инфраструктурой;
- появляется R-005 о хорошей жизни и нормативности;
- появляется R-016 о рынке и конкурентах;
- Flourishing App получает статус концептуального соседа и research benchmark;
- Alpha остаётся отложенной до завершения обязательных исследований.

---

# 19. Следующий практический порядок

## Пакет 1. Восстановление памяти

- найти и восстановить Bible v4;
- восстановить R-004;
- восстановить GDR-001–003;
- начать полную Chronicle;
- создать source registry.

## Пакет 2. Foundational Research

Провести R-005–R-012.

## Пакет 3. Market Observatory

- полноценно разобрать Flourishing;
- затем Tangle;
- затем Rosebud, Mindsera и Reflection;
- затем Finch и Fabulous как альтернативные модели мотивации;
- затем Wysa и AI safety;
- сформировать карту категории.

## Пакет 4. Product Synthesis

После исследований сравнить минимум три концепции Garden:

1. ritual-first;
2. reflection-first;
3. whole-life garden / flourishing-first.

Только затем принимать решение о формате Alpha.

---

# 20. Ближайший документ

Следующий основной документ:

```text
R-005_what_is_a_good_life_and_who_decides.md
```

Параллельный документ Observatory:

```text
OBS-001_flourishing_app_deep_dive.md
```

Они должны делаться вместе: первое исследует научную и философскую основу, второе — то, как эта основа уже превращена в продукт.
