# Garden Market Thesis and Alpha Wedge

**Версия:** 0.1  
**Статус:** `proposed`

---

## 1. Market thesis

The market does not need another product whose main promise is:

> Write more, reveal more, track more, and let AI understand you better.

A plausible unmet need is:

> Help me turn what matters into a living practice without making me submit to a tracker, a coach, an avatar or a permanent psychological profile.

---

## 2. Category

### Internal category

**Agency-preserving personal sensemaking and practice system**

### User-facing category

**Система осмысления и личной практики**

### Short descriptor

**От понимания — к бережному действию.**

---

## 3. Alpha target situation

The user:

- has a current important direction or recurring issue;
- has already thought about it;
- does not need a generic article;
- wants a small real-world form;
- has failed to maintain rigid trackers;
- wants support without pressure;
- values privacy.

---

## 4. Alpha job

> «Помоги мне выбрать одну живую практику для того, что важно сейчас, встроить её в реальные условия и честно менять без чувства провала».

---

## 5. Alpha promise

> Garden помогает понять ситуацию, выбрать небольшую практику и вернуться к ней в согласованное время. Без streaks, оценок и бесконечного AI-чата.

---

## 6. Alpha flow

1. Current Direction.
2. Fact / need / context.
3. Practice or another action.
4. Meaningful minimum.
5. Chosen Support Contract.
6. Offline action.
7. Bounded Reflection.
8. Continue / Adapt / Pause / Complete / Release.
9. Memory decision.

---

## 7. Required comparator

Garden must be tested against:

- a plain note;
- a normal reminder;
- a generic AI chat;
- a standard habit tracker.

Otherwise the team cannot know whether the system adds value.

---

## 8. Alpha product boundaries

### Included

- one active direction;
- maximum three active practices;
- no social graph;
- no community;
- no passive data;
- no generalized score;
- no clinical claims;
- no immersive dying garden;
- transparent memory;
- export/delete.

### Excluded

- AI friend;
- therapy;
- content library;
- marketplace;
- public profiles;
- B2B;
- wearables;
- full second brain;
- endless journaling;
- automatic psychological insights.

---

## 9. Business model hypothesis

Subscription with a meaningful free/local mode.

Never paywall:

- export;
- deletion;
- privacy;
- access to existing user-authored content.

Paid value:

- bounded AI processing;
- cross-entry user-approved context;
- advanced practice reviews;
- optional voice;
- private sync.

---

## 10. Core validation metrics

- user understands the category;
- real-world action occurs;
- pressure stays low;
- user adapts or completes honestly;
- trust is calibrated;
- Garden adds value beyond generic AI;
- user can continue without Garden;
- willingness to pay after real use.

---

## 11. Kill criteria

Reconsider Garden if:

- users primarily want an AI friend or therapist;
- no-streak design materially reduces action with no compensating benefit;
- generic chat performs equally well;
- users do not understand practice lifecycle;
- safety architecture makes the interaction unusable;
- user value requires total memory or passive sensing;
- subscription depends on increasing emotional reliance;
- product cannot explain itself in one sentence.
