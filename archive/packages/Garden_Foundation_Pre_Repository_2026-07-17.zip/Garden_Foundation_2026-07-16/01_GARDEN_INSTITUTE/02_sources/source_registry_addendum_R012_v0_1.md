# Garden Source Registry — Addendum for R-012

**Версия:** 0.1  
**Дата:** 15 июля 2026

## SRC-PRIV-001 — GDPR

**Regulation (EU) 2016/679.**  
Тип: binding EU regulation  
Качество: C2 / primary legal source  
Статус: current text reviewed

Поддерживает principles, special-category protection, data-subject rights, security, privacy by design/default, DPIA and breach duties.

Требует country/use-case legal interpretation; не является product checklist by itself.

## SRC-PRIV-002 — EDPB data-protection basics

**European Data Protection Board — Data protection basics / lawful processing / sensitive data.**  
Тип: official regulator guidance  
Качество: C2  
Статус: web guidance reviewed

Поддерживает additional protection for health, sexuality, beliefs and other special-category data.

## SRC-PRIV-003 — Data Protection by Design and Default

**EDPB Guidelines 4/2019 on Article 25 GDPR.**  
Тип: official guideline  
Качество: C2  
Статус: official page and guidance reviewed

Поддерживает privacy by design/default, minimization and protected defaults.

## SRC-PRIV-004 — Data-subject rights

**EDPB SME Guide — Respect individuals’ rights.**  
Тип: official web guidance  
Качество: C2  
Статус: reviewed

Поддерживает access, correction, erasure, restriction, portability, objection and automated-decision protections.

## SRC-PRIV-005 — DPIA

**WP29/EDPB-endorsed Guidelines on Data Protection Impact Assessment.**  
Тип: official regulatory guidance  
Качество: C2  
Статус: official index and relevant criteria reviewed

Поддерживает DPIA where processing is likely to create high risks; evaluation/scoring, sensitive data and novel technology are relevant criteria.

## SRC-PRIV-006 — LLM Privacy Risks & Mitigations

**EDPB Support Pool of Experts (2025). AI Privacy Risks & Mitigations — Large Language Models.**  
Тип: practical technical/privacy guidance  
Качество: C2/B1  
Статус: full document sections reviewed

Поддерживает lifecycle data-flow mapping, LLM-specific DPIA risks, sensitive disclosure, improper anonymization, unlawful training use and excessive retention.

The document is practical expert guidance and does not replace a DPIA or binding legal advice.

## SRC-PRIV-007 — NIST Privacy Framework

**NIST Privacy Framework and PF 1.1 materials.**  
Тип: voluntary risk-management framework  
Качество: C2  
Статус: official web material reviewed

Поддерживает management of privacy risk across the full data-processing ecosystem and lifecycle.

## SRC-PRIV-008 — Breach notification

**EDPB Guidelines 9/2022 on personal data breach notification under GDPR.**  
Тип: official guidance  
Качество: C2  
Статус: full relevant sections reviewed

Поддерживает confidentiality, integrity and availability breach categories and risk assessment for sensitive data and vulnerable people.

## SRC-REG-001 — EU AI Act

**Regulation (EU) 2024/1689.**  
Тип: binding EU regulation  
Качество: C2 / primary legal source  
Статус: current official text reviewed

Поддерживает prohibition of certain manipulative/deceptive practices that materially distort informed decisions and cause or are likely to cause significant harm.

Does not by itself determine Garden’s classification.

## SRC-REG-002 — AI Act implementation timeline

**European Commission — AI Act regulatory framework and navigation pages.**  
Тип: official implementation guidance  
Качество: C2  
Статус: updated pages reviewed July 2026

Supports entry into force on 1 August 2024, application of initial rules from 2 February 2025 and the Commission’s current implementation timeline. Re-check before launch because simplification and transitional measures are evolving.

## SRC-REG-003 — FDA digital-health software boundary

**FDA Clinical Decision Support Software guidance and Device Software Functions pages, current 2026.**  
Тип: official US regulatory guidance  
Качество: C2  
Статус: current web pages reviewed

Supports that intended purpose and patient-facing recommendations can affect medical-device oversight.

Not an EU classification source.

## SRC-SEC-001 — OWASP Prompt Injection

**OWASP GenAI Security Project, LLM01:2025 Prompt Injection.**  
Тип: industry security consensus guidance  
Качество: B1  
Статус: official page reviewed

Supports direct/indirect prompt-injection risks including data disclosure and unauthorized actions.

## SRC-SEC-002 — OWASP Sensitive Information Disclosure

**OWASP GenAI Security Project, LLM02:2025.**  
Тип: industry security guidance  
Качество: B1  
Статус: official page reviewed

Supports risks from PII/sensitive content in model inputs, outputs and application context.

System prompts alone are not an adequate control.

## SRC-SEC-003 — OWASP Top 10 for LLM/GenAI 2025

Тип: risk catalogue  
Качество: B1  
Статус: official project reviewed

Used for security threat coverage, not as proof that listed mitigations guarantee safety.

## SRC-SEC-004 — ENISA Securing ML Algorithms

**ENISA (2021). Securing Machine Learning Algorithms.**  
Тип: official cybersecurity taxonomy and review  
Качество: C2/B1  
Статус: official page reviewed

Supports poisoning, adversarial attacks, data exfiltration and ML lifecycle threats.

## SRC-SEC-005 — NIST AI RMF Generative AI Profile

**NIST AI 600-1 (2024).**  
Тип: voluntary risk-management profile  
Качество: C2  
Статус: official publication page reviewed

Supports governance, mapping, measurement and management of GenAI-specific risks.

## SRC-SAFE-001 — WHO AI for Health

**WHO (2021). Ethics and Governance of Artificial Intelligence for Health.**  
Тип: global governance guidance  
Качество: C2/B1  
Статус: official summary reviewed

Supports protecting autonomy, safety, transparency, accountability, inclusiveness and sustainability.

## SRC-SAFE-002 — WHO LMM guidance

**WHO (2024/2025). Ethics and Governance Guidance for Large Multi-Modal Models in Health.**  
Тип: official governance guidance  
Качество: C2/B1  
Статус: official publication pages reviewed

Supports lifecycle governance, stakeholder involvement, risk assessment and caution with generative systems in health contexts.

## SRC-SAFE-003 — WHO caution on health LLMs

**WHO (2023). WHO calls for safe and ethical AI for health.**  
Тип: official departmental statement  
Качество: C2  
Статус: reviewed

Supports caution to protect wellbeing, safety and autonomy before widespread routine use.

## SRC-SAFE-004 — NIMH mental-health technology overview

**NIMH — Technology and the Future of Mental Health Treatment.**  
Тип: official public-health overview  
Качество: C2  
Статус: current page reviewed

Supports potential benefits alongside uncertainty and limited information about effectiveness of many apps.

## New Source Registry fields

```yaml
legal_jurisdiction:
controller_or_processor_role:
article_6_basis:
article_9_condition:
dpia_required_or_recommended:
data_class:
purpose:
provider_retention:
provider_training:
international_transfer:
subprocessors:
prompt_injection_scope:
security_test:
incident_duty:
crisis_use:
child_use:
regulatory_classification:
last_legal_review:
```
