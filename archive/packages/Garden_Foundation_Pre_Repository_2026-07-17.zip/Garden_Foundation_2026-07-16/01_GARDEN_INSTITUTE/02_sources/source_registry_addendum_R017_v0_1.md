# Garden Source Registry — Addendum for R-017

**Версия:** 0.1  
**Дата:** 16 июля 2026

## SRC-UNK-001

**Bilalić, M., McLeod, P., & Gobet, F. (2008).**  
*Inflexibility of Experts—Reality or Myth? Quantifying the Einstellung Effect in Chess Masters.* Cognitive Psychology, 56(2), 73–102.  
DOI: `10.1016/j.cogpsych.2007.02.001`  
Тип: expert problem-solving experiments  
Качество: A2  
Статус: abstract/metadata reviewed

Supports suboptimal familiar solutions impairing discovery of better solutions in chess expertise.

Does not support general expert rigidity across all tasks.

## SRC-UNK-002

**Bilalić, M., McLeod, P., & Gobet, F. (2010).**  
*The Mechanism of the Einstellung Effect.*  
Тип: eye-tracking/problem-solving study  
Качество: A2  
Статус: bibliographic source

Supports attentional capture by familiar solution patterns.

## SRC-UNK-003

**Dane, E. (2010).**  
*Reconsidering the Trade-off Between Expertise and Flexibility: A Cognitive Entrenchment Perspective.* Academy of Management Review, 35(4), 579–603.  
DOI: `10.5465/amr.35.4.zok579`  
Тип: theory review  
Качество: B1  
Статус: abstract reviewed

Supports cognitive entrenchment as a possible cost of stable expert schemas.

## SRC-UNK-004

**Crilly, N. (2015).**  
*Fixation and Creativity in Concept Development: The Attitudes and Practices of Expert Designers.* Design Studies, 38, 54–91.  
DOI: `10.1016/j.destud.2015.01.002`  
Тип: literature synthesis + interviews with 13 professional designers  
Качество: B1/B2  
Статус: full repository text reviewed

Supports fixation as multifaceted and expert practices for addressing it.

## SRC-UNK-005

**Jansson, D. G., & Smith, S. M. (1991).**  
*Design Fixation.* Design Studies, 12(1), 3–11.  
DOI: `10.1016/0142-694X(91)90003-F`  
Тип: classic experimental study  
Качество: A2  
Статус: bibliographic source

Supports example-induced fixation in design tasks.

## SRC-UNK-006

**National Research Council (2000).**  
*How People Learn: How Experts Differ from Novices.*  
Тип: authoritative research synthesis  
Качество: A0/B1  
Статус: official chapter reviewed

Supports experts organizing knowledge around deep principles and meaningful relations rather than only surface features.

## SRC-UNK-007

**Zhu, M., et al. (2022).**  
*Differences in Thinking Flexibility Between Novices and Experts Based on Eye Tracking.*  
PMCID: `PMC9246232`  
Тип: empirical expert–novice study  
Качество: A2  
Статус: full text reviewed

In the studied task, experts allocated attention more effectively; novices ignored some less salient information.

Counters simple novice-superiority assumptions.

## SRC-UNK-008

**Haavold, P. Ø. (2022).**  
*Creativity in Problem Solving: Integrating Two Different Views of Insight.* ZDM Mathematics Education.  
DOI: `10.1007/s11858-021-01304-8`  
Тип: conceptual/research synthesis  
Качество: B1  
Статус: abstract reviewed

Supports interaction between expertise, problem representation and creative process.

## SRC-UNK-009

**Loewenstein, G. (1994).**  
*The Psychology of Curiosity: A Review and Reinterpretation.* Psychological Bulletin, 116(1), 75–98.  
DOI: `10.1037/0033-2909.116.1.75`  
Тип: foundational theoretical review  
Качество: B1  
Статус: full PDF reviewed

Proposes information-gap theory and nonlinear relation between knowledge gaps and curiosity.

## SRC-UNK-010

**Kidd, C., & Hayden, B. Y. (2015).**  
*The Psychology and Neuroscience of Curiosity.* Neuron, 88(3), 449–460.  
DOI: `10.1016/j.neuron.2015.09.010`  
Тип: interdisciplinary review  
Качество: B1  
Статус: abstract reviewed

Supports curiosity as central to information seeking and learning with multiple mechanisms.

## SRC-UNK-011

**Porter, T., et al. (2022).**  
*Predictors and Consequences of Intellectual Humility.* Nature Reviews Psychology, 1, 524–536.  
PMCID: `PMC9244574`  
Тип: review  
Качество: B1  
Статус: full text reviewed

Defines intellectual humility around recognizing knowledge limits and fallibility; synthesizes correlates and consequences.

## SRC-UNK-012

**Zmigrod, L., et al. (2019).**  
*The Psychological Roots of Intellectual Humility.* Personality and Individual Differences, 141, 200–208.  
DOI: `10.1016/j.paid.2019.01.016`  
Тип: empirical study  
Качество: A2  
Статус: abstract reviewed

Supports association between flexible thinking disposition and intellectual humility, independent of measured cognitive ability.

## SRC-UNK-013

**Leary, M. R., et al.**  
*The Psychology of Intellectual Humility.*  
Тип: research-program synthesis  
Качество: B1  
Статус: full report metadata reviewed

Notes benefits, possible downsides and need to distinguish humility from low confidence.

## SRC-UNK-014

**Stanovich, K. E., & Toplak, M. E. (2023).**  
*Actively Open-Minded Thinking and Its Measurement.*  
PMCID: `PMC9966223`  
Тип: measurement/theoretical review  
Качество: B1  
Статус: full text reviewed

Supports willingness to consider alternatives, counterevidence, reflective thought and delayed closure.

## SRC-UNK-015

**Rozenblit, L., & Keil, F. (2002).**  
*The Misunderstood Limits of Folk Science: An Illusion of Explanatory Depth.* Cognitive Science, 26(5), 521–562.  
DOI: `10.1207/S15516709COG2605_1`; PMCID: `PMC3062901`  
Тип: experimental studies  
Качество: A2  
Статус: full text reviewed

Supports overestimation of explanatory understanding for complex causal mechanisms and recalibration after attempted explanation.

## SRC-UNK-016

**Dunning, D. (2011).**  
*The Dunning–Kruger Effect: On Being Ignorant of One’s Own Ignorance.* Advances in Experimental Social Psychology, 44, 247–296.  
DOI: `10.1016/B978-0-12-385522-0.00005-6`  
Тип: review chapter  
Качество: B1  
Статус: full report reviewed

Supports metacognitive difficulty in recognizing some knowledge deficits.

## SRC-UNK-017

**Hofer, G., et al. (2022).**  
*Less-Intelligent and Unaware? Accuracy and Dunning–Kruger Effects.*  
PMCID: `PMC8883889`  
Тип: empirical/methodological analysis  
Качество: A2  
Статус: full text reviewed

Supports caution: some observed Dunning–Kruger patterns can arise from measurement/statistical effects, while accuracy differences still matter.

## SRC-UNK-018

**Edmondson, A. (1999).**  
*Psychological Safety and Learning Behavior in Work Teams.* Administrative Science Quarterly, 44(2), 350–383.  
DOI: `10.2307/2666999`  
Тип: multimethod field study  
Качество: A2  
Статус: full manuscript reviewed

Supports association between team psychological safety and learning behavior.

Transfer to individual app use is indirect.

## SRC-UNK-019

**Sarasvathy, S. D. (2001).**  
*Causation and Effectuation: Toward a Theoretical Shift from Economic Inevitability to Entrepreneurial Contingency.* Academy of Management Review, 26(2), 243–263.  
DOI: `10.5465/amr.2001.4378020`  
Тип: foundational theory based on entrepreneurial expertise research  
Качество: B1  
Статус: bibliographic/summary reviewed

Distinguishes prediction-oriented causation and control-oriented effectuation under uncertainty.

## SRC-UNK-020

**Harms, R., & Schiele, H. (2012).**  
*Antecedents and Consequences of Effectuation and Causation in the International New Venture Process.* Journal of International Entrepreneurship, 10, 95–116.  
DOI: `10.1007/s10843-012-0089-2`  
Тип: protocol analysis  
Качество: A2  
Статус: abstract reviewed

Reports expert entrepreneurs more often using means-driven, affordable-loss and partnership reasoning in hypothetical venture tasks.

## SRC-UNK-021

**Effectuation research program.**  
*Five Principles of Effectuation / Affordable Loss.*  
Тип: theory translation and research program  
Качество: B1/C1  
Статус: official research-community materials reviewed

Use as design inspiration, not a universal decision rule.

## SRC-UNK-022

**Flyvbjerg, B., & Sunstein, C. R. (2016).**  
*The Principle of the Malevolent Hiding Hand; or, the Planning Fallacy Writ Large.*  
arXiv: `1509.01526` / Social Research  
Тип: project-performance analysis  
Качество: B1  
Статус: manuscript reviewed

Argues cost overruns and benefit shortfalls are more common than beneficial hidden-difficulty effects.

## SRC-UNK-023

**Flyvbjerg, B. (2018).**  
*Planning Fallacy or Hiding Hand: Which Is the Better Explanation?*  
arXiv: `1802.09999`  
Тип: empirical/theoretical response using large project dataset  
Качество: B1  
Статус: manuscript reviewed

Reports beneficial Hiding Hand pattern as minority rather than typical case in analyzed projects.

## SRC-UNK-024

**Flyvbjerg, B. (2022).**  
*Top Ten Behavioral Biases in Project Management.*  
arXiv: `2202.00125`  
Тип: research overview  
Качество: B1/C1  
Статус: abstract reviewed

Highlights optimism bias, planning fallacy, overconfidence, uniqueness and base-rate neglect.

## SRC-UNK-025

**Ballantyne, N. (2019).**  
*Epistemic Trespassing.* Mind, 128(510), 367–395.  
DOI: `10.1093/mind/fzx042`  
Тип: philosophical analysis  
Качество: B1  
Статус: manuscript reviewed

Defines risk of experts judging outside their competence domains.

## SRC-UNK-026

**DiPaolo, J. (2021).**  
*What’s Wrong With Epistemic Trespassing?* Philosophical Studies.  
PMCID: `PMC8131877`  
Тип: philosophical analysis  
Качество: B1  
Статус: full text reviewed

Examines epistemic and moral problems of cross-domain expert judgment.

## SRC-UNK-027

**Chen, L., et al. (2025).**  
*Understanding Design Fixation in Generative AI.*  
arXiv: `2502.05870`  
Тип: framework and experimental study  
Качество: A2/C1 preprint  
Статус: abstract reviewed

Supports emerging concern that generative AI outputs can exhibit and contribute to design fixation.

## SRC-UNK-028

**Wen, C., et al. (2025).**  
*Exploration vs. Fixation: Scaffolding Divergent and Convergent Thinking for Human–AI Co-Creation.*  
arXiv: `2512.18388`  
Тип: HCI system and within-subject study  
Качество: A2/C1 preprint  
Статус: abstract reviewed

Reports structured divergent/convergent stages improved perceived exploration/control compared with linear chat in the studied creative task.

## SRC-UNK-029

**Younie, L. (2017).**  
*Beginner’s Mind.*  
PMCID: `PMC5694793`  
Тип: medical-education reflective article  
Качество: C1  
Статус: full text reviewed

Uses beginner’s mind as openness and curiosity in the medical encounter.

Not empirical validation of shoshin as intervention.

## New Source Registry fields

```yaml
unknown_type:
recognized_unknown:
hard_constraint:
soft_constraint:
domain_expertise_required:
reversibility:
affordable_loss:
feedback_speed:
disconfirming_evidence:
historical_memory_bracketed:
identity_story:
experiment_or_decision:
learning_created:
```
