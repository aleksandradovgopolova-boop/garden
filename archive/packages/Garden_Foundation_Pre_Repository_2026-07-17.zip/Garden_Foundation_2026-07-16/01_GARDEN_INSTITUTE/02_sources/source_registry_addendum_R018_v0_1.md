# Source Registry Addendum — R-018

**Дата:** 16 июля 2026

## Core theoretical sources

- Scannell, L., & Gifford, R. (2010). *Defining place attachment: A tripartite organizing framework.* Journal of Environmental Psychology.
- Lewicka, M. (2011). *Place attachment: How far have we come in the last 40 years?* Journal of Environmental Psychology.
- Proshansky, H. M., Fabian, A. K., & Kaminoff, R. (1983). *Place-identity: Physical world socialization of the self.*
- Williams, D. R., & Vaske, J. J. (2003). *The measurement of place attachment.*
- Kaplan, S. (1995). *The restorative benefits of nature: Toward an integrative framework.*
- Hartig et al. and later systematic reviews of restorative environments.
- Oldenburg, R. *The Great Good Place* — conceptual source for third places.
- Finlay et al. (2019). Third places and health/wellbeing.
- Kim et al. (2025). Discord and virtual third-place design.
- Virtual world place-attachment and gaming studies.
- R-003, R-013, R-014 and R-016 internal Garden research.

## Evidence cautions

- Much place-attachment research is correlational and self-report based.
- Physical-place findings do not automatically transfer to digital products.
- Third-place theory does not validate a private app or community feature.
- Restorative-environment theory does not establish clinical effects for Garden.
- Cozy-game market language is not outcome evidence.

## New fields

```yaml
place_type:
place_meaning_owner:
place_identity_risk:
place_dependence:
customization:
persistence:
reversibility:
absence_effect:
departure_support:
sensory_coherence:
ambient_obligation:
virtual_to_physical_transfer:
```
