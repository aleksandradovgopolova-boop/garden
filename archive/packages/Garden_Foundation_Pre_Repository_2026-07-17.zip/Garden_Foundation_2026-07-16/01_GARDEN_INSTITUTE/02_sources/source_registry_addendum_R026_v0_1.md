# Source Registry Addendum — R-026

**Дата:** 17 июля 2026

## Sources

- ISO 12913-1 — Soundscape: definition and conceptual framework.
- Fan et al. (2024). The effect of exposure to natural sounds on stress reduction: systematic review and meta-analysis.
- Song et al. (2023). Effects of nature sounds on attention and physiological/psychological relaxation.
- Peters et al. (2023). The impact of musicking on emotion regulation: systematic review and meta-analysis.
- Chong et al. (2024). Scoping review on the use of music for emotion regulation.
- Lu & Song (2025). Music-based emotion regulation research review.
- Cheah et al. Background Music and Cognitive Task Performance: systematic review.
- Absar & Guastavino (2008). Usability of non-speech sounds in interfaces.
- Systematic review/meta-analysis of auditory icons, earcons, spearcons and speech.
- W3C WCAG 2.2 — audio control and non-audio alternatives.
- Garden internal R-003, R-004, R-009, R-013, R-022 and R-025.

## Evidence cautions

- soundscape effects are context-dependent;
- natural-sound studies vary in stimuli, duration and outcomes;
- music emotion regulation is not equivalent to music therapy;
- cognitive effects of background music are inconsistent;
- laboratory listening does not reproduce long-term product use;
- pleasant sound can still create fatigue through repetition;
- audio accessibility requires real-user testing.
