# Source Registry Addendum — R-024

**Дата:** 16 июля 2026

## Sources

- Allman et al. (2014). First- and second-order principles of subjective time.
- Merchant et al. (2013). Neural basis of time perception and estimation.
- Wittmann (2009). The inner experience of time.
- Polti et al. (2018). Attention and working memory effects on duration estimation.
- Zacks (2020). Event perception and memory.
- Clewett et al. (2019). Event memories and temporal organization.
- van de Ven et al. (2021). Timing contexts and event segmentation.
- Morrow et al. (2025). Event boundaries and temporal distortions.
- Li et al. (2025). Hierarchical event segmentation in virtual environments.
- Yue et al. (2026). Retrospective duration judgments of naturalistic events.
- Pendleton et al. (2025). Time in mind and mental time travel.
- ACM CHI PLAY: Daily Quests or Daily Pests?
- ACM work on deceptive time pressure and FOMO in games and commerce.

## Evidence cautions

- laboratory duration tasks do not directly describe long-term product experience;
- event segmentation findings do not justify AI-generated life chapters;
- autobiographical memory is reconstructive;
- exact calendar data can remain important for accuracy and accountability;
- game FOMO studies do not prove every seasonal event is harmful;
- product hypotheses around guilt-free absence require direct testing.
