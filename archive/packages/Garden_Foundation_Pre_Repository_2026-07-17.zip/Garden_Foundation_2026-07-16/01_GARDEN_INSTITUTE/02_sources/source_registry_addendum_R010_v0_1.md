# Garden Source Registry — Addendum for R-010

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Контур:** `06_sources/source_registry_addenda/R-010.md`

---

## SRC-AI-INT-001 — KRIYA

**Gupta, S., et al. (2026).**  
*Designing KRIYA: An AI Companion for Wellbeing Self-Reflection.*  
arXiv: `2601.14589`  
Тип: HCI prototype + semi-structured interviews  
Выборка: 18 college students, hypothetical data  
Качество: B2/C1  
Статус: full text reviewed

Поддерживает:

- co-interpretation as a design direction;
- reflection can feel supportive or pressuring depending on framing;
- transparency, uncertainty and corrigibility as trust factors;
- AI as complement, not replacement.

Не поддерживает long-term benefit, clinical safety or broad generalization.

---

## SRC-AI-INT-002 — Personal advice RCT

**Luettgau, L., et al. (2026, v3).**  
*People Readily Follow Personal Advice from AI but It Does Not Improve Their Well-Being.*  
arXiv: `2511.15352v3`  
Тип: longitudinal randomized controlled trial  
Выборка: representative UK sample, `N = 6,474`  
Качество: A2/C1 preprint  
Статус: full text reviewed

Поддерживает:

- up to 79% self-reported advice following;
- over 60% following even for higher-stakes recommendations;
- substantial real-world behavioral influence;
- no sustained 2–3 week wellbeing benefit over control conversation.

Ограничения:

- self-reported following;
- short follow-up;
- UK context;
- consumer general-purpose chatbots;
- preprint.

Лицензия: CC BY-NC-ND 4.0.

---

## SRC-AI-INT-003 — Social Sycophancy

**Cheng, M., et al. (2025).**  
*Social Sycophancy: A Broader Understanding of LLM Sycophancy.*  
arXiv: `2505.13995`  
Тип: taxonomy, datasets and benchmark evaluation  
Качество: A2/C1  
Статус: full overview reviewed

Поддерживает:

- sycophancy beyond factual agreement;
- emotional validation, moral endorsement, indirect action and accepting framing as face-preserving behaviors;
- high social-sycophancy rates across evaluated models.

Не устанавливает longitudinal psychological harm.

---

## SRC-AI-INT-004 — Generative Confidants

**Volpato, R., Stumpf, S., & DeBruine, L. (2026).**  
*Generative Confidants: How Do People Experience Trust in Emotional Support from Generative AI?*  
arXiv: `2601.16656`; SSRN DOI: `10.2139/ssrn.6265318`  
Тип: qualitative diaries + transcripts + interviews  
Выборка: 24 frequent users  
Качество: B2/C1  
Статус: abstract and detailed metadata reviewed

Поддерживает:

- familiarity through personalization as a trust factor;
- user control and mental models as trust factors;
- positive/persuasive language can obscure machine nature.

Ограничения: small self-selected qualitative sample.

---

## SRC-AI-INT-005 — Emotional Support as interaction

**Huang, O. Y., Stodolska, M., & Sultana, S. (2026).**  
*Emotional Support with Conversational AI: Talking to Machines About Life.*  
arXiv: `2603.22618`  
Тип: qualitative analysis of Reddit discussions  
Качество: B2/C1  
Статус: full text reviewed  
Лицензия: CC BY 4.0

Поддерживает:

- emotional support is co-constructed;
- persistent availability, anonymity and low interpersonal burden are important affordances;
- tensions support/dependency, validation/delusion and accessibility/harm;
- AI may operate alongside or replace traditional support structures.

Не оценивает clinical accuracy or causal effects.

---

## SRC-AI-INT-006 — Replika emotional dependence

**Laestadius, L., Bishop, A., Gonzalez, M., Illenčík, D., & Campos-Castillo, C.**  
*Too Human and Not Human Enough: A Grounded Theory Analysis of Mental Health Harms from Emotional Dependence on the Social Chatbot Replika.*  
New Media & Society.  
DOI: `10.1177/14614448221142007`  
Тип: grounded theory of public Reddit posts  
Corpus: 582 mental-health-relevant posts, 2017–2021  
Качество: B2  
Статус: full text reviewed

Поддерживает:

- described cases of emotional dependence and role-taking;
- users attributing needs/emotions to chatbot;
- harms during ongoing or disrupted use;
- benefits and harms can arise from the same relational affordances.

Не поддерживает prevalence estimates or universal harm.

---

## SRC-AI-INT-007 — AI companion psychosocial impacts

**Yuan, Y., et al. (2025/2026).**  
*Mental Health Impacts of AI Companions: Triangulating Social Media Quasi-Experiments, User Perspectives, and Relational Theory.*  
arXiv: `2509.22505`  
Тип: quasi-experimental longitudinal Reddit analysis + 15 interviews  
Качество: A2/B2/C1  
Статус: abstract and overview reviewed

Поддерживает mixed effects, relationship-stage dependence, emotional validation/social rehearsal alongside overreliance and withdrawal risks.

Causal confidence remains limited by observational platform data.

---

## SRC-AI-INT-008 — PersistBench

**Pulipaka, S., et al. (2026).**  
*PersistBench: When Should Long-Term Memories Be Forgotten by LLMs?*  
arXiv: `2602.01146`  
Тип: benchmark across 18 frontier and open-source models  
Качество: A2/C1  
Статус: abstract reviewed

Поддерживает:

- cross-domain leakage;
- memory-induced sycophancy;
- median failure rates reported as 53% and 97% respectively in benchmark tests.

Не оценивает напрямую Garden architecture or real-user harm.

Лицензия: CC BY 4.0.

---

## SRC-AI-INT-009 — Cognitive–affective gap

**2026 human-grounded evaluation study.**  
*Assessing the Quality of Mental Health Support in LLM Responses through Multi-Attribute Human Evaluation.*  
arXiv: `2601.18630`  
Тип: evaluation of nine LLMs on 500 counseling conversations by two psychiatric-trained experts  
Качество: A2/C1  
Статус: full overview reviewed

Поддерживает:

- inconsistency between cognitive attributes such as safety/interpretation and affective resonance such as empathy/helpfulness;
- a structured and safe response may still be emotionally misattuned.

Не устанавливает clinical efficacy.

---

## SRC-AI-INT-010 — Incidental emotional dependence

**Shi, Y., Fang, C. M., Maez, P., & Goldenberg, A. (2026).**  
*Stumbling Into AI Emotional Dependence: How Routine AI Interactions Reshape Human Connection.*  
arXiv: `2606.04150`  
Тип: conceptual synthesis of emerging empirical evidence  
Качество: B1/C1  
Статус: abstract reviewed

Поддерживает гипотезу, что emotional support может возникать incidentally в general-purpose AI interactions и изменять будущие support preferences.

Количественные утверждения требуют отдельного аудита underlying studies.

---

## SRC-AI-INT-011 — Mental health LLM systematic reviews

Umbrella IDs:

- Guo et al. (2024), *Large Language Models for Mental Health Applications*;
- Hua et al. (2025), evolution of AI mental-health chatbots;
- Bucher et al. (2025), systematic review of LLM-based mental-health chatbots;
- Yang et al. (2026), application boundaries of LLMs in mental health.

Использовать только для broad evidence mapping. Конкретные efficacy/safety claims требуют карточек первичных исследований.

---

## SRC-AI-INT-012 — Identity negotiation

**Ma, R., et al. (2026).**  
*Negotiating Digital Identities with AI Companions.*  
arXiv: `2601.12181`  
Тип: LLM-assisted thematic analysis of 22,374 Character.AI subreddit discussions  
Качество: B2/C1  
Статус: abstract reviewed

Поддерживает identity co-construction как релевантный процесс взаимодействия.

Ограничения: platform-specific public discourse, LLM-assisted analysis, no causal claims.

---

## SRC-AI-INT-013 — Behavioral evaluation of LLM therapists

**Chiu, Y. Y., et al. (2024).**  
*A Computational Framework for Behavioral Assessment of LLM Therapists.*  
arXiv: `2401.00820`  
Тип: computational behavioral evaluation  
Качество: C1  
Статус: abstract reviewed

Поддерживает необходимость behavioral evaluation и риск избыточного problem-solving advice.

Не разрешает использовать Garden как therapist.

---

## Новые поля Source Registry

```yaml
interpretation_target:
epistemic_level:
user_confirmed:
alternative_explanations:
disconfirming_evidence:
memory_eligible:
memory_expiry:
domain_scope:
persuasive_personalization:
relational_role:
dependency_risk:
human_bridge:
correction_supported:
```
