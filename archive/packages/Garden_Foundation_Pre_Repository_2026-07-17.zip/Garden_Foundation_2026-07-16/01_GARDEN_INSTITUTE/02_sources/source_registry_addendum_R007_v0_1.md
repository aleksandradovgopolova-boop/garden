# Garden Source Registry — Addendum for R-007

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Контур:** `06_sources/source_registry_addenda/R-007.md`

---

## SRC-REF-001

**Frattaroli, J. (2006).**  
*Experimental Disclosure and Its Moderators: A Meta-Analysis.* Psychological Bulletin, 132(6), 823–865.  
PMID: `17073523`  
DOI: `10.1037/0033-2909.132.6.823`  
Тип: meta-analysis  
Качество: A1  
Статус: abstract reviewed

Поддерживает небольшой средний эффект experimental disclosure и важность модераторов дизайна.

Не поддерживает ежедневный свободный journaling или AI interpretation.

---

## SRC-REF-002

**Gortner, E.-M., Rude, S. S., & Pennebaker, J. W. (2006).**  
*Benefits of Expressive Writing in Lowering Rumination and Depressive Symptoms.* Behavior Therapy, 37(3), 292–303.  
PMID: `16942980`  
DOI: `10.1016/j.beth.2006.01.004`  
Тип: randomized controlled study  
Качество: A2  
Статус: abstract reviewed

Поддерживает пользу expressive writing для определённой depression-vulnerable student subgroup, особенно при высокой suppression.

Не поддерживает универсальный эффект.

---

## SRC-REF-003

**Trapnell, P. D., & Campbell, J. D. (1999).**  
*Private Self-Consciousness and the Five-Factor Model of Personality: Distinguishing Rumination from Reflection.* Journal of Personality and Social Psychology, 76(2), 284–304.  
PMID: `10074710`  
Тип: scale development and correlational studies  
Качество: A2/B1  
Статус: abstract reviewed

Поддерживает различение curiosity-driven reflection и threat/loss-driven rumination.

Не поддерживает диагностику процесса пользователя в реальном времени.

---

## SRC-REF-004

**Harrington, R., & Loffredo, D. A. (2011).**  
*Insight, Rumination, and Self-Reflection as Predictors of Well-Being.* Journal of Psychology, 145(1), 39–57.  
PMID: `21290929`  
Тип: correlational study  
Качество: A2  
Статус: abstract reviewed

Поддерживает различающиеся связи insight, rumination и reflection с subjective wellbeing.

Корреляционный дизайн не устанавливает причинность.

---

## SRC-REF-005

**Nolen-Hoeksema, S., Wisco, B. E., & Lyubomirsky, S. (2008).**  
*Rethinking Rumination.* Perspectives on Psychological Science, 3(5), 400–424.  
PMID: `26158958`  
Тип: authoritative review  
Качество: B1  
Статус: abstract reviewed

Поддерживает связи rumination с более длительным distress, negative thinking, impaired problem solving, reduced instrumental behavior и social difficulties.

---

## SRC-REF-006

**Nolen-Hoeksema, S. (2000).**  
*The Role of Rumination in Depressive Disorders and Mixed Anxiety/Depressive Symptoms.* Journal of Abnormal Psychology.  
PMID: `11016119`  
Тип: longitudinal evidence synthesis  
Качество: A2/B1  
Статус: abstract reviewed

Поддерживает prospective association rumination с depressive symptoms и disorders.

Не поддерживает использование Garden как clinical screening tool.

---

## SRC-REF-007

**Watkins, E. R. (2008).**  
*Constructive and Unconstructive Repetitive Thought.* Psychological Bulletin, 134(2), 163–206.  
PMID: `18298268`  
Тип: integrative review  
Качество: B1  
Статус: full-text source identified / abstract reviewed

Поддерживает процессуальную модель: repeated thought может быть constructive или unconstructive в зависимости от processing mode, context и function.

---

## SRC-REF-008

**Watkins, E. R. (2008).**  
*Processing Mode Causally Influences Emotional Reactivity: Distinct Effects of Abstract Versus Concrete Construal on Emotional Response.* Emotion, 8(3), 364–378.  
PMID: `18540752`  
Тип: experiments  
Качество: A2  
Статус: abstract reviewed

Поддерживает различающиеся эффекты abstract и concrete processing в экспериментальных условиях.

Не поддерживает запрет абстрактного мышления.

---

## SRC-REF-009

**Watkins, E., & Teasdale, J. D. (2004).**  
*Adaptive and Maladaptive Self-Focus in Depression.* Journal of Affective Disorders, 82(1), 1–8.  
PMID: `15465571`  
Тип: experimental clinical study  
Качество: A2  
Статус: abstract reviewed

Поддерживает различие analytic/evaluative и experiential/concrete self-focus.

---

## SRC-REF-010

**Raes, F., Watkins, E. R., Williams, J. M. G., & Hermans, D. (2008).**  
*Non-Ruminative Processing Reduces Overgeneral Autobiographical Memory Retrieval in Students.* Behavior Research and Therapy, 46(6), 748–756.  
PMID: `18456242`  
DOI: `10.1016/j.brat.2008.03.003`  
Тип: experiment  
Качество: A2  
Статус: abstract reviewed

Поддерживает влияние concrete process-focused induction на autobiographical memory specificity в student sample.

---

## SRC-REF-011

**Vassilopoulos, S. P., & Watkins, E. R. (2009).**  
*Adaptive and Maladaptive Self-Focus: A Pilot Extension Study.* Behavior Therapy, 40(2), 181–189.  
PMID: `19433149`  
Тип: randomized pilot experiment  
Качество: A2 with small analogue sample  
Статус: abstract reviewed

Поддерживает снижение global negative self-judgments при experiential self-focus у high-FNE participants.

---

## SRC-REF-012

**Guo, L. (2023).**  
*The Delayed, Durable Effect of Expressive Writing on Depression, Anxiety and Stress: A Meta-Analytic Review of Studies With Long-Term Follow-Ups.* British Journal of Clinical Psychology, 62(1), 272–297.  
PMID: `36536513`  
DOI: `10.1111/bjc.12408`  
Тип: meta-analysis of 31 experiments, N=4012  
Качество: A1  
Статус: abstract reviewed

Поддерживает небольшой delayed average effect в healthy/subclinical samples.

Не поддерживает неограниченный journaling или clinical claims.

---

## SRC-REF-013

**Schueller, S. M., Neary, M., Lai, J., & Epstein, D. A. (2021).**  
*Understanding People’s Use of and Perspectives on Mood-Tracking Apps: Interview Study.* JMIR Mental Health, 8(8), e29368.  
PMID: `34383678`  
DOI: `10.2196/29368`  
Тип: qualitative interview study  
Качество: B2  
Статус: full text available / abstract reviewed

Поддерживает разнообразие целей, преимуществ, ограничений и интерпретаций mood tracking.

---

## SRC-REF-014

**Dubad, M., et al. (2021).**  
*The Clinical Impacts of Mobile Mood-Monitoring in Young People With Mental Health Problems: Systematic Review.*  
PMCID: `PMC8363129`  
Тип: systematic review  
Качество: A1 with limited evidence base  
Статус: abstract reviewed

Поддерживает возможную пользу, но подчёркивает ограниченность доказательств.

---

## SRC-REF-015

**Beltzer, M. L., et al. (2023).**  
*Mental Health Self-Tracking Preferences of Young Adults With Mood and Anxiety Disorders.*  
PMCID: `PMC10589825`  
Тип: qualitative/preference study  
Качество: B2  
Статус: abstract reviewed

Поддерживает необходимость customizable, actionable и privacy-sensitive self-tracking.

Не доказывает эффективность tracking.

---

## SRC-REF-016

**Wright, L. A., et al. (2025).**  
*The User Experience of Ambulatory Assessment and Mood Monitoring in Depression: A Systematic Review and Meta-Synthesis.* npj Digital Medicine, 8, 737.  
Тип: systematic review and qualitative meta-synthesis  
Качество: A1/B2  
Статус: abstract reviewed

Поддерживает mixed user experience: awareness и clinical communication alongside burden, negative focus и usability concerns.

---

## SRC-REF-017

**Wrzus, C., & Neubauer, A. B. (2023).**  
*Ecological Momentary Assessment: A Meta-Analysis on Designs, Samples, and Compliance Across Research Fields.* Assessment, 30, 825–846.  
PMID: `35016567`; PMCID: `PMC9999286`  
Тип: meta-analysis, 496 samples, N=677,536  
Качество: A1  
Статус: full text available / abstract reviewed

Поддерживает dependence of compliance/dropout on protocol design and sample characteristics.

Не является прямым исследованием psychological harm.

---

## SRC-REF-018

**König, L. M., et al. (2022).**  
*A Systematic Review and Meta-Analysis of Studies of Reactivity to Digital In-the-Moment Measurement of Health Behaviour.*  
Тип: systematic review and meta-analysis  
Качество: A1  
Статус: identified; full audit required

Поддерживает необходимость учитывать measurement reactivity; эффекты зависят от поведения и дизайна.

---

## SRC-REF-019

**Stone, A. A., et al. (2026).**  
*Intensive, Repeated Self-Report Measures: Should We Be Concerned About Their Effects on Data Quality?* JMIR mHealth and uHealth.  
Тип: methodological viewpoint with empirical illustrations  
Качество: B1/C1 recent  
Статус: full text available / watch

Поддерживает необходимость учитывать habituation, reactivity, fatigue и changes in response processes.

Не доказывает конкретный harmful effect Garden.

---

## Обновление правил Source Registry

Для исследований repeated assessment добавляются поля:

```yaml
prompt_frequency:
assessment_duration:
participant_burden:
reactivity_measured:
adverse_experience_reported:
missingness_handling:
dropout_rate:
clinical_population:
```
