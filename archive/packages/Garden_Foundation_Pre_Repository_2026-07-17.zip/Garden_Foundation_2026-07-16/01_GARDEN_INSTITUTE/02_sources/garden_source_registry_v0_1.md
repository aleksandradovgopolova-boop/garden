# Garden Source Registry

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Статус:** действующий стартовый реестр; полный аудит продолжается  
**Контур:** `06_sources/source_registry.md`

---

## 1. Назначение

Garden Source Registry — единая точка учёта всех материалов, на которых строятся:

- исследования Garden Institute;
- Философия Garden;
- Голос Garden;
- продуктовые гипотезы;
- метрики и шкалы;
- анализ рынка и конкурентов;
- решения GDR;
- правила безопасности и приватности.

Реестр не является обычной библиографией. Он должен отвечать на пять вопросов:

1. Откуда взялось утверждение?
2. Что источник действительно позволяет утверждать?
3. Чего он не доказывает?
4. Насколько надёжен источник для данного вывода?
5. Можно ли использовать материал в коммерческом продукте?

---

## 2. Базовые правила

1. Страница продукта не считается доказательством его эффективности.
2. Одна статья не становится продуктовым принципом автоматически.
3. Теория объясняет понятия, но не доказывает конкретную механику.
4. Корреляция не доказывает причинность.
5. Средний групповой эффект не определяет, что полезно конкретному человеку.
6. Валидная шкала не обязательно полезна, если показать её результат пользователю.
7. Само измерение способно изменить внимание и поведение.
8. Клинические выводы нельзя автоматически переносить на общий wellbeing-продукт.
9. Preprint используется как ранний сигнал, а не как окончательное доказательство.
10. Лицензия и право на использование проверяются отдельно от научной ценности.
11. Отрицательные и неоднозначные результаты сохраняются.
12. Любой принцип Garden должен иметь traceability: источник → исследование → гипотеза → решение.

---

## 3. Статусы аудита

| Статус | Значение |
|---|---|
| `identified` | источник найден, но не проверен |
| `metadata_verified` | проверены авторы, год, название, публикация и ссылка |
| `abstract_reviewed` | изучены аннотация и основные публичные сведения |
| `full_text_reviewed` | изучен полный текст |
| `evidence_card_complete` | заполнена полная карточка доказательств |
| `license_verified` | отдельно проверены условия использования |
| `superseded` | существует более новая или сильная версия |
| `rejected` | источник нельзя использовать для заявленного вывода |
| `watch` | источник или продукт нужно отслеживать во времени |

---

## 4. Оценка качества

Качество оценивается не «вообще», а относительно конкретного вывода.

| Код | Уровень | Типичные источники |
|---|---|---|
| A1 | высокая доказательная ценность | качественный систематический обзор, метаанализ, крупное продольное исследование |
| A2 | сильный первичный источник | рецензируемое исследование с подходящим дизайном |
| B1 | сильная теоретическая основа | признанная теория, философская работа, методологическая статья |
| B2 | полезное качественное/HCI-исследование | интервью, дневниковое исследование, прототипный тест |
| C1 | ранний научный сигнал | preprint, небольшое пилотное исследование |
| C2 | официальный институциональный источник | описание программы, шкалы, лицензии, методология |
| D1 | рыночный первичный источник | официальный сайт, privacy policy, pricing, App Store |
| D2 | пользовательское свидетельство | отзывы, интервью, сообщества |
| E | слабый или неподходящий источник | маркетинговый пересказ, непроверяемая вторичная публикация |

Код не является итогом автоматически. Например, официальный сайт продукта — хороший источник для цены, но слабый источник для эффективности.

---

# 5. Внутренние источники Garden

| ID | Источник | Роль | Статус |
|---|---|---|---|
| GDN-001 | `garden_knowledge_system_v1.md` | архитектура знания и жизненный цикл документов | full_text_reviewed |
| GDN-002 | `garden_project_map_research_market_v0_1.md` | исследовательская карта и Garden Observatory | full_text_reviewed |
| GDN-003 | `research_operating_model.md` | стандарт работы Garden Institute | full_text_reviewed |
| GDN-004 | `garden_philosophy_v0_1.md` | философское ядро; пока не доказательный источник | full_text_reviewed |
| GDN-005 | `garden_voice_v0_1.md` | черновик голосовой системы; требует исследований | full_text_reviewed |
| GDN-006 | `R-005_what_is_a_good_life_and_who_decides_v0_1.md` | первая синтетическая версия исследования | full_text_reviewed |
| GDN-007 | `OBS-001_flourishing_app_deep_dive_v0_1.md` | первый аудит внешней платформы | full_text_reviewed |
| GDN-008 | `garden_alpha_blueprint_v1.md` | exploratory draft, не утверждённый план | full_text_reviewed |
| GDN-009 | `research_01_why_people_change.md` | ранее созданное исследование; нужен source audit | identified |
| GDN-010 | `research_02_care_vs_control.md` | ранее созданное исследование; нужен source audit | identified |
| GDN-011 | `research_03_why_nature_calms_us.md` | ранее созданное исследование; нужен source audit | identified |
| GDN-012 | `R-004_language_of_inner_dialogue.md` | требует восстановления | identified |

**Правило:** внутренний документ Garden может синтезировать знания, но не заменяет внешний первичный источник.

---

# 6. Стартовый внешний реестр

## A. Human flourishing и хорошая жизнь

### SRC-WB-001

**Источник:** VanderWeele, T. J. (2017). *On the Promotion of Human Flourishing*. PNAS.  
**Тип:** peer-reviewed theoretical and empirical synthesis  
**Качество:** B1/A2 в зависимости от вывода  
**Статус:** abstract_reviewed  
**DOI:** `10.1073/pnas.1702996114`  
**Официальная ссылка:** `https://www.pnas.org/doi/10.1073/pnas.1702996114`  
**Поддерживает:**

- flourishing шире отдельных показателей счастья, здоровья или дохода;
- предложение многомерной модели;
- обоснование доменов и измерений.

**Не поддерживает:**

- обязательность этой модели для каждого продукта;
- полезность общего score пользователю;
- эффективность Flourishing App;
- универсальность любого конкретного UX.

**Связано с:** R-005, OBS-001.

---

### SRC-WB-002

**Источник:** Human Flourishing Program at Harvard — *Our Flourishing Measure*.  
**Тип:** официальный институциональный источник  
**Качество:** C2  
**Статус:** license_verified  
**Ссылка:** `https://hfh.fas.harvard.edu/measuring-flourishing`  
**Поддерживает:**

- официальную структуру Flourishing и Secure Flourish Measure;
- пять основных доменов и два вопроса материальной стабильности;
- информацию о переводах;
- условия лицензирования.

**Лицензия:**

- некоммерческое использование: CC BY-NC 4.0 с атрибуцией;
- коммерческое использование требует отдельного лицензирования.

**Не поддерживает:**

- автоматическую полезность шкалы для Garden;
- право смешивать её с другими Flourishing Scales;
- безопасность показа результата пользователю.

**Связано с:** R-005, OBS-001, R-011, R-012.

---

### SRC-WB-003

**Источник:** Human Flourishing Program — *Global Flourishing Study*.  
**Тип:** официальная программа крупного продольного исследования  
**Качество:** C2; отдельные публикации оцениваются самостоятельно  
**Статус:** abstract_reviewed  
**Ссылка:** `https://hfh.fas.harvard.edu/global-flourishing-study`  
**Поддерживает:**

- существование международной продольной программы;
- многомерный и кросс-культурный исследовательский подход;
- актуальную структуру измеряемых доменов.

**Не поддерживает:**

- выводы, которых нет в конкретной публикации;
- перенос средних международных результатов на отдельного пользователя.

**Связано с:** R-005, кросс-культурная программа.

---

### SRC-WB-004

**Источник:** Ryff, C. D., & Keyes, C. L. M. (1995). *The Structure of Psychological Well-Being Revisited*.  
**Тип:** peer-reviewed primary study  
**Качество:** A2  
**Статус:** abstract_reviewed  
**PubMed:** `https://pubmed.ncbi.nlm.nih.gov/7473027/`  
**Поддерживает:**

- шестимерную модель психологического благополучия;
- автономию, mastery среды, рост, отношения, цель и самопринятие;
- эмпирическую проверку структуры на взрослой выборке.

**Не поддерживает:**

- необходимость превращать шесть измерений в продуктовые сферы;
- одинаковую валидность всех коротких версий шкалы;
- оценку всей жизни одним баллом.

**Связано с:** R-005, R-011.

---

### SRC-WB-005

**Источник:** Ryff, C. D. (2013/2014). *Psychological Well-Being Revisited: Advances in Science and Practice*.  
**Тип:** peer-reviewed review  
**Качество:** B1  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC4241300/`  
**Поддерживает:**

- развитие эвдемонической модели;
- обзор исследований и ограничений;
- внимание к контексту и неравенству.

**Связано с:** R-005, R-015.

---

### SRC-WB-006

**Источник:** Keyes, C. L. M. (2002). *The Mental Health Continuum: From Languishing to Flourishing in Life*.  
**Тип:** peer-reviewed primary conceptual and empirical paper  
**Качество:** A2/B1  
**Статус:** abstract_reviewed  
**PubMed:** `https://pubmed.ncbi.nlm.nih.gov/12096700/`  
**Поддерживает:**

- различение психического заболевания и положительного психического здоровья;
- эмоциональные, психологические и социальные составляющие функционирования.

**Риск применения:**

- категории flourishing/languishing могут восприниматься пользователем как диагноз или идентичность.

**Связано с:** R-005, R-011, Garden Voice.

---

### SRC-WB-007

**Источник:** Seligman, M. E. P. (2018). *PERMA and the Building Blocks of Well-Being*.  
**Тип:** peer-reviewed theoretical clarification  
**Качество:** B1  
**Статус:** full_text_available / abstract_reviewed  
**DOI:** `10.1080/17439760.2018.1437466`  
**Ссылка:** `https://ppc.sas.upenn.edu/sites/default/files/permawellbeing.pdf`  
**Поддерживает:**

- PERMA как пять предлагаемых строительных блоков wellbeing;
- важность вопроса о том, как выбираются элементы благополучия.

**Не поддерживает:**

- полноту PERMA;
- необходимость её использования как универсального продуктового чек-листа.

**Связано с:** R-005.

---

### SRC-PHI-001

**Источник:** Robeyns, I. — *The Capability Approach*, Stanford Encyclopedia of Philosophy.  
**Тип:** академический философский обзор  
**Качество:** B1  
**Статус:** full_text_reviewed  
**Ссылка:** `https://plato.stanford.edu/entries/capability-approach/`  
**Поддерживает:**

- различение достижений и реальных возможностей;
- необходимость учитывать способность конвертировать ресурсы в действия;
- анти-патерналистский аргумент в пользу capabilities.

**Не поддерживает:**

- готовую продуктовую модель;
- конкретный список деревьев Garden;
- способ измерения возможностей в приложении.

**Связано с:** R-005, R-015, Философия Garden.

---

## B. Автономия, мотивация и изменение поведения

### SRC-MOT-001

**Источник:** Ryan, R. M., & Deci, E. L. (2000). *Self-Determination Theory and the Facilitation of Intrinsic Motivation, Social Development, and Well-Being*.  
**Тип:** peer-reviewed theoretical synthesis  
**Качество:** B1  
**Статус:** full_text_available / abstract_reviewed  
**DOI:** `10.1037/0003-066X.55.1.68`  
**Ссылка:** `https://selfdeterminationtheory.org/SDT/documents/2000_RyanDeci_SDT.pdf`  
**Поддерживает:**

- роль автономии, компетентности и связанности;
- различение автономной и контролируемой мотивации;
- влияние среды на мотивацию и wellbeing.

**Не поддерживает:**

- отсутствие любой структуры;
- утверждение, что любой свободный выбор полезен;
- конкретные формулировки Garden без тестирования.

**Связано с:** R-001, R-002, R-005, R-009.

---

### SRC-MOT-002

**Источник:** Deci, E. L., & Ryan, R. M. (2000). *The “What” and “Why” of Goal Pursuits*.  
**Тип:** peer-reviewed theory paper  
**Качество:** B1  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://selfdeterminationtheory.org/SDT/documents/2000_DeciRyan_PIWhatWhy.pdf`  
**Поддерживает:**

- различие между содержанием цели и качеством мотивации;
- важность базовых психологических потребностей.

**Связано с:** R-001, R-002.

---

### SRC-HAB-001

**Источник:** Lally, P., van Jaarsveld, C. H. M., Potts, H. W. W., & Wardle, J. (2010). *How Are Habits Formed: Modelling Habit Formation in the Real World*.  
**Тип:** peer-reviewed longitudinal primary study  
**Качество:** A2  
**Статус:** abstract_reviewed  
**DOI:** `10.1002/ejsp.674`  
**Официальная запись:** `https://openresearch.surrey.ac.uk/esploro/outputs/journalArticle/99783513802346`  
**Поддерживает:**

- постепенное развитие автоматичности при повторении поведения в стабильном контексте;
- существенную индивидуальную вариативность.

**Не поддерживает:**

- миф о фиксированных 21 или 66 днях как универсальном сроке;
- тождество привычки и осмысленного ритуала;
- обязательность ежедневного повторения для Garden.

**Связано с:** R-006.

---

### SRC-HAB-002

**Источник:** Gollwitzer, P. M., & Sheeran, P. (2006). *Implementation Intentions and Goal Achievement: A Meta-analysis of Effects and Processes*.  
**Тип:** meta-analysis  
**Качество:** A1  
**Статус:** abstract_reviewed  
**DOI:** `10.1016/S0065-2601(06)38002-1`  
**Запись:** `https://www.socmot.uni-konstanz.de/publications/implementation-intentions-and-goal-achievement-meta-analysis-effects-and-processes`  
**Поддерживает:**

- if–then planning как способ сокращать разрыв между намерением и действием;
- влияние конкретного будущего контекста на запуск поведения.

**Не поддерживает:**

- применение плана без согласия человека;
- способность плана решить структурные ограничения;
- необходимость превращать Garden в планировщик.

**Связано с:** R-001, R-006.

---

## C. Self-compassion, стыд и поддержка

### SRC-COMP-001

**Источник:** Ferrari, M. et al. (2019). *Self-Compassion Interventions and Psychosocial Outcomes: A Meta-Analysis of RCTs*.  
**Тип:** meta-analysis of randomized trials  
**Качество:** A1  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://self-compassion.org/wp-content/uploads/2019/08/Ferrari2019.pdf`  
**Поддерживает:**

- возможность улучшения self-compassion и ряда психосоциальных исходов;
- необходимость учитывать качество и неоднородность интервенций.

**Не поддерживает:**

- универсальную эффективность тёплого языка Garden;
- тождество self-compassion и снятия требований;
- применение клинических практик без адаптации.

**Связано с:** R-002, R-009.

---

### SRC-COMP-002

**Источник:** Wakelin, K. E. et al. (2022). *Effectiveness of Self-Compassion-Related Interventions for Reducing Self-Criticism*.  
**Тип:** systematic review and meta-analysis  
**Качество:** A1  
**Статус:** abstract_reviewed  
**PubMed:** `https://pubmed.ncbi.nlm.nih.gov/33749936/`  
**Поддерживает:**

- среднее снижение self-criticism в интервенциях;
- необходимость дальнейшего анализа качества исследований.

**Связано с:** R-002, Garden Voice.

---

### SRC-COMP-003

**Источник:** Sirois, F. M. et al. (2015). *Self-Compassion, Affect, and Health-Promoting Behaviors*.  
**Тип:** peer-reviewed empirical study  
**Качество:** A2  
**Статус:** abstract_reviewed  
**PubMed:** `https://pubmed.ncbi.nlm.nih.gov/25243717/`  
**Поддерживает:**

- связь self-compassion, адаптивных эмоций и health-promoting behavior.

**Не поддерживает:**

- причинный вывод для любого поведения;
- продуктовую формулу «мягкость всегда повышает действие».

**Связано с:** R-002.

---

## D. Язык и совместное изменение

### SRC-LANG-001

**Источник:** Bischof, G. et al. (2021). *Motivational Interviewing: An Evidence-Based Approach for Use in Medical Practice*.  
**Тип:** peer-reviewed practical review  
**Качество:** B1  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC8200683/`  
**Поддерживает:**

- работу с амбивалентностью;
- коллаборативную, неосуждающую позицию;
- извлечение собственной мотивации человека.

**Не поддерживает:**

- право Garden имитировать терапию;
- автоматическое применение MI-паттернов LLM без контроля качества.

**Связано с:** R-009, Garden Voice.

---

### SRC-LANG-002

**Источник:** Rubak, S. et al. (2005). *Motivational Interviewing: A Systematic Review and Meta-analysis*.  
**Тип:** systematic review and meta-analysis  
**Качество:** A1  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC1463134/`  
**Поддерживает:**

- эффективность MI в ряде медицинских поведенческих контекстов по сравнению с традиционным советованием.

**Ограничения:**

- неоднородность контекстов;
- отсутствие систематического поиска вреда в старых исследованиях;
- перенос на AI требует отдельного исследования.

**Связано с:** R-009, R-010.

---

## E. Рефлексия и journaling

### SRC-REF-001

**Источник:** Frattaroli, J. (2006). *Experimental Disclosure and Its Moderators: A Meta-analysis*.  
**Тип:** meta-analysis  
**Качество:** A1  
**Статус:** abstract_reviewed  
**DOI:** `10.1037/0033-2909.132.6.823`  
**PubMed:** `https://pubmed.ncbi.nlm.nih.gov/17073523/`  
**Поддерживает:**

- небольшой средний эффект письменного эмоционального раскрытия;
- важность модераторов и дизайна практики.

**Не поддерживает:**

- утверждение, что ежедневное ведение дневника полезно всем;
- безопасность неограниченной рефлексии;
- эффективность AI-интерпретации записей.

**Связано с:** R-007.

---

### SRC-REF-002

**Источник:** Gortner, E.-M. et al. (2006). *Benefits of Expressive Writing in Lowering Rumination and Depressive Symptoms*.  
**Тип:** peer-reviewed primary study  
**Качество:** A2  
**Статус:** abstract_reviewed  
**PubMed:** `https://pubmed.ncbi.nlm.nih.gov/16942980/`  
**Поддерживает:**

- возможную роль expressive writing в снижении руминации у определённой выборки и в определённом протоколе.

**Не поддерживает:**

- универсальность эффекта;
- любой формат свободного journaling;
- замену профессиональной помощи.

**Связано с:** R-007.

---

## F. Природа и восстановление

### SRC-NAT-001

**Источник:** Jimenez, M. P. et al. (2021). *Associations between Nature Exposure and Health: A Review of the Evidence*.  
**Тип:** peer-reviewed evidence review  
**Качество:** B1/A1 по отдельным выводам  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC8125471/`  
**Поддерживает:**

- широкий корпус ассоциаций между контактом с природой и различными исходами;
- несколько возможных механизмов, включая восстановление внимания.

**Не поддерживает:**

- эквивалентность цифровой и реальной природы;
- клинические обещания Garden;
- утверждение, что садовая метафора сама по себе восстанавливает.

**Связано с:** R-003, R-013.

---

### SRC-NAT-002

**Источник:** Pham, T. P. et al. (2024). *Human Attention Restoration, Flow, and Creativity*.  
**Тип:** peer-reviewed review  
**Качество:** B1  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC11050943/`  
**Поддерживает:**

- актуальный обзор Attention Restoration Theory и связанных исследований.

**Связано с:** R-003, R-013.

---

## G. Измерение и self-tracking

### SRC-MEAS-001

**Источник:** König, L. M. et al. (2024). *Reactivity to Digital In-the-Moment Measurement of Health Behaviour: Systematic Review and Meta-analysis*.  
**Тип:** systematic review and meta-analysis  
**Качество:** A1  
**Статус:** identified / требует полного аудита  
**Публичная запись:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC11659718/`  
**Поддерживает:**

- сам факт необходимости учитывать measurement reactivity;
- неодинаковое влияние цифрового измерения в разных дизайнах.

**Связано с:** R-011.

---

### SRC-MEAS-002

**Источник:** Chiauzzi, E. et al. (2015). *Patient-Centered Activity Monitoring in Self-Management*.  
**Тип:** peer-reviewed review  
**Качество:** B1  
**Статус:** abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC4391303/`  
**Поддерживает:**

- self-monitoring может влиять на самооценку и поведение;
- важность пользовательского контекста и интерпретации данных.

**Связано с:** R-011.

---

## H. AI, совместная интерпретация и wellbeing

### SRC-AI-001

**Источник:** Zhu, S. et al. (2026). *Designing KRIYA: An AI Companion for Wellbeing Self-Reflection*.  
**Тип:** preprint / HCI prototype study  
**Качество:** C1/B2  
**Статус:** abstract_reviewed  
**Ссылка:** `https://arxiv.org/abs/2601.14589`  
**Поддерживает:**

- ценность co-interpretive framing как исследовательскую гипотезу;
- важность transparency;
- различие supportive и pressuring reflection;
- результаты интервью с 18 студентами на прототипе и гипотетических данных.

**Не поддерживает:**

- клиническую эффективность;
- долгосрочную безопасность;
- перенос на широкую аудиторию;
- доказанную эффективность Garden.

**Связано с:** R-010, R-011, Garden Voice.

---

### SRC-AI-002

**Источник:** Nepal, S. et al. (2024). *MindScape Study: Integrating LLM and Behavioral Sensing for Personalized AI-Driven Journaling Experiences*.  
**Тип:** preprint / exploratory study  
**Качество:** C1  
**Статус:** abstract_reviewed  
**Ссылка:** `https://arxiv.org/abs/2409.09570`  
**Поддерживает:**

- ранние результаты контекстного AI journaling;
- потенциальную ценность персонализированных prompts;
- необходимость дальнейшей проверки.

**Риски:**

- маленькая студенческая выборка;
- чувствительный пассивный сбор данных;
- preprint;
- множественные исходы;
- нельзя считать доказательством долгосрочного эффекта.

**Связано с:** R-007, R-010, R-012.

---

### SRC-AI-003

**Источник:** Chiu, Y. Y. et al. (2024). *A Computational Framework for Behavioral Assessment of LLM Therapists*.  
**Тип:** preprint / computational evaluation  
**Качество:** C1  
**Статус:** abstract_reviewed  
**Ссылка:** `https://arxiv.org/abs/2401.00820`  
**Поддерживает:**

- необходимость систематической проверки поведения LLM;
- риск избыточного problem-solving advice;
- невозможность полагаться на ощущение «эмпатичного тона».

**Не поддерживает:**

- использование Garden как терапевта;
- полный safety benchmark для wellbeing-продукта.

**Связано с:** R-010, R-009.

---

## I. Приватность и чувствительные данные

### SRC-PRIV-001

**Источник:** Tangari, G. et al. (2021). *Mobile Health and Privacy: Cross-Sectional Study*. BMJ.  
**Тип:** empirical privacy audit  
**Качество:** A2  
**Статус:** abstract_reviewed  
**Ссылка:** `https://www.bmj.com/content/373/bmj.n1248`  
**Поддерживает:**

- наличие существенных проблем и несоответствий в практиках приватности mHealth apps.

**Не поддерживает:**

- вывод о конкретной архитектуре Garden;
- утверждение, что все приложения одинаково небезопасны.

**Связано с:** R-012.

---

### SRC-PRIV-002

**Источник:** Iwaya, L. H. et al. (2022). *On the Privacy of Mental Health Apps*.  
**Тип:** empirical multi-method privacy investigation  
**Качество:** A2  
**Статус:** full_text_available / abstract_reviewed  
**Ссылка:** `https://pmc.ncbi.nlm.nih.gov/articles/PMC9643945/`  
**Поддерживает:**

- риски permissions, cryptography, logging, third-party sharing и profiling;
- необходимость privacy-by-design.

**Связано с:** R-012.

---

### SRC-PRIV-003

**Источник:** Georgiou, C. et al. (2026). *What’s on Your Mind? Exploring Privacy of Mental Health Apps*.  
**Тип:** recent preprint / empirical technical audit  
**Качество:** C1  
**Статус:** abstract_reviewed / watch  
**Ссылка:** `https://arxiv.org/abs/2605.02016`  
**Поддерживает:**

- свежий рыночный сигнал о transparency gaps, tracker SDKs и third-party AI processing;
- необходимость конкретно раскрывать обработчиков данных.

**Ограничения:**

- preprint;
- выборка Android-приложений;
- результаты требуют peer review и воспроизводимости.

**Связано с:** R-012, Garden Observatory.

---

## J. Рынок и продукты

### SRC-MKT-001

**Источник:** Flourishing App — About.  
**Тип:** официальный рыночный первичный источник  
**Качество:** D1  
**Статус:** full_text_reviewed / watch  
**Ссылка:** `https://www.flourishing.app/about`  
**Поддерживает:**

- самопозиционирование платформы;
- описанную связь с Human Flourishing Program;
- заявленную образовательную роль;
- планы дополнительных форматов.

**Не поддерживает:**

- официальное партнёрство с Harvard;
- научную эффективность продукта;
- активную мобильную пользовательскую базу.

**Связано с:** OBS-001, R-016.

---

### SRC-MKT-002

**Источник:** Flourishing App — Flourishing Measure page.  
**Тип:** официальный продуктовый источник  
**Качество:** D1  
**Статус:** full_text_reviewed / watch  
**Ссылка:** `https://www.flourishing.app/measures/flourishing-measure`  
**Поддерживает:**

- содержание публичной страницы;
- набор отображаемых вопросов;
- используемое продуктовое описание.

**Найденная проблема:**

- смешение описания 8-item Flourishing Scale с 12-question Secure Flourish Measure.

**Не поддерживает:**

- валидность такой комбинации;
- лицензионную чистоту;
- научную эффективность приложения.

**Связано с:** OBS-001, R-011.

---

# 7. Источники, которые необходимо добавить в следующей версии

## Для R-006 — ритуал и привычка

- антропология и социология ритуала;
- ritualization и meaning;
- distinction ritual/routine/habit;
- embodied cognition;
- cultural variability of ritual.

## Для R-007 — рефлексия и руминация

- Trapnell & Campbell: reflection versus rumination;
- Watkins: constructive and unconstructive repetitive thought;
- systematic reviews digital journaling;
- narrative identity;
- contraindications and adverse effects.

## Для R-009 — голос взрослой субъектности

- Motivational Interviewing Treatment Integrity;
- psychological reactance;
- autonomy-supportive language;
- infantilization and patronizing language;
- cross-cultural pragmatics;
- uncertainty communication.

## Для R-010 — AI и интерпретация

- sycophancy;
- anthropomorphism;
- emotional reliance;
- AI companion dependency;
- calibrated uncertainty;
- memory and identity formation;
- human oversight.

## Для R-011 — измерение

- Goodhart’s law and metric fixation;
- quantified-self HCI;
- mood tracking;
- eating disorder and anxiety risks;
- missingness and feedback loops.

## Для R-012 — безопасность

- GDPR;
- EU AI Act;
- medical device boundary;
- mental health app governance;
- intimate privacy;
- local/on-device inference;
- deletion and portability.

---

# 8. Очередь полного аудита

Приоритет P0:

1. SRC-WB-001 — полный текст и карточка аргументов.
2. SRC-WB-002 — отдельная license card.
3. SRC-MOT-001 — извлечь принципы autonomy support без терапевтизации.
4. SRC-COMP-001 — проверить эффект, выборки, риск bias.
5. SRC-REF-001 — разобрать модераторы и adverse outcomes.
6. SRC-NAT-001 — отделить реальную, цифровую природу и метафору.
7. SRC-MEAS-001 — полный аудит measurement reactivity.
8. SRC-AI-001 — разобрать дизайн, выборку и pressure findings.
9. SRC-PRIV-002 — превратить выводы в safety requirements.
10. SRC-MKT-002 — сохранить evidence mismatch как Observatory incident.

---

# 9. Требование к каждому исследованию Garden

Каждое исследование должно завершаться таблицей:

| Claim ID | Утверждение Garden | Источники | Уровень уверенности | Ограничения | Продуктовый статус |
|---|---|---|---|---|---|
| CLM-001 | ... | SRC-... | low/medium/high | ... | hypothesis/principle/accepted |

Исследование не может использовать формулировку «наука показывает» без конкретного Claim ID.

---

# 10. Требование к продуктовым решениям

Перед GDR проверяется:

- есть ли минимум один источник за решение;
- есть ли источник или аргумент против решения;
- проверена ли применимость к нашей аудитории;
- отделена ли научная гипотеза от ценностного выбора;
- проверена ли лицензия;
- существует ли способ измерить вред;
- обновлён ли Chronicle;
- можно ли объяснить решение пользователю простым языком.

---

# 11. Текущие ограничения реестра

- Это стартовый, а не полный корпус.
- Для большинства работ проверены метаданные и аннотации, но не выполнен полный критический разбор.
- Старые исследования R-001–R-003 ещё не связаны с конкретными Source ID.
- R-004 требует восстановления.
- Философские книги Сена и Нуссбаум пока представлены через академический обзор, а не через отдельные карточки оригинальных работ.
- Не собраны исследования adverse effects.
- Не завершена юридическая карта ЕС и других рынков.
- Не проведён систематический поиск по базам с заранее зарегистрированным протоколом.
