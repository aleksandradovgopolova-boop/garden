# Source Registry Addendum — R-032

**Дата:** 17 июля 2026

## Foundations

- Habit and automaticity research.
- Ritual, routine and symbolic-action traditions in anthropology and psychology.
- Self-determination and autonomy-supportive design traditions.
- Garden internal R-003, R-005, R-009, R-024, R-029 and R-031.
- Garden Trigger decks: Human-centric, Storytelling, Business Design, Innovation and Naming.

## Evidence cautions

- ritual definitions vary substantially across disciplines;
- meaningful repetition cannot be inferred from frequency alone;
- absence of logging is not evidence of absence of practice;
- some safety-critical routines genuinely require adherence support and belong to a separate product domain;
- streak effects vary by person and context;
- AI pattern detection can create false narratives and requires explicit consent;
- Garden principles are normative product decisions, not universal behavioral laws.
