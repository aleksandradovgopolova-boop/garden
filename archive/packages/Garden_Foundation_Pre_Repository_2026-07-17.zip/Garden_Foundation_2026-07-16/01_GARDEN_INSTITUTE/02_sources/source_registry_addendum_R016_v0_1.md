# Garden Source Registry — Addendum for R-016

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Scope:** current public product positioning, pricing and privacy claims; verify before decisions

## Direct AI journals

### SRC-MKT-001 — Rosebud

Official site and help center, accessed July 2026.

Observed public claims/features:

- AI journal adapting to the user;
- personalized prompts;
- pattern discovery;
- voice;
- long-term memory;
- self-care/habits;
- free tier;
- USD 12.99 monthly and USD 107.99 yearly offer displayed at access time;
- user input described as not used to train future models in its comparison material.

Use limitation: marketing claims are not independent outcome evidence.

### SRC-MKT-002 — Reflection

Official site, FAQ and premium page.

Observed:

- AI journal and coach;
- real-time guidance;
- voice;
- 100+ guides/programs;
- advanced insights;
- encryption at rest/in transit;
- subscription-funded;
- USD 8 monthly / USD 5.75 monthly annualized at access time.

### SRC-MKT-003 — Mindsera

Official site, privacy and plan pages.

Observed:

- AI journal / thinking copilot;
- emotion detection;
- patterns;
- frameworks;
- morning/evening rituals;
- habit tracker;
- voice, call and physical-journal scan;
- AES-256 at rest and TLS in transit;
- explicit statement that server-side AI is not compatible with true E2EE;
- paid range shown as approximately USD 10.75–14.99 monthly.

### SRC-MKT-004 — Liven

Official website and app listings.

Observed:

- self-discovery companion;
- mood tracking;
- habits;
- courses;
- AI assistant Livie;
- non-medical disclaimer.

## Practice and self-care

### SRC-MKT-005 — Finch

Official site/help and current app listings.

Observed:

- self-care pet;
- personalized exercises;
- daily rewards and events;
- friend/streak elements in current listing.

### SRC-MKT-006 — Fabulous

Official site and app listing.

Observed:

- routine and self-care app;
- daily coaching;
- goals/to-dos;
- journaling;
- workouts, breathwork, affirmations and meditation.

### SRC-MKT-007 — Habitica

Official site and current app listing.

Observed:

- game framing;
- recurring tasks and habits;
- streak counters;
- leveling;
- gear and pets;
- health loss/reward logic.

### SRC-MKT-008 — Stoic

Current app listings.

Observed:

- morning preparation and evening reflection;
- mood tracking;
- journal prompts;
- habits;
- meditation/breathwork;
- AI mentor/insight features described in current comparison materials.

## Measurement

### SRC-MKT-009 — Daylio

Official site and app listings.

Observed:

- no-writing mood journal;
- activities;
- goals;
- Year in Pixels;
- charts/statistics.

### SRC-MKT-010 — How We Feel

Official site and app listings.

Observed:

- emotion vocabulary;
- check-ins;
- strategies;
- sleep/exercise/health trends.

### SRC-MKT-011 — Bearable

Official product and support pages.

Observed:

- symptoms, moods, factors, treatments;
- correlations and experiments;
- warnings that correlation quality depends on data and professional guidance;
- premium price USD 34.99 annual at access time.

### SRC-MKT-012 — Exist

Official site.

Observed:

- integrated personal data;
- correlations;
- behavioral experiments;
- questions such as what makes the user happiest or productive.

## Mental health and companions

### SRC-MKT-013 — Headspace Ebb

Official Headspace pages.

Observed:

- adult 18+ AI companion;
- self-reflection and emotional processing;
- recommendations into Headspace library;
- not human care;
- no real-time human monitoring stated on product FAQ;
- automated real-time classification across defined risk categories described on AI principles page;
- encrypted data and limited need-to-know employee access;
- USD 69.99 annual offer at access time.

### SRC-MKT-014 — Wysa

Official site, FAQ and app listing.

Observed:

- anonymous AI conversation;
- structured techniques;
- human coach option;
- health-system and employer/institutional positioning.

### SRC-MKT-015 — Ash

Official site and app listing.

Observed:

- purpose-built mental-health AI;
- voice/text;
- weekly patterns;
- long-term growth;
- crisis disclaimer.

### SRC-MKT-016 — Replika

Official site and May 2026 privacy policy.

Observed:

- AI friend/companion;
- meaningful relationship;
- individualized conversation and learning from interactions;
- 18+ in current policy.

### SRC-MKT-017 — Pi

Current official app listing and service status.

Observed:

- emotionally intelligent AI;
- decision support, planning, growth and entertainment;
- «grows with you» positioning;
- updated July 2026.

### SRC-MKT-018 — Character.AI

Official privacy policy plus July 2026 regulatory reporting.

Observed:

- lifelike character conversations and user-generated content;
- significant age/privacy scrutiny;
- not a recommended model for Garden.

## Journals and knowledge systems

### SRC-MKT-019 — Day One

Official site, pricing and encryption documentation.

Observed:

- multimedia journal;
- durable archive and export;
- E2EE default for new journals;
- user-held key;
- USD 49.99 annual Silver plan at access time.

### SRC-MKT-020 — Apple Journal

Official Apple product/privacy/developer pages.

Observed:

- moments and multimedia;
- on-device Journaling Suggestions;
- user control of suggestion categories and sharing;
- device lock/biometrics.

### SRC-MKT-021 — Reflect Notes

Official site.

Observed:

- linked notes;
- GPT/Whisper AI;
- intellectual thought-partner positioning.

### SRC-MKT-022 — Capacities

Official site/app listing.

Observed:

- connected objects;
- daily notes;
- AI assistant;
- long-term personal knowledge system.

## Category privacy research

### SRC-MKT-023

Georgiou, C., Lu, H., De Cristofaro, E., & Tsudik, G. (2026).  
*What's on Your Mind? Exploring Privacy of Mental Health Apps.*  
arXiv: `2605.02016`.

Technical analysis of 25 Android mental-health and life-coaching apps reported:

- at least one undisclosed tracker SDK in every analyzed app;
- 68% failing to disclose at least half of detected trackers;
- permission-policy contradictions;
- inconsistent identification of third-party AI recipients.

Status: recent preprint; methods and sample should be independently audited before regulatory claims.

## New Source Registry fields

```yaml
product:
category:
public_positioning:
core_user_job:
ai_role:
memory_model:
measurement_model:
engagement_model:
social_model:
business_model:
privacy_claim:
clinical_claim:
garden_overlap:
garden_risk:
last_verified:
```
