# Garden Source Registry — Addendum for R-009

**Версия:** 0.1  
**Дата:** 15 июля 2026

## SRC-CULT-001

Chirkov, Ryan, Kim & Kaplan (2003). *Differentiating Autonomy From Individualism and Independence.*  
DOI: `10.1037/0022-3514.84.1.97`  
Тип: cross-cultural empirical study  
Качество: A2/B1  
Статус: full text reviewed

Поддерживает различение autonomy, independence и individualism; связь relative autonomy и wellbeing в выборках США, России, Турции и Южной Кореи.

Не поддерживает единый универсальный стиль коммуникации.

## SRC-CULT-002

Chen et al. (2015). *Basic Psychological Need Satisfaction, Need Frustration, and Need Strength Across Four Cultures.*  
DOI: `10.1007/s11031-014-9450-1`  
Тип: cross-cultural empirical study  
Качество: A2  
Статус: full-text proof reviewed

Поддерживает связи satisfaction/frustration автономии, компетентности и связанности с wellbeing/ill-being в выборках Бельгии, Китая, США и Перу.

Не поддерживает одинаковое культурное выражение потребностей.

## SRC-CULT-003

Spencer-Oatey (2022). *Politeness and Rapport Management.*  
DOI: `10.1017/9781108884303.020`  
Тип: authoritative review chapter  
Качество: B1  
Статус: official summary reviewed

Поддерживает контекстный и оценочный характер politeness и rapport.

## SRC-CULT-004

House & Kádár (2021). *Cross-Cultural Pragmatics.*  
Тип: academic framework  
Качество: B1  
Статус: official chapter summaries reviewed

Не является таблицей «правильных национальных тонов».

## SRC-CULT-005

Park & Kim (2008). *Asian and European American Cultural Values and Communication Styles.*  
PMID: `18230000`  
Тип: correlational study  
Качество: A2  
Статус: abstract reviewed

Поддерживает связь между лично поддерживаемыми cultural values и communication styles.

Не позволяет предсказывать человека по этничности.

## SRC-CULT-006

Gueta et al. (2023). *Cultural Accommodation of Internet-Based Interventions.*  
PMCID: `PMC10321598`  
Тип: pilot and framework  
Качество: B2/B1  
Статус: abstract reviewed

Поддерживает cultural accommodation beyond literal translation и участие целевой аудитории.

## SRC-GEN-001

Fiske (2012). *Warmth and Competence: Stereotype Content Issues.*  
PMCID: `PMC3801417`  
Тип: evidence review  
Качество: B1  
Статус: full text available/reviewed

Поддерживает warmth и competence как значимые измерения социального восприятия.

## SRC-GEN-002

Briggs et al. (2023). *Competence-Questioning Communication and Gender.*  
PMCID: `PMC9838290`  
Тип: multi-study empirical paper  
Качество: A2  
Статус: abstract reviewed

Поддерживает гендерно различающийся опыт competence-questioning communication в изученных контекстах.

Не поддерживает gender-based personalization.

## SRC-GEN-003

Park et al. (2016). *Women Are Warmer but No Less Assertive Than Men.*  
PMCID: `PMC4881750`  
Тип: large observational language study  
Качество: A2  
Статус: abstract reviewed

Поддерживает сложность и расхождение между стереотипами и наблюдаемым языком.

## SRC-DIGN-001

Shaw & Gordon (2021). *Understanding Elderspeak.*  
DOI: `10.1093/geroni/igab023`  
Тип: concept analysis  
Качество: B1  
Статус: full text available/reviewed

Поддерживает elderspeak как patronizing overaccommodation и риск снижения perceived respect.

## SRC-DIGN-002

Shaw et al. (2025). *The Iowa Coding Scheme for Elderspeak.*  
PMCID: `PMC12065398`  
Тип: coding scheme development  
Качество: A2/B1  
Статус: abstract reviewed

Операционализирует infantilizing language и дисбаланс care–respect–control.

## SRC-ND-001

Howard & Sedgewick (2021). *Anything but the Phone! Communication Mode Preferences in the Autism Community.*  
PMID: `34169750`  
Тип: survey  
Качество: A2/B2  
Статус: abstract reviewed

Поддерживает context-dependent communication preferences.

## SRC-ND-002

Nicolaidis et al. (2015). *Respect the Way I Need to Communicate With You.*  
PMCID: `PMC4841263`  
Тип: qualitative study  
Качество: B2  
Статус: full text available/reviewed

Поддерживает необходимость спрашивать и уважать коммуникационные потребности.

## SRC-ND-003

Bottini et al. (2024). *A Systematic Review of Recent Language Use in Autism Research.*  
PMCID: `PMC11319857`  
Тип: systematic review  
Качество: A1/B1  
Статус: abstract reviewed

Поддерживает разнообразие language preferences и отсутствие одного обязательного identity-first/person-first стандарта.

## SRC-ND-004

Cummins et al. (2020). *Autistic Adults’ Views of Their Communication Skills and Needs.*  
PMID: `32618026`  
Тип: qualitative interviews  
Качество: B2  
Статус: abstract reviewed

Поддерживает participant-defined needs и разные preferred modes.

## SRC-AI-LANG-001

Basoah et al. (2025). *Not Like Us, Hunty.*  
arXiv: `2505.05660`  
Тип: user studies with 498 AAE and 487 Queer slang speakers  
Качество: A2/C1  
Статус: full text reviewed

Поддерживает: sociolect mirroring влияет на trust, preference, social presence и reliance неодинаково и не гарантирует улучшения.

## SRC-AI-LANG-002

Borah, Augenstein & Mihalcea (2026). *Whose Norms?*  
arXiv: `2606.07877`  
Тип: benchmark and five-country human study  
Качество: A2/C1  
Статус: overview reviewed

Поддерживает внутри-культурный плюрализм и слабую передачу моделями распределения несогласия.

## SRC-AI-LANG-003

Yazan et al. (2026). *Personalized to Persuade.*  
arXiv: `2605.31275`  
Тип: experiment, N=380  
Качество: A2/C1  
Статус: full text reviewed

Поддерживает сложное влияние contextualization и warmth на trust, persuasion и reliance.

## SRC-AI-LANG-004

Chita-Tegmark et al. (2026). *Responsible Personalisation.*  
arXiv: `2607.06344`  
Тип: conceptual review  
Качество: B1/C1  
Статус: overview reviewed

Поддерживает риски потери автономии, усиления bias и privacy harms.

## SRC-AI-LANG-005

Huang et al. (2026). *Emotional Support with Conversational AI.*  
arXiv: `2603.22618`  
Тип: conceptual/review framework  
Качество: B1/C1  
Статус: abstract reviewed

Поддерживает tensions вокруг relatedness, competence, autonomy и overdependence.

## SRC-AI-LANG-006

Sun & Wang (2026). *Be Friendly, Not Friends: How LLM Sycophancy Shapes User Trust.*  
arXiv: `2502.10844`  
Тип: 2×2 experiment, N=224  
Качество: A2/C1  
Статус: full text reviewed

Поддерживает сложное взаимодействие complimentary demeanor и stance adaptation на authenticity и trust.

## Новые поля Source Registry

```yaml
country_or_region:
language:
within_culture_variation_considered:
translation_method:
cultural_adaptation:
identity_inference_used:
explicit_preferences_collected:
sociolect_or_dialect:
appropriation_risk:
gender_stereotype_risk:
accessibility_population:
```
