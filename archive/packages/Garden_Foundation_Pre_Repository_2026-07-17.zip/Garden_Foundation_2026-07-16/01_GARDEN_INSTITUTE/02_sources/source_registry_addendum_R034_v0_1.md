# Source Registry Addendum — R-034

**Дата:** 17 июля 2026

## Foundations

- Information architecture distinctions between hierarchy, graph and faceted structures.
- Situated and spatial interaction traditions.
- Product-boundary and bounded-context principles.
- Garden internal R-027, R-028, R-030, R-032 and R-033.
- Garden Trigger decks: Human-centric, Graphic Design, Innovation, Business Design and Naming.

## Evidence cautions

- graph interfaces can be useful in knowledge-management products;
- spatial composition does not replace semantic organization in all domains;
- Garden’s restricted relation model is a deliberate product boundary;
- user-created tags can still expand into informal ontology and require monitoring;
- future Garden–«Нити» interoperability requires consent, provenance and deletion research;
- relation limits should be validated against real retrieval tasks.
