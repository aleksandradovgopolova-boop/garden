# Garden Source Registry — Addendum for R-006

**Версия:** 0.1  
**Дата:** 15 июля 2026

## SRC-RIT-001 — Psychology of Habit

Wood, W., & Rünger, D. (2016). *Psychology of Habit.* Annual Review of Psychology, 67, 289–314.  
DOI: `10.1146/annurev-psych-122414-033417`  
Тип: authoritative review  
Качество: B1  
Статус: official full-text summary reviewed

Поддерживает context-cue activation, automaticity и различие привычки и deliberate goal pursuit.

Не поддерживает определение ритуала и необходимость автоматизировать любую практику.

## SRC-RIT-002 — Habit terminology

Gardner, B. (2015). *A Review and Analysis of the Use of “Habit” in Understanding, Predicting and Influencing Health-Related Behaviour.*  
PMCID: `PMC4566897`  
Тип: terminology review  
Качество: B1  
Статус: full text available / reviewed

Поддерживает необходимость различать habit process и просто частое поведение.

## SRC-RIT-003 — Habits and behavior change

Verplanken, B. (2022). *Attitudes, Habits, and Behavior Change.* Annual Review of Psychology.  
DOI: `10.1146/annurev-psych-020821-011744`  
Тип: authoritative review  
Качество: B1  
Статус: official summary reviewed

Поддерживает habit как memory-based propensity автоматически отвечать на cue.

## SRC-RIT-004 — Psychology of rituals

Hobson, N. M., et al. (2018). *The Psychology of Rituals: An Integrative Review and Process-Based Framework.*  
PMID: `29130838`  
Тип: integrative review  
Качество: B1  
Статус: abstract reviewed

Поддерживает три исследовательские функции ritual: emotion, performance goal states и social connection.

Ограничение: корпус обзора требует integrity re-check после последующих ретракций в области.

## SRC-RIT-005 — Ritual explained

Legare, C. H., & Nielsen, M. (2020). *Ritual Explained: Interdisciplinary Answers to Tinbergen’s Four Questions.*  
PMCID: `PMC7423255`  
Тип: interdisciplinary review  
Качество: B1  
Статус: full text reviewed

Поддерживает ритуалы как социально обусловленные, конвенциональные, часто формальные, ригидные и повторяющиеся последовательности.

## SRC-RIT-006 — Ingredients of rituals

Boyer, P., & Liénard, P. (2020). *Ingredients of “Rituals” and Their Cognitive Underpinnings.*  
PMCID: `PMC7423267`  
Тип: theoretical review  
Качество: B1  
Статус: full text reviewed

Поддерживает критическую позицию: ritual объединяет разнородное поведение по family resemblance.

## SRC-RIT-007 — Anxiety and ritualization

Lang, M., et al. (2015). *Effects of Anxiety on Spontaneous Ritualized Behavior.* Current Biology, 25(14), 1892–1897.  
PMID: `26096971`  
DOI: `10.1016/j.cub.2015.05.049`  
Тип: experiment  
Качество: A2  
Статус: abstract reviewed

Поддерживает: induced anxiety увеличивала redundancy, repetitiveness и rigidity движений.

Не поддерживает: ритуал снижает тревогу или полезен.

## SRC-RIT-008 — Perceived efficacy

Xygalatas, D., et al. (2021). *Ritualization Increases the Perceived Efficacy of Instrumental Actions.* Cognition, 215, 104823.  
PMID: `34198073`  
DOI: `10.1016/j.cognition.2021.104823`  
Тип: perception study  
Качество: A2  
Статус: abstract reviewed

Поддерживает влияние ritualized form на perceived efficacy.

Риск для Garden: форма может создавать завышенное ожидание результата.

## SRC-RIT-009 — Synchrony and cooperation

Wiltermuth, S. S., & Heath, C. (2009). *Synchrony and Cooperation.* Psychological Science, 20(1), 1–5.  
PMID: `19152536`  
Тип: experiments  
Качество: A2  
Статус: abstract reviewed

Поддерживает рост cooperation после synchronous action в исследованных условиях.

Не поддерживает универсальное улучшение отношений.

## SRC-RIT-010 — Secular rituals and bonding

Charles, S. J., et al. (2021). *United on Sunday: The Effects of Secular Rituals on Social Bonding and Affect.* PLOS ONE, 16(1), e0242546.  
PMID: `33503054`; PMCID: `PMC7840012`  
Тип: field pre-post study  
Качество: A2/B2  
Статус: abstract reviewed

Ограничения: self-selection, отсутствие рандомизации, коллективный контекст.

## SRC-RIT-011 — Ritual and cooperation

Fischer, R., et al. (2013). *How Do Rituals Affect Cooperation?*  
PMID: `23666518`  
Тип: experimental field study  
Качество: A2  
Статус: abstract reviewed

Поддерживает контекстно зависимую связь synchrony/sacredness и prosocial outcomes.

## SRC-RIT-012 — Compulsive behavior

Luigjes, J., et al. (2019). *Defining Compulsive Behavior.*  
PMCID: `PMC6499743`  
Тип: interdisciplinary review  
Качество: B1  
Статус: full text available / abstract reviewed

Поддерживает признаки compulsivity: repetitive acts, feeling of “has to”, несоответствие общим целям.

Не является диагностическим инструментом Garden.

## SRC-RIT-013 — RETRACTED

Brooks, A. W., et al. (2016). *Don’t Stop Believing: Rituals Improve Performance by Decreasing Anxiety.*  
**Статус:** retracted in 2024  
Retraction DOI: `10.1016/j.obhdp.2024.104377`

Правило:

- не использовать выводы;
- помечать обзоры, опиравшиеся на статью;
- сохранить как integrity incident.

## SRC-RIT-014 — Family routines and rituals

Fiese, B. H., et al. *A Review of 50 Years of Research on Naturally Occurring Family Routines and Rituals.*  
Тип: family research review  
Качество: B1  
Статус: identified; нужен полный аудит

Поддерживает различение observable routines и symbolic family rituals.

## SRC-RIT-015 — INTEGRITY WATCH

Vohs, K. D., Wang, Y., Gino, F., & Norton, M. I. (2013). *Rituals Enhance Consumption.*  
PMID: `23863754`  
Статус: не отозвана на дату аудита; отдельная проверка integrity и replication обязательна.

## SRC-RIT-016 — INTEGRITY WATCH

Norton, M. I., & Gino, F. (2014). *Rituals Alleviate Grieving for Loved Ones, Lovers, and Lotteries.*  
PMID: `23398180`  
Статус: не отозвана на дату аудита; не делать продуктовый вывод без отдельной проверки.

---

## Новые поля Source Registry

```yaml
retraction_checked:
correction_checked:
expression_of_concern_checked:
data_or_materials_available:
independent_replication:
integrity_watch:
```
