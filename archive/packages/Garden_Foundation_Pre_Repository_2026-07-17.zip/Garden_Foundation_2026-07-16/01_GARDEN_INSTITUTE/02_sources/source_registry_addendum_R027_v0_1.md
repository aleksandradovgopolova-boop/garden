# Source Registry Addendum — R-027

**Дата:** 17 июля 2026

## Источники

- Gibson, J. J. (1979). *The Ecological Approach to Visual Perception*.
- Maier, Fadel & Battisto (2009). *An affordance-based approach to architectural theory, design, and practice*.
- Baber (2022). *Embodying Design*.
- Costanza-Chock (2020). *Design Justice* — неравный доступ к affordances и ценности, встроенные в системы.
- Lynch (1960). *The Image of the City* — landmarks, paths, edges, districts and nodes.
- Research on environmental affordances in open and green spaces.
- Recent affordance-based architectural evaluation research.
- Public-open-space research on seating, seclusion and solitary practices.
- Garden internal R-018, R-019, R-020 and World Architecture v1.

## Ограничения

- физические affordances нельзя напрямую переносить в цифровой мир;
- intended function, perceived affordance and actual use различаются;
- возможности зависят от тела, навыков, устройства и социального контекста;
- архитектурные эффекты часто контекстны и корреляционны;
- культурные значения объектов не универсальны.
