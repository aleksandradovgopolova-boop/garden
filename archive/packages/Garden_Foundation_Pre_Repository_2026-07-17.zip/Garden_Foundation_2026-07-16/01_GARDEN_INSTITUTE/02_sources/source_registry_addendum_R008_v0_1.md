# Garden Source Registry — Addendum for R-008

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Контур:** `06_sources/source_registry_addenda/R-008.md`

---

## SRC-ACT-001

**Ntoumanis, N., et al. (2021).**  
*A Meta-Analysis of Self-Determination Theory-Informed Intervention Studies in the Health Domain.* Health Psychology Review.  
PMID: `31983293`  
Тип: meta-analysis  
Качество: A1  
Статус: abstract reviewed

Поддерживает:

- positive changes in need support and autonomous motivation associated with positive health behavior change;
- importance of intervention content and delivery.

Не поддерживает:

- любой «свободный выбор» как полезный;
- конкретную механику Garden;
- отсутствие структуры.

---

## SRC-ACT-002

**Mohr, D. C., Cuijpers, P., & Lehman, K. A. (2011).**  
*Supportive Accountability: A Model for Providing Human Support to Enhance Adherence to eHealth Interventions.* Journal of Medical Internet Research, 13(1), e30.  
PMID: `21393123`  
DOI: `10.2196/jmir.1602`  
Тип: theoretical model grounded in adjacent literature  
Качество: B1  
Статус: full article metadata and abstract reviewed

Поддерживает:

- accountability to a trustworthy, benevolent and expert coach;
- clear process-oriented expectations;
- participant involvement in defining expectations;
- human support as an adherence mechanism.

Ограничение:

- основная целевая переменная — adherence к intervention;
- модель человеческой поддержки нельзя автоматически переносить на AI;
- это theoretical model, а не универсальный доказанный протокол.

---

## SRC-ACT-003

**Kwok, G., Cheung, S. P. Y., Duffecy, J., & Devine, K. A. (2025).**  
*Application of the Supportive Accountability Model in Digital Health Interventions: Scoping Review.* Journal of Medical Internet Research, 27, e72639.  
PMID: `41004801`  
DOI: `10.2196/72639`  
Тип: scoping review  
Качество: B1  
Статус: abstract/conclusion reviewed

Поддерживает:

- SAM применяется неравномерно;
- многие DHI используют отдельные элементы, а не модель целиком;
- human support рассматривается как adjunct to engagement;
- остаются методологические пробелы.

Не доказывает эффективность AI accountability.

---

## SRC-ACT-004

**Bryan, G., Karlan, D., & Nelson, S. (2010).**  
*Commitment Devices.* Annual Review of Economics, 2, 671–698.  
DOI: `10.1146/annurev.economics.102308.124324`  
Тип: evidence review  
Качество: B1  
Статус: abstract reviewed

Поддерживает различение hard и soft commitments и контекстную эффективность commitment devices.

Не поддерживает обязательные штрафы или universal demand.

---

## SRC-ACT-005

**Herzog, S. M., & Hertwig, R. (2025).**  
*Boosting: Empowering Citizens with Behavioral Science.* Annual Review of Psychology, 76, 851–881.  
DOI: `10.1146/annurev-psych-020924-124753`  
Тип: authoritative open-access review  
Качество: B1  
Статус: full text reviewed

Поддерживает:

- boosting как развитие competences, agency, self-control and informed decision-making;
- критику ставки только на benevolent choice architects;
- self-nudging как один из empowerment approaches.

Не поддерживает, что boosts всегда эффективнее nudges.

Лицензия: CC BY 4.0.

---

## SRC-ACT-006

**Banerjee, S., & John, P. (2024; online 2021).**  
*Nudge Plus: Incorporating Reflection into Behavioral Public Policy.* Behavioural Public Policy, 8(1), 69–84.  
DOI: `10.1017/bpp.2021.6`  
Тип: conceptual and theoretical synthesis  
Качество: B1  
Статус: full text reviewed

Поддерживает:

- adding active reflection and transparency to nudge design;
- agency as a normative objective.

Ограничения:

- efficacy remains to be empirically validated;
- reflective design itself can subtly steer toward sponsor-preferred outcomes.

Лицензия: CC BY 4.0.

---

## SRC-ACT-007

**Reijula, S., & Hertwig, R. (2022; online 2020).**  
*Self-Nudging and the Citizen Choice Architect.* Behavioural Public Policy, 6(1), 119–149.  
DOI: `10.1017/bpp.2020.5`  
Тип: conceptual framework  
Качество: B1  
Статус: abstract reviewed

Поддерживает:

- individuals can design their own proximate choice environments;
- self-nudging as empowerment and self-governance;
- education about choice architecture.

Не поддерживает универсальную эффективность или равный доступ к environmental change.

---

## SRC-ACT-008

**Duckworth, A. L., Gendler, T. S., & Gross, J. J. (2016).**  
*Situational Strategies for Self-Control.* Perspectives on Psychological Science, 11(1), 35–55.  
PMID: `26817725`  
Тип: theoretical review  
Качество: B1  
Статус: abstract reviewed

Поддерживает:

- antecedent situational strategies can reduce reliance on in-the-moment effort;
- changing exposure and environment may prevent stronger impulses.

Не поддерживает individualizing structural problems.

---

## SRC-ACT-009

**Coupe, N., et al. (2019).**  
*The Effect of Commitment-Making on Weight Loss and Behaviour Change in Adults With Obesity/Overweight: A Systematic Review and Meta-Analysis.*  
PMCID: `PMC6591991`  
Тип: systematic review and meta-analysis, three trials, N=409  
Качество: A1 with small evidence base  
Статус: abstract reviewed

Поддерживает modest short-term weight-loss effect in a narrow context.

Не поддерживает general commitment mechanics for Garden.

---

## SRC-ACT-010

**Fanaroff, A. C., et al. (2023/2024).**  
*Feasibility and Outcomes From Using a Commitment Device for Time-Restricted Eating.*  
PMCID: `PMC11010633`  
Тип: randomized controlled trial  
Качество: A2  
Статус: abstract reviewed

Поддерживает a null result: soft commitment did not improve adherence versus attention control in the studied intervention.

Урок: commitment device is not automatically effective.

---

## SRC-ACT-011

**van der Swaluw, K., et al. (2018).**  
*Commitment Lotteries Promote Physical Activity Among Overweight Adults.*  
PMCID: `PMC6361262`; follow-up PMCID: `PMC6061083`  
Тип: cluster randomized trial  
Качество: A2  
Статус: abstract reviewed

Поддерживает positive effects in a specific gym-attendance lottery design.

Ограничения: external incentive, specific population and context.

---

## SRC-ACT-012

**Derksen, L., et al. (2024/2025).**  
*Healthcare Appointments as Commitment Devices.*  
PMCID: `PMC12687577`  
Тип: randomized field experiment  
Качество: A2  
Статус: abstract reviewed

Поддерживает that appointments and hard commitment devices can affect HIV testing behavior in a specific Malawi context.

Не переносится на general wellbeing or Garden penalties.

---

## SRC-ACT-013

**Loughnane, C., Laiti, J., O’Donovan, R., & Dunne, P. J. (2025).**  
*Systematic Review Exploring Human, AI, and Hybrid Health Coaching in Digital Health Interventions.* Frontiers in Digital Health, 7, 1536416.  
DOI: `10.3389/fdgth.2025.1536416`  
Тип: systematic review, 35 studies  
Качество: A1 with narrative synthesis and heterogeneity  
Статус: abstract reviewed

Поддерживает:

- human, AI and hybrid modalities have demonstrated feasibility and acceptability;
- some positive engagement and lifestyle outcomes;
- protocols and engagement measures vary;
- hybrid models require further refinement.

Не поддерживает equivalence of AI and human coaching or long-term safety.

---

## SRC-ACT-014

**Altendorf, M. B., et al. (2019).**  
*Should or Could? Testing Autonomy-Supportive Language and Choice in Online Alcohol Reduction Communication.* Digital Health.  
PMCID: `PMC6393822`  
Тип: online experiment, N=521  
Качество: A2  
Статус: abstract reviewed

Did not find expected significant main effects of wording or choice on key outcomes.

Урок: modal verbs do not guarantee autonomy support.

---

## SRC-ACT-015

**Smit, E. S., et al. (2019).**  
*Identifying the Most Autonomy-Supportive Message Frame in Digital Health Communication.* Journal of Medical Internet Research, 21(10), e14074.  
PMCID: `PMC6914245`  
Тип: 2×2 online experiment, N=526  
Качество: A2  
Статус: abstract reviewed

Provision of choice was a stronger signal of perceived autonomy support than wording alone in this setting.

Не поддерживает a universal copy formula.

---

## SRC-ACT-016

**Promberger, M., & Marteau, T. M. (2013).**  
*When Do Financial Incentives Reduce Intrinsic Motivation? Comparing Behaviors Studied in Psychological and Economic Literatures.*  
PMID: `24001245`  
Тип: systematic conceptual review  
Качество: B1  
Статус: abstract reviewed

Поддерживает context-dependent undermining effects, particularly for simple tasks with existing intrinsic motivation.

Не поддерживает claim that incentives always undermine motivation.

---

## Дополнительные правила для commitment и accountability

Добавить поля:

```yaml
commitment_owner:
commitment_type:
reversibility:
penalty:
resource_inequality_risk:
changed_preference_handling:
human_or_ai_support:
adherence_target:
human_outcome_target:
withdrawal_process:
```
