# Source Registry Addendum — R-031

**Дата:** 17 июля 2026

## Foundations

- Human-in-the-loop and mixed-initiative interaction traditions.
- Version control, reversible interaction and provenance principles.
- Garden internal R-019, R-024, R-027, R-029 and R-030.
- Garden Trigger decks: Human-centric, Innovation, Graphic Design, Storytelling and Business Design.

## Evidence cautions

- perceived authorship must be tested directly;
- more user effort does not automatically improve ownership;
- explanation quality depends on relevance, not quantity;
- proposal workflows can create friction if overused;
- AI-generated drafts may anchor users toward first suggestions;
- collaboration and conflict resolution require separate research.
