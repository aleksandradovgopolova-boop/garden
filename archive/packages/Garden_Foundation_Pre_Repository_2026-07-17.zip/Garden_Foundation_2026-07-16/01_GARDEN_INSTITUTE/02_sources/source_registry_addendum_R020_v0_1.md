# Source Registry Addendum — R-020

**Дата:** 16 июля 2026

## Primary and authoritative sources used

- UNESCO World Heritage Centre — The Persian Garden.
- Encyclopaedia Iranica — Čahārbāḡ and Achaemenid gardens.
- The Metropolitan Museum of Art — The Gardens of The Met Cloisters.
- Smarthistory / British Museum — Chinese scholar-painters and garden culture.
- Smarthistory — Ryōanji.
- The Metropolitan Museum of Art — Japanese Tea Ceremony, Muromachi period, seasonal imagery.
- Château de Versailles — Gardens, groves and official history.
- Historic England — English Landscape Garden and Capability Brown landscapes.
- National Gallery of Art — History of Early American Landscape Design.

## Evidence cautions

- Garden traditions are internally diverse and changed across centuries.
- Museum summaries simplify contested scholarship.
- Symbolic meanings vary by period, region and patron.
- Modern reconstructions may combine evidence and interpretation.
- Elite gardens dominate surviving documentation.
- Domestic, Indigenous, vernacular and colonized perspectives require further research.
