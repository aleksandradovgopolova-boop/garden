# Garden Source Registry — Addendum for R-013

**Версия:** 0.1  
**Дата:** 15 июля 2026

## SRC-META-001

Thibodeau, P. H., & Boroditsky, L. (2011). *Metaphors We Think With: The Role of Metaphor in Reasoning.* PLOS ONE, 6(2), e16782.  
DOI: `10.1371/journal.pone.0016782`  
Тип: five framing experiments  
Качество: A2  
Статус: full text reviewed

Поддерживает: metaphor framing can influence proposed solutions and information search.

Ограничения: specific crime scenarios; effect boundaries and coding contested in later work.

## SRC-META-002

Thibodeau, P. H., et al. (2015). *Measuring Effects of Metaphor in a Dynamic Opinion Landscape.* PLOS ONE.  
PMCID: `PMC4517745`  
Тип: experiments and reanalysis  
Качество: A2  
Статус: full text reviewed

Поддерживает context and existing opinion landscape as relevant to framing effects.

## SRC-META-003

Christmann, U., et al. (2016). *German-Language Replication of Metaphor Framing.* PLOS ONE.  
PMID: `27779615`; PMCID: `PMC5079120`  
Тип: replication study  
Качество: A2  
Статус: full text available/reviewed

Reports a successful replication in the studied German-language design.

## SRC-META-004

Steen, G. J., Reijnierse, W. G., & Burgers, C. (2014). *When Do Natural Language Metaphors Influence Reasoning?*  
Тип: critical follow-up study  
Качество: A2  
Статус: full manuscript identified/reviewed

Supports boundary-condition caution and sensitivity to coding/control comparisons.

## SRC-META-005

Landau, M. J., Keefer, L. A., & Rothschild, Z. K. (2017; PMC publication 2021). *Do Metaphors in Health Messages Work?*  
PMCID: `PMC8025806`  
Тип: systematic conceptual review of experiments  
Качество: B1  
Статус: full text reviewed

Supports possible effects on attention, comprehension, emotion, motivation and behavioral intentions in specific conditions.

Does not support universal benefit or clinical outcomes.

## SRC-META-006

Semino, E., Demjén, Z., & Demmen, J. (2017). *The Online Use of Violence and Journey Metaphors by Patients with Cancer.* BMJ Supportive & Palliative Care.  
PMID: `25743439`  
Тип: corpus-based qualitative analysis  
Качество: B2  
Статус: abstract and related corpus materials reviewed

Supports empowering and disempowering uses within both metaphor families.

## SRC-META-007

Lempp, H., et al. (2024). *The Use of Metaphors by Service Users With Diverse Long-Term Conditions.*  
PMID: `38328347`; PMCID: `PMC10849034`  
Тип: qualitative analysis  
Качество: B2  
Статус: full text reviewed

Supports polysemy and person/context dependence of illness metaphors.

## SRC-META-008

Rucińska, Z., et al. (2022). *Enacting Metaphors in Systemic Collaborative Therapy.*  
PMCID: `PMC9114737`  
Тип: theoretical and practice analysis  
Качество: B1/B2  
Статус: full text reviewed

Supports metaphor as shared, enacted and relational process rather than static linguistic substitution.

Not evidence for automated AI therapy.

## SRC-META-009

Řiháček, T., et al. (2021). *Facets of the Psychotherapy Relationship: A Metaphorical Approach.*  
PMCID: `PMC7875073`  
Тип: qualitative metaphor analysis  
Качество: B2  
Статус: full text reviewed

Supports use of metaphor to access relational experience not easily captured by analytic language.

## SRC-META-010

Roystonn, K., et al. *Cross-Cultural Exploration of Metaphors Used by Young Adults With Depression.*  
PMCID repository: `PMC11930630`  
Тип: cross-cultural qualitative analysis  
Качество: B2  
Статус: full text reviewed

Supports cultural overlap and variation in metaphor use.

Does not justify national metaphor profiles.

## SRC-META-011

Malkomsen, A., et al. (2021). *How Patients Use Metaphors to Describe Experiences of Psychiatric Treatment.*  
PMCID: `PMC8555134`  
Тип: qualitative systematic/empirical analysis  
Качество: B2  
Статус: full text reviewed

Supports metaphors as windows into expectations, distress and treatment experience.

## SRC-META-012

Altavilla, D., et al. (2025). *Metaphor as a Cognitive and Relational Tool for Self-Narrating Illness.*  
PMCID: `PMC12533479`  
Тип: qualitative/clinical communication analysis  
Качество: B2  
Статус: full text reviewed

Supports metaphor as coping and identity-narration tool.

## SRC-META-013

Lakoff, G., & Johnson, M. (1980/2003). *Metaphors We Live By.*  
Тип: foundational conceptual theory  
Качество: C1 theoretical classic  
Статус: bibliographic source

Use as theory, not causal experimental proof.

## SRC-META-014

Garden R-003. *Real Nature, Digital Nature and Garden Metaphor.*  
Тип: internal audited synthesis  
Статус: internal foundation

Supports strict separation of real nature effects and metaphor effects.

## Новые поля Source Registry

```yaml
metaphor_source:
metaphor_target:
user_authored:
product_imposed:
cultural_context:
empowering_reading:
disempowering_reading:
hidden_mapping:
systemic_issue_risk:
medical_implication:
literal_equivalent:
exit_available:
```
