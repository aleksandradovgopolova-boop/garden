# Source Registry Addendum — R-029

Internal foundations: R-019, R-024, R-025, R-026, R-027, R-028 and the eight Garden Trigger decks.

Cautions:

- perceived aliveness requires direct testing;
- trigger cards generate alternatives and are not evidence;
- reversibility is a product principle, not a universal psychological law;
- long-term effects of persistent virtual worlds need later research;
- migration requirements need technical validation.
