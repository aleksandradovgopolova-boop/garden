# Garden Source Registry — Addendum for R-014

**Версия:** 0.1  
**Дата:** 16 июля 2026

## SRC-SOC-001

**Cohen, S., & Wills, T. A. (1985).**  
*Stress, Social Support, and the Buffering Hypothesis.* Psychological Bulletin, 98(2), 310–357.  
PMID: `3901065`  
Тип: foundational review  
Качество: B1  
Статус: bibliographic/official metadata reviewed

Supports distinctions between general beneficial effects and stress-buffering models of support.

## SRC-SOC-002

**Graven, L. J., & Grant, J. S. (2014).**  
*Social Support and Self-Care Behaviors in Individuals With Heart Failure.*  
PMID: `23850389`  
Тип: systematic review  
Качество: A1/B1  
Статус: abstract reviewed

Uses emotional, instrumental/tangible, informational and appraisal support categories.

Clinical context limits generalization.

## SRC-SOC-003

**Lee, A. A., et al. (2019).**  
*Diabetes Self-Management and Glycemic Control: The Role of Autonomy Support From Informal Health Supporters.*  
PMID: `30652911`  
Тип: observational health study  
Качество: A2  
Статус: abstract reviewed

Supports association between autonomy-supportive informal support and attitudes, self-care and glycemic control.

Does not prove Garden social mechanics.

## SRC-SOC-004

**Di Maio, S., et al. (2024).**  
*Compendium of Dyadic Intervention Techniques to Change Health Behaviours in Romantic Couples.*  
PMID: `38437798`  
Тип: systematic development of technique compendium  
Corpus: 165 studies, 122 interventions  
Качество: A1/B1  
Статус: abstract reviewed

Supports diversity of dyadic mechanisms rather than one generic partner-involvement technique.

## SRC-SOC-005

**Martire, L. M., et al. (2010).**  
*Review and Meta-Analysis of Couple-Oriented Interventions for Chronic Illness.*  
PMID: `20697859`  
Тип: meta-analysis  
Качество: A1  
Статус: abstract reviewed

Reports small average effects and potential value of targeting partner influence.

Clinical and chronic-illness context.

## SRC-SOC-006

**Fortuna, K. L., et al. (2020).**  
*Digital Peer Support Mental Health Interventions for People With a Lived Experience of a Serious Mental Illness: Systematic Review.*  
PMCID: `PMC7165313`  
Тип: systematic review  
Качество: A1  
Статус: full text available/abstract reviewed

Identified 30 studies/24 interventions; supports promise and major heterogeneity.

## SRC-SOC-007

**Marshall, P., et al. (2024).**  
*Understanding the Impacts of Online Mental Health Peer Support Forums: Realist Synthesis.*  
PMCID: `PMC11117133`  
Тип: realist review and program theory  
Качество: B1  
Статус: full text reviewed

Supports context-sensitive mechanisms behind positive and negative impacts.

## SRC-SOC-008

**Yeo, G. H., et al. (2025).**  
*The Effects of Digital Peer Support Interventions on Physical and Mental Health: Systematic Review and Meta-Analysis.*  
PMCID: `PMC11886969`  
Тип: systematic review and meta-analysis  
Качество: A1  
Статус: full text reviewed

Reports positive average effects, stronger mental-health effects, weaker effects at longer follow-up, and possible risks with extended exposure.

Heterogeneous intervention components and predominantly Western samples limit conclusions.

## SRC-SOC-009

**Easton, K., et al. (2017).**  
*Qualitative Exploration of the Potential for Adverse Events When Using an Online Peer Support Network.*  
PMCID: `PMC5684514`  
Тип: qualitative study  
Качество: B2  
Статус: full text reviewed

Identifies emotional/behavioral contagion, debate, co-rumination, collusion and negative interactions as relevant risks.

## SRC-SOC-010

**Kruzan, K. P., et al. (2023).**  
*Young Adults’ Perceptions of Publicly Available Digital Resources for Self-Injury.*  
PMCID: `PMC9880808`  
Тип: randomized/qualitative perception study  
Качество: A2/B2  
Статус: full text reviewed

Participants reported benefits and harms; peer-support app condition generated more reported harms than informational materials.

Narrow self-injury context.

## SRC-SOC-011

**Abou Seif, N., et al. (2022).**  
*Effectiveness, Acceptability and Potential Harms of Peer Support for Self-Harm: Systematic Review.*  
PMCID: `PMC8811789`  
Тип: systematic review  
Качество: A1  
Статус: full text reviewed

Supports acceptability and perceived community/empowerment benefits alongside limited effectiveness and harm evidence.

## SRC-SOC-012

**Strand, M., et al. (2020).**  
*Combining Online and Offline Peer Support Groups in Community Mental Health Care.*  
PMCID: `PMC7260836`  
Тип: implementation/qualitative study  
Качество: B2  
Статус: full text reviewed

Highlights concerns about excessive use, reduced offline interaction, avoidance and dependency.

## SRC-SOC-013

**Rose, A. J., et al. (2007).**  
*Prospective Associations of Co-Rumination With Friendship and Emotional Adjustment.*  
PMCID: `PMC3382075`  
Тип: longitudinal adolescent study  
Качество: A2  
Статус: full text reviewed

Supports co-rumination as a process with potential relational benefits and internalizing costs.

## SRC-SOC-014

**Starr, L. R., & Davila, J. (2009).**  
*Clarifying Co-Rumination: Associations With Internalizing Symptoms and Romantic Involvement.*  
PMCID: `PMC2652577`  
Тип: empirical study  
Качество: A2  
Статус: full text reviewed

Supports positive associations with depressive symptoms and friendship dimensions, with mixed longitudinal findings.

## SRC-SOC-015

**Mackenzie, E., et al. (2023).**  
*Online Support Seeking, Co-Rumination, and Mental Health.*  
PMCID: `PMC10027699`  
Тип: empirical study  
Качество: A2  
Статус: full text reviewed

Suggests co-rumination can reduce benefits of friend support seeking in studied youth data.

## SRC-SOC-016

**Stone, L. B., et al. (2022).**  
*Stop Talking About It Already! Co-Rumination and Social Media.*  
PMCID: `PMC8819886`  
Тип: empirical study  
Качество: A2  
Статус: full text reviewed

Supports adjustment trade-offs and relation between co-rumination and communication patterns.

## SRC-SOC-017

**Tong, H. L., et al. (2022).**  
*A Personalized Mobile App for Physical Activity: Social Comparison Preferences.*  
PMCID: `PMC9309778`  
Тип: user study  
Качество: B2  
Статус: full text reviewed

Supports diversity of preferences for similarity, upward and downward comparison.

Does not prove benefits of comparison.

## SRC-SOC-018

**Feng, S., et al. (2021).**  
*How Self-Tracking and the Quantified Self Promote Health and Well-Being: Systematic Review.*  
PMCID: `PMC8493454`  
Тип: systematic review  
Качество: A1  
Статус: full text reviewed

Supports social comparison/social support as possible mechanisms while documenting mixed experiences and risks.

## SRC-SOC-019

**Deng, D., et al. (2023).**  
*The Role of Moderators in Facilitating Peer-to-Peer Support in an Online Mental Health Community.*  
PMCID: `PMC9933803`  
Тип: qualitative moderator interviews  
Качество: B2  
Статус: full text reviewed

Supports active moderator roles in modeling, facilitation, safety and escalation.

## SRC-SOC-020

**Understanding Safety in Online Mental Health Forums (2025).**  
PMCID: `PMC12227176`  
Тип: realist evaluation  
Качество: B1/B2  
Статус: full text reviewed

Supports distinction between absence of harm and felt interpersonal safety and the role of platform context.

## SRC-SOC-021

**Métellus, S., et al. (2025).**  
*Attachment Anxiety and Relationship Satisfaction in the Digital Age: Social Media Jealousy and Electronic Partner Surveillance.*  
PMCID: `PMC12445260`  
Тип: three-wave longitudinal study, N=322  
Качество: A2  
Статус: full text reviewed

Supports digital jealousy/surveillance as relevant relationship risks, with partially supported longitudinal hypotheses.

Does not directly study shared wellbeing apps.

## New Source Registry fields

```yaml
support_type:
support_requested:
support_provider:
power_asymmetry:
dyadic_or_group:
data_visibility:
reciprocity:
coercion_risk:
co_rumination_risk:
comparison_present:
moderation_model:
offline_transfer:
exit_process:
```
