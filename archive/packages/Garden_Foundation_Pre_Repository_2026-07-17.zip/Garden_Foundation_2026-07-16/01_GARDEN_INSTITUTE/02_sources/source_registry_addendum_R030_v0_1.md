# Source Registry Addendum — R-030

**Дата:** 17 июля 2026

## Foundations

- Lynch — paths, edges, nodes, landmarks and spatial legibility.
- Wayfinding and information-foraging traditions.
- Accessibility principles for non-spatial alternatives and reduced motion.
- Garden internal R-027, R-028 and R-029.
- Garden Trigger decks: Innovation, Human-centric, Graphic Design, Storytelling and Business Design.

## Evidence cautions

- physical wayfinding does not transfer directly to digital worlds;
- spatial interfaces are not inherently intuitive;
- direct access and world immersion must be tested together;
- map preference varies by task and user;
- trigger cards generate hypotheses, not evidence;
- accessibility requires testing with real assistive technologies and users.
