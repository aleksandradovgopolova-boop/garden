# Garden Evidence Card Template

```yaml
source_id:
title:
authors:
year:
publication:
doi:
official_url:
access_date:
source_type:
research_domain:
related_research:
audit_status:
quality_code:
peer_reviewed:
license:
commercial_use:
conflict_of_interest:
funding:
```

## 1. Исследовательский вопрос источника

Что именно изучали или утверждали авторы?

## 2. Дизайн

- тип исследования;
- выборка;
- страна и контекст;
- длительность;
- сравнение/контроль;
- основные измерения;
- метод анализа.

## 3. Основные результаты

Только результаты, реально присутствующие в источнике.

## 4. Что источник поддерживает для Garden

Список узких утверждений с Claim ID.

## 5. Чего источник не поддерживает

Какие популярные или соблазнительные выводы из него делать нельзя.

## 6. Ограничения

- размер и состав выборки;
- causality;
- self-report;
- attrition;
- multiple outcomes;
- replication;
- cultural transfer;
- clinical/non-clinical transfer;
- publication bias.

## 7. Риски продуктового переноса

Что может пойти не так при превращении результата в функцию?

## 8. Альтернативные объяснения

Какие ещё причины могли породить наблюдаемый результат?

## 9. Противоречащие источники

Какие работы показывают другую картину?

## 10. Лицензия и использование

- можно ли цитировать;
- можно ли воспроизводить шкалу;
- можно ли переводить;
- требуется ли атрибуция;
- возможно ли коммерческое использование;
- требуется ли отдельное разрешение.

## 11. Решение

- `use_as_foundation`
- `use_with_caution`
- `market_signal_only`
- `needs_replication`
- `do_not_use`
- `watch`

## 12. Связи

- Research ID:
- Claim ID:
- GDR:
- Product hypothesis:
- Chronicle entry:
