# Source Registry Addendum — R-028

**Дата:** 17 июля 2026

## Sources

- Scannell & Gifford (2010). Defining place attachment: A tripartite organizing framework.
- Lewicka (2008). Place attachment, place identity, and place memory.
- Lewicka (2011). Place attachment: How far have we come in the last 40 years?
- Hay (1998). Sense of place in developmental context.
- Rajala et al. (2020). The meaning(s) of place: structure of sense of place.
- Lynch (1960). The Image of the City.
- Appleton (1975). The Experience of Landscape.
- Dosen & Ostwald (2016). Evidence for prospect-refuge theory: a meta-analysis.
- Akcelik et al. (2024). Aesthetic preference through the lens of prospect-refuge theory.
- Lebrusán (2022). The importance of place attachment in understanding ageing in place.
- Garden internal R-019, R-020, R-024 and R-027.

## Evidence cautions

- physical-place attachment research does not directly validate digital place attachment;
- repeated exposure does not guarantee attachment;
- attachment may also complicate change, loss and departure;
- prospect-refuge findings are heterogeneous;
- public-space findings depend on culture, safety and social context;
- naming and templates require direct product testing;
- Garden must not deliberately optimize emotional dependency.
