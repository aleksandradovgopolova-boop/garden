# Garden Source Registry — Addendum for R-015

**Версия:** 0.1  
**Дата:** 16 июля 2026

## SRC-STR-001

**World Health Organization (2025).**  
*Social Determinants of Health.*  
Тип: official fact sheet  
Качество: A0 institutional  
Статус: full page reviewed

Defines social determinants as conditions of birth, growth, work, life and ageing and wider forces shaping daily life.

## SRC-STR-002

**World Health Organization (2025).**  
*World Report on Social Determinants of Health Equity.*  
Тип: authoritative international report  
Качество: A0 institutional  
Статус: report overview reviewed

Supports importance of access to power, money and resources for avoidable health inequities.

## SRC-STR-003

**World Health Organization (2010).**  
*A Conceptual Framework for Action on the Social Determinants of Health.*  
ISBN: `9789241500852`  
Тип: conceptual policy framework  
Качество: A0/B1  
Статус: official publication reviewed

Distinguishes structural determinants and intermediary determinants through long causal chains.

## SRC-STR-004

**World Health Organization.**  
*Determinants of Health.*  
Тип: official overview  
Качество: A0  
Статус: full page reviewed

Includes social/economic environment, physical environment and individual characteristics/behaviours.

## SRC-STR-005

**Phelan, J. C., Link, B. G., & Tehranifar, P. (2010).**  
*Social Conditions as Fundamental Causes of Health Inequalities.*  
PMID: `20943581`  
Тип: theory review  
Качество: B1  
Статус: abstract reviewed

Supports flexible resources—money, knowledge, prestige, power and social connections—as mechanisms protecting health across changing risks.

## SRC-STR-006

**Clouston, S. A. P., & Link, B. G. (2021).**  
*A Retrospective on Fundamental Cause Theory.*  
PMCID: `PMC8691558`; PMID: `34949900`  
Тип: retrospective review  
Качество: B1  
Статус: full text available/reviewed

Supports persistence of inequalities through unequal flexible resources and development of FCT evidence.

## SRC-STR-007

**Kennedy, W., et al. (2021).**  
*Using Ecological Models of Health Behavior to Promote Health Care Access and Physical Activity Engagement.*  
PMCID: `PMC8295941`  
Тип: applied framework review  
Качество: B1  
Статус: full text reviewed

Uses individual, interpersonal, organizational, community and policy levels.

## SRC-STR-008

**Melino, K., et al. (2022).**  
*Structural Competency in Health Care.*  
PMCID: `PMC9300050`  
Тип: scoping review/conceptual synthesis  
Качество: B1  
Статус: full text reviewed

Supports recognizing structural factors, limits of individual/cultural explanations and multilevel responses.

## SRC-STR-009

**Halsall, T., et al. (2025).**  
*Tracing the Undercurrents: A Scoping Review of the Lifestyle Drift Concept.*  
PMCID: `PMC12837583`  
Тип: scoping review, 32 included articles  
Качество: B1  
Статус: full text reviewed

Defines drift from upstream structural action toward downstream individual behavior and identifies proposed drivers/mitigation strategies.

Notes need for more empirical research.

## SRC-STR-010

**Marmot, M., et al. (2014).**  
*Social Determinants of Health Equity.*  
PMCID: `PMC4151898`  
Тип: policy/research synthesis  
Качество: B1  
Статус: full text reviewed

Discusses lifestyle drift and need to address causes of causes.

## SRC-STR-011

**Yao, R., et al. (2022).**  
*Inequities in Health Care Services Caused by the Adoption of Digital Health Technologies.*  
PMCID: `PMC8981004`  
Тип: scoping review  
Качество: B1  
Статус: full text reviewed

Supports pathways through which digital health can create or reproduce inequities.

## SRC-STR-012

**Weiss, D., et al. (2018).**  
*Innovative Technologies and Social Inequalities in Health: A Scoping Review.*  
PMCID: `PMC5882163`  
Тип: scoping review  
Качество: B1  
Статус: full text reviewed

Supports consideration of differential access, uptake and benefit.

## SRC-WORK-001

**World Health Organization (2019/current ICD-11 page).**  
*Burn-out an Occupational Phenomenon.*  
Тип: official classification explanation  
Качество: A0  
Статус: official page reviewed

Defines burnout as syndrome resulting from chronic workplace stress that has not been successfully managed and limits it to occupational context.

## SRC-WORK-002

**International Labour Organization (2022).**  
*Psychosocial Risks and Stress at Work.*  
Тип: official occupational-safety guidance  
Качество: A0  
Статус: official page reviewed

Lists work design and management hazards including workload, pace, hours and job control.

## SRC-WORK-003

**International Labour Organization.**  
*Psychosocial Risks and Mental Health at Work.*  
Тип: official topic guidance  
Качество: A0  
Статус: official page reviewed

Includes organizational culture, job security, relationships, bullying/harassment and working conditions.

## SRC-WORK-004

**Bes, I., et al. (2023).**  
*Organizational Interventions and Occupational Burnout: A Meta-Analysis.*  
PMCID: `PMC10560169`  
Тип: meta-analysis  
Качество: A1  
Статус: full text reviewed

Organization-directed and combined interventions showed small-to-moderate exhaustion reductions; workload-targeted and participatory interventions were among stronger categories.

## SRC-WORK-005

**Aust, B., et al. (2024).**  
*Effects of Different Types of Organisational Workplace Interventions on Mental Health and Well-Being in Healthcare Workers.*  
PMCID: `PMC11130054`  
Тип: systematic review/meta-analysis  
Качество: A1  
Статус: full text reviewed

Supports potential effectiveness of organizational interventions, especially implemented workplace changes; participatory interventions face implementation barriers.

## SRC-WORK-006

**Greiner, B. A., et al. (2022).**  
*Effectiveness of Organisational-Level Workplace Mental Health Interventions.*  
PMCID: `PMC9668198`  
Тип: systematic review  
Качество: A1/B1  
Статус: full text reviewed

Identifies team, task-allocation and participatory approaches; evidence base limited.

## SRC-WORK-007

**Kiratipaisarl, W., et al. (2024).**  
*Individual and Organizational Interventions to Reduce Burnout in Resident Physicians.*  
PMCID: `PMC11523819`; PMID: `39478552`  
Тип: systematic review/meta-analysis  
Качество: A1  
Статус: full text reviewed

Finds none-to-small practical effects overall with inconsistency and high risk of bias; recommends combined approach research.

## SRC-WORK-008

**Shoman, Y., et al. (2021).**  
*Predictors of Occupational Burnout: A Systematic Review.*  
PMCID: `PMC8430894`  
Тип: systematic review  
Качество: A1  
Статус: full text reviewed

Supports job demands, control/resources and effort–reward factors while noting mixed buffering evidence.

## New Source Registry fields

```yaml
problem_level:
root_cause:
immediate_mechanism:
user_control:
other_actor_control:
formal_responsibility:
resource_requirements:
power_asymmetry:
structural_determinant:
relief_or_resolution:
retaliation_risk:
external_verification:
lifestyle_drift_risk:
```
