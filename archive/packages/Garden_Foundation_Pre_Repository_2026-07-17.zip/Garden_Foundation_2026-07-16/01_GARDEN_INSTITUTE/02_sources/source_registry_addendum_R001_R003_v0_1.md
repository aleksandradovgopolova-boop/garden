# Garden Source Registry — Addendum for R-001–R-003

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Назначение:** новые и уточнённые Source ID после аудита первых трёх исследований.

## SRC-MOT-003

**Michie, S., van Stralen, M. M., & West, R. (2011).**  
*The Behaviour Change Wheel: A New Method for Characterising and Designing Behaviour Change Interventions.*  
DOI: `10.1186/1748-5908-6-42`  
Тип: peer-reviewed framework development  
Качество: B1  
Статус: full_text_reviewed

Поддерживает COM-B и взаимодействие capability, opportunity, motivation и behavior.

Не поддерживает автоматическую диагностику барьера ИИ или эффективность интерфейса Garden.

## SRC-COMP-004

**Breines, J. G., & Chen, S. (2012).**  
*Self-Compassion Increases Self-Improvement Motivation.*  
DOI: `10.1177/0146167212445599`  
Тип: четыре лабораторных эксперимента  
Качество: A2 для краткосрочного экспериментального вывода  
Статус: full_text_reviewed

Поддерживает: краткое self-compassion framing может повышать отдельные показатели corrective motivation.

Не поддерживает: долгосрочную привычку, retention или эффект любого тёплого UX-текста.

## SRC-COMP-005

**Neff, K. D. (2003).**  
*The Development and Validation of a Scale to Measure Self-Compassion.*  
DOI: `10.1080/15298860309027`  
Тип: определение конструкта и разработка шкалы  
Качество: A2/B1  
Статус: full_text_reviewed

Поддерживает исходную модель компонентов self-compassion и психометрическую проверку.

Ограничения: self-report и последующие дебаты о факторной структуре. Шкала не является пользовательским диагнозом.

## SRC-COMP-006

**Vidal, J., et al. (2022/2023).**  
*Effect of Compassion-Focused Therapy on Self-Criticism and Self-Soothing: A Meta-Analysis.*  
Тип: meta-analysis  
Качество: A1 с неоднородностью интервенций  
Статус: abstract_reviewed

Поддерживает среднее снижение self-criticism и рост soothing-related outcomes.

Не поддерживает использование Garden как CFT или терапевтического продукта.

## SRC-EMO-001

**Tangney, J. P., Stuewig, J., & Mashek, D. J. (2007).**  
*Moral Emotions and Moral Behavior.*  
DOI: `10.1146/annurev.psych.56.091103.070145`  
Тип: peer-reviewed review  
Качество: B1  
Статус: abstract_reviewed

Поддерживает различение guilt и shame и их типичные связи с reparative и avoidant/defensive responses.

Не поддерживает диагностику эмоции пользователя по одной формулировке.

## SRC-NAT-003

**Bowler, D. E., Buyung-Ali, L. M., Knight, T. M., & Pullin, A. S. (2010).**  
*A Systematic Review of Evidence for the Added Benefits to Health of Exposure to Natural Environments.*  
DOI: `10.1186/1471-2458-10-456`  
Тип: systematic review  
Качество: A1 с неоднородной доказательной базой  
Статус: abstract_reviewed

Поддерживает возможные эмоциональные преимущества природной среды; данные по вниманию и физиологии менее последовательны.

Не поддерживает перенос эффекта на цифровой сад.

## SRC-NAT-004

**Ohly, H., et al. (2016).**  
*Attention Restoration Theory: A Systematic Review of the Attention Restoration Potential of Exposure to Natural Environments.*  
DOI: `10.1080/10937404.2016.1196155`  
Тип: systematic review and meta-analyses  
Качество: A1  
Статус: abstract_reviewed

Поддерживает частичную поддержку ART по отдельным cognitive tests.

Не поддерживает единый эффект на всё внимание.

## SRC-NAT-005

**Roberts, H., et al. (2019).**  
*The Effect of Short-Term Exposure to the Natural Environment on Depressive Mood: A Systematic Review and Meta-Analysis.*  
DOI: `10.1016/j.envres.2019.108606`  
Тип: systematic review and meta-analysis  
Качество: A1, при этом качество включённых доказательств низкое/очень низкое  
Статус: abstract_reviewed

Поддерживает небольшой pooled effect на depressive mood.

Ограничения: высокий риск bias и значительная неоднородность.

## SRC-NAT-006

**Stevenson, M. P., Schilhab, T., & Bentsen, P. (2018).**  
*Attention Restoration Theory II.*  
DOI: `10.1080/10937404.2018.1505571`  
Тип: systematic review  
Качество: A1  
Статус: abstract_reviewed

Поддерживает более последовательные сигналы для executive attention и working memory при неоднородности методов.

## SRC-NAT-007

**Ulrich, R. S., et al. (1991).**  
*Stress Recovery During Exposure to Natural and Urban Environments.*  
DOI: `10.1016/S0272-4944(05)80184-7`  
Тип: controlled laboratory experiment  
Качество: A2 / foundational  
Статус: abstract_reviewed

Поддерживает более быстрое восстановление после stressor при природных сценах по ряду показателей в конкретном эксперименте.

Не поддерживает универсальность или эффект интерактивного wellbeing-продукта.

## SRC-NAT-008

**Hubbard, G., et al. (2025).**  
*A Systematic Literature Review and Meta-Analysis of Virtual Reality Nature Effects on Higher Education Students’ Mental Health and Wellbeing.*  
DOI: `10.1111/aphw.70060`  
Тип: systematic review and meta-analysis  
Качество: A1 с узкой аудиторией  
Статус: abstract_reviewed

Поддерживает emerging positive effects VR nature в higher-education populations.

## SRC-NAT-009

**Chen, L., et al. (2025).**  
*How Exposure to Virtual Natural Environments Reduces Anxiety and Related Outcomes: Systematic Review and Meta-Analysis.*  
Тип: systematic review and meta-analysis  
Качество: A1 с высокой неоднородностью  
Статус: abstract_reviewed

Поддерживает средние эффекты по отдельным self-reported outcomes у healthy adults.

Ограничения: высокая гетерогенность и небольшое число исследований для некоторых сравнений.

## Обновления существующих карточек

### SRC-HAB-001

Добавить:

- выборка 96 человек;
- стабильный контекст являлся частью дизайна;
- один пропуск возможности в исходной модели не разрушал процесс;
- среднее 66 дней нельзя использовать как обещание.

### SRC-COMP-001

Добавить:

- 27 randomized trials;
- неоднородность интервенций и контрольных групп;
- эффект тренинга нельзя переносить на одну AI-реплику.

### SRC-NAT-001

Использовать как широкий narrative review. Для конкретных утверждений предпочитать SRC-NAT-003–009.
