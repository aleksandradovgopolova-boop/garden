# Garden Source Registry — Addendum for R-011

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Контур:** `06_sources/source_registry_addenda/R-011.md`

---

## SRC-MEAS-001 — Measurement reactivity in EMA

**Maher, J. P., et al. (2024/2026 publication record).**  
*Measurement Reactivity in Ecological Momentary Assessment Studies of Movement-Related Behaviors.*  
PMID: `41726043`  
Тип: intensive longitudinal empirical study  
Качество: A2  
Статус: abstract/full metadata reviewed

Поддерживает:

- repeated assessment can coincide with early changes in measured behavior and motivational antecedents;
- researchers must distinguish true change from assessment artifact;
- reactivity may differ over protocol days.

Не поддерживает universal or uniformly harmful reactivity.

---

## SRC-MEAS-002 — EMA compliance and dropout

**Wrzus, C., & Neubauer, A. B. (2023).**  
*Ecological Momentary Assessment: A Meta-Analysis on Designs, Samples, and Compliance Across Research Fields.* Assessment, 30, 825–846.  
PMID: `35016567`; PMCID: `PMC9999286`  
Тип: meta-analysis, 496 samples, `N = 677,536`  
Качество: A1  
Статус: full text available / abstract reviewed

Поддерживает dependence of compliance and dropout on protocol and sample characteristics.

Не является прямым доказательством psychological harm.

---

## SRC-MEAS-003 — Stage-Based Model

**Li, I., Dey, A. K., & Forlizzi, J. (2010).**  
*A Stage-Based Model of Personal Informatics Systems.* CHI 2010.  
DOI: `10.1145/1753326.1753409`  
Тип: foundational HCI model  
Качество: B1  
Статус: abstract reviewed

Поддерживает five stages: preparation, collection, integration, reflection and action.

Не доказывает that passage through stages is linear or successful.

---

## SRC-MEAS-004 — Lived Informatics

**Epstein, D. A., Ping, A., Fogarty, J., & Munson, S. A. (2015).**  
*A Lived Informatics Model of Personal Informatics.* UbiComp 2015.  
DOI: `10.1145/2750858.2804250`  
Тип: empirical HCI model  
Качество: B1/B2  
Статус: abstract reviewed

Поддерживает non-linear everyday tracking, including lapses, tool switching, abandonment and resumed tracking.

---

## SRC-MEAS-005 — Personal Informatics, insight and behavior change

**Kersten-van Dijk, E. T., Westerink, J. H. D. M., Beute, F., & IJsselsteijn, W. A. (2017).**  
*Personal Informatics, Self-Insight, and Behavior Change: A Critical Review of Current Literature.* Human–Computer Interaction.  
DOI: `10.1080/07370024.2016.1276456`  
Тип: critical literature review  
Качество: B1  
Статус: abstract reviewed

Поддерживает critical examination of the assumed chain tracking → insight → behavior change.

---

## SRC-MEAS-006 — Unintended consequences of Personal Informatics

**Luo, Y., et al. (2025).**  
*Reflecting Upon the Unintended Consequences of Personal Informatics Technology.* CHI 2025.  
DOI: `10.1145/3715336.3735746`  
Тип: HCI review/framework  
Качество: B1/C1 recent  
Статус: abstract reviewed

Поддерживает the need to study unintended cognitive, emotional, behavioral and social consequences of self-tracking.

---

## SRC-MEAS-007 — Response shift theory

**Vanier, A., et al. (2021).**  
*Response Shift in Patient-Reported Outcomes: Definition, Theory, and a Revised Model.* Quality of Life Research.  
PMCID: `PMC8602159`  
Тип: theory and methodological synthesis  
Качество: B1  
Статус: full text available / abstract reviewed

Поддерживает response shift as change in the meaning of self-evaluation and a special case of longitudinal measurement non-invariance.

---

## SRC-MEAS-008 — Response shift systematic review

**Sawatzky, R., et al. (2024).**  
*Response Shift Results of Quantitative Research Using Patient-Reported Outcome Measures: A Systematic Review.* Quality of Life Research.  
Тип: systematic review  
Качество: A1  
Статус: abstract reviewed

Поддерживает that response-shift effects are detected across populations and methods, with variable prevalence and magnitude.

---

## SRC-MEAS-009 — COSMIN content validity

**Terwee, C. B., et al. (2018) and current COSMIN framework.**  
*COSMIN Methodology for Evaluating the Content Validity of Patient-Reported Outcome Measures.*  
PMCID: `PMC5891557`  
Тип: consensus-based methodology  
Качество: B1  
Статус: framework and official COSMIN site reviewed

Поддерживает:

- content validity as a core measurement property;
- relevance, comprehensiveness and comprehensibility;
- selection of an instrument based on construct, population and context.

---

## SRC-MEAS-010 — FDA Patient-Reported Outcome guidance

**U.S. Food and Drug Administration.**  
*Patient-Reported Outcome Measures: Use in Medical Product Development to Support Labeling Claims.*  
Тип: regulatory guidance  
Качество: institutional primary source  
Статус: official guidance page reviewed

Поддерживает treating a PRO instrument as questionnaire plus documentation, context of use, recall period, scoring and evidence.

Не applies directly to a general wellbeing consumer app, but provides a strong measurement discipline reference.

---

## SRC-MEAS-011 — Intensive repeated self-report

**Stone, A. A., et al. (2026).**  
*Intensive, Repeated Self-Report Measures: Should We Be Concerned About Their Effects on Data Quality?* JMIR mHealth and uHealth.  
Тип: methodological viewpoint with empirical illustrations  
Качество: B1/C1 recent  
Статус: full-text metadata reviewed

Supports considering habituation, reactivity, fatigue and change in response process.

---

## SRC-MEAS-012 — Passive sensing systematic review

**Shen, S. Y., et al. (2025).**  
*Passive Sensing for Mental Health Monitoring Using Machine Learning: Systematic Review.*  
PMCID: `PMC12395114`  
Тип: systematic review of 42 peer-reviewed studies  
Качество: A1  
Статус: abstract reviewed

Supports rapid growth alongside heterogeneity, small samples and validation/generalization limitations.

---

## SRC-MEAS-013 — Digital phenotyping standardization

**Alam, N. B., et al. (2025).**  
*Challenges and Standardisation Strategies for Sensor-Based Digital Phenotyping.* Communications Medicine.  
Тип: methodological review  
Качество: B1  
Статус: abstract reviewed

Supports lack of standardization, device/context dependencies, validation and reproducibility challenges.

---

## SRC-MEAS-014 — Goodhart/Campbell governance signal

**Mattson, C., et al. (2021).**  
*When a Measure Becomes a Target, It Ceases to Be a Good Measure.*  
PMCID: `PMC7901608`  
Тип: applied measurement commentary  
Качество: B1  
Статус: abstract reviewed

Supports dynamic corruption and distortion when measures become targets in evaluation systems.

Use as governance principle, not an empirical law with one universal effect size.

---

## SRC-MEAS-015 — Wellbeing measures scoping review

**Zhang, W., et al. (2024).**  
*A Scoping Review of Well-Being Measures.*  
PMCID: `PMC11515516`  
Тип: scoping review  
Качество: B1  
Статус: abstract reviewed

Supports plurality of wellbeing conceptualizations and instruments rather than one neutral universal score.

---

## SRC-MEAS-016 — Flexible Minimalist Self-Tracking

**Li, H., et al. (2024).**  
*Flexible Minimalist Self-Tracking to Support Individual Needs.* IMWUT.  
DOI: `10.1145/3660339`  
Тип: HCI design and evaluation research  
Качество: A2/B2  
Статус: abstract reviewed

Supports flexibility and minimalism as promising directions for reducing tracking burden while supporting personal questions.

Does not establish the optimal Garden design.

---

## SRC-MEAS-017 — Personal Informatics in everyday life

**Rapp, A., & Cena, F. (2016).**  
*Personal Informatics for Everyday Life: How Users Without Prior Self-Tracking Experience Engage With Personal Data.*  
Тип: diary study, 14 participants  
Качество: B2  
Статус: abstract reviewed

Supports that some novice users found collection burdensome and insufficiently rewarding.

---

## SRC-MEAS-018 — Personal Informatics concerns

**Ayobi, A., et al. (2016).**  
*Reflections on 5 Years of Personal Informatics: Rising Concerns and Emerging Directions.*  
Тип: HCI synthesis/workshop paper  
Качество: B1/C2  
Статус: identified

Use for field mapping; specific claims require primary sources.

---

## Новые поля Source Registry

```yaml
construct:
unit_of_analysis:
individual_or_group_use:
recall_period:
measurement_frequency:
content_validity:
reliability:
measurement_error:
responsiveness:
measurement_invariance:
response_shift_considered:
reactivity_measured:
participant_burden:
missing_data_assumption:
derived_score:
target_use:
passive_or_active:
feedback_shown:
```
