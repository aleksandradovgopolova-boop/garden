# Source Registry Addendum — R-033

Foundations: autobiographical-memory and reconstructive-memory traditions; HCI work on digital memories and resurfacing; privacy, provenance and deletion principles; Garden R-024, R-028, R-029, R-031 and R-032; relevant Trigger decks.

Cautions:

- digital records are not equivalent to human memory;
- semantic search may infer beyond user language and requires grounding;
- resurfacing can be welcome for some people and harmful for others;
- emotional meaning cannot be reliably inferred from media;
- rejection of knowledge graphs is a Garden product boundary, not a universal design rule;
- painful-memory safety requires dedicated user research.
