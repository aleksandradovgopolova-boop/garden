# Source Registry Addendum — R-023

**Дата:** 16 июля 2026

## Sources

- Fleming, R. W. (2014). Visual perception of materials and their properties.
- Harvey et al. (2021). Low-level visual features support robust material categorization.
- Schmid et al. (2023). Material category from specular image structure.
- Chadwick & Kentridge (2015). The perception of gloss: review.
- Roberts et al. (2024). Visual effects on tactile texture perception.
- Adams et al. (2016). Touch influences perceived gloss.
- Lacey & Sathian (2014). Visuo-haptic multisensory object recognition.
- Malik et al. (2026). Material qualities from moving contours.
- Sakamoto et al. (2017). Tactile perceptual dimensions using materials.
- Strappini et al. (2024). Sustainable materials, perception, affordance and aesthetics.
- Ranscombe et al. (2022). Material ageing and aesthetic appreciation.
- De Korte et al. (2022). Visual perception of changes in material surfaces over time.
- Wastiels et al. (2012). Material experience and perceived warmth.
- Zhao et al. (2023). Interior materials and perceived restorativeness.
- W3C WCAG 2.2 for non-text information and accessibility principles.

## Evidence cautions

- many studies use isolated rendered objects or laboratory samples;
- material perception differs between screen, VR and physical touch;
- aesthetic associations are context- and culture-dependent;
- “natural” appearance does not establish sustainability;
- patina studies are limited and material-specific;
- visual haptics do not reproduce full physical sensation.
