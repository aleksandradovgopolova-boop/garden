# Source Registry Addendum — R-025

**Дата:** 17 июля 2026

## Sources

- Rault (2015), Pets in the Digital Age: Live, Robot, or Virtual?
- Na et al. (2022), Mixed Reality-Based Interaction between Human and Virtual Animals.
- Johnson et al. (2023), Virtual animal stimuli in academic advising.
- Relatedness and Psychological Ownership in Augmented Reality (CHI 2019), longitudinal virtual-dog study.
- Northrope et al. (2025), systematic review of pet attachment and mental health/wellbeing.
- Friedmann et al. (2025), pet attachment and longitudinal psychological health.
- Lass-Hennemann et al. (2022), attachment to pets and mental-health burden.
- Ma et al. (2025), anthropomorphism, perceived intelligence and attachment/trust.
- Li et al. (2026), human-like conversational agents as social partners.
- Cihodaru-Ștefanache et al. (2025), anthropomorphism and emotional expectations.
- Research on deceptive game design, wildlife embodiment in VR and perceived natural diversity.

## Evidence cautions

- real-pet findings do not transfer directly to virtual animals;
- virtual-animal studies are often small or short-term;
- positive affect is not durable wellbeing evidence;
- attachment can be beneficial, neutral or burdensome;
- perceived biodiversity is not ecological biodiversity;
- symbolism and comfort vary across cultures.
