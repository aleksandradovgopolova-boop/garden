# Garden Source Registry — Addendum for R-004

**Версия:** 0.1  
**Дата:** 15 июля 2026  
**Контур:** `06_sources/source_registry_addenda/R-004.md`

---

## SRC-LANG-003

**Alderson-Day, B., & Fernyhough, C. (2015).**  
*Inner Speech: Development, Cognitive Functions, Phenomenology, and Neurobiology.* Psychological Bulletin, 141(5), 931–965.  
DOI: `10.1037/bul0000021`  
Тип: comprehensive peer-reviewed review  
Качество: B1  
Статус: full_text_available / abstract_reviewed

Поддерживает многофункциональность и вариативность inner speech.

Не поддерживает универсальность вербального внутреннего диалога и продуктовую технику Garden.

---

## SRC-LANG-004

**Kross, E., et al. (2014).**  
*Self-Talk as a Regulatory Mechanism: How You Do It Matters.* Journal of Personality and Social Psychology, 106(2), 304–324.  
DOI: `10.1037/a0035173`  
Тип: series of experiments  
Качество: A2  
Статус: abstract_reviewed

Поддерживает regulatory benefits non-first-person self-talk в конкретных экспериментальных задачах.

Не поддерживает универсальное назначение третьего лица.

---

## SRC-LANG-005

**Moser, J. S., et al. (2017).**  
*Third-Person Self-Talk Facilitates Emotion Regulation Without Engaging Cognitive Control.* Scientific Reports, 7, 4519.  
DOI: `10.1038/s41598-017-04047-3`  
Тип: experimental neurocognitive study  
Качество: A2  
Статус: full_text_available / abstract_reviewed

Поддерживает снижение ряда neural markers emotional reactivity при third-person self-talk в условиях исследования.

Ограничения: лабораторные стимулы и ограниченная переносимость на повседневный продукт.

---

## SRC-LANG-006

**Murdoch, E. M., Chapman, M. T., Crane, M. F., & Gucciardi, D. F. (2023).**  
*The Effectiveness of Self-Distanced Versus Self-Immersed Reflections Among Adults: Systematic Review and Meta-Analysis of Experimental Studies.* Stress and Health, 39(2), 255–271.  
DOI: `10.1002/smi.3199`  
Тип: systematic review and meta-analysis  
Качество: A1  
Статус: abstract_reviewed

Поддерживает средние преимущества distanced reflection по отдельным outcomes.

Ограничения: неоднородные манипуляции и задачи; нельзя считать универсальной техникой.

---

## SRC-LANG-007

**Schertz, K. E., et al. (2025).**  
*The Frequency, Form, and Function of Self-Talk in Everyday Life.* Scientific Reports, 15, 38883.  
DOI: `10.1038/s41598-025-22647-2`  
Тип: ecological momentary assessment study  
Качество: A2 / recent  
Статус: abstract_reviewed / watch

Поддерживает различия immersed/distanced self-talk в повседневности и контекстно зависимые функции.

Ограничения: один новый observational study; требует репликации и культурного расширения.

---

## SRC-LANG-008

**Wood, J. V., Perunovic, W. Q. E., & Lee, J. W. (2009).**  
*Positive Self-Statements: Power for Some, Peril for Others.* Psychological Science, 20(7), 860–866.  
DOI: `10.1111/j.1467-9280.2009.02370.x`  
Тип: experimental studies  
Качество: A2  
Статус: abstract_reviewed

Поддерживает возможность обратного эффекта чрезмерно позитивных self-statements у людей с низкой self-esteem.

Не поддерживает вывод, что позитивная речь всегда вредна.

---

## SRC-LANG-009

**Steindl, C., Jonas, E., Sittenthaler, S., Traut-Mattausch, E., & Greenberg, J. (2015).**  
*Understanding Psychological Reactance: New Developments and Findings.* Zeitschrift für Psychologie, 223(4), 205–214.  
DOI: `10.1027/2151-2604/a000222`  
Тип: peer-reviewed review  
Качество: B1  
Статус: full_text_available / abstract_reviewed

Поддерживает reactance как реакцию на воспринимаемую угрозу свободе.

Не поддерживает прогноз реакции конкретного пользователя на отдельную фразу.

---

## SRC-LANG-010

**Smit, E. S., Zeidler, C., Resnicow, K., & de Vries, H. (2019).**  
*Identifying the Most Autonomy-Supportive Message Frame in Digital Health Communication: A 2×2 Between-Subjects Experiment.* JMIR, 21(10), e14074.  
DOI: `10.2196/14074`  
Тип: digital health experiment, N=526  
Качество: A2  
Статус: abstract_reviewed

Поддерживает provision of choice как более выраженный signal perceived autonomy support в этом контексте.

Не поддерживает универсальную superiority конкретного wording.

---

## SRC-LANG-011

**Altendorf, M. B., van Weert, J. C. M., Hoving, C., & Smit, E. S. (2019).**  
*Should or Could? Testing Autonomy-Supportive Language and Choice in Online Alcohol Reduction Communication.* Digital Health, 5.  
DOI: `10.1177/2055207619832767`  
Тип: online experiment, N=521  
Качество: A2  
Статус: abstract_reviewed

В исследовании не обнаружены ожидавшиеся значимые основные эффекты autonomy-supportive wording и выбора на ключевые outcomes.

Урок: простая замена modal verbs не гарантирует autonomy support.

---

## SRC-LANG-012

**Shaw, C. A., & Gordon, J. K. (2021).**  
*Understanding Elderspeak: An Evolutionary Concept Analysis.* Innovation in Aging, 5(3).  
DOI: `10.1093/geroni/igab023`  
Тип: concept analysis/review  
Качество: B1  
Статус: full_text_available / abstract_reviewed

Поддерживает elderspeak как patronizing overaccommodation, часто основанную на добрых намерениях и стереотипах.

Перенос на Garden — cautionary, а не прямое доказательство для общей взрослой аудитории.

---

## SRC-LANG-013

**Healy, M., et al. (2022).**  
*How to Reduce Stigma and Bias in Clinical Communication.*  
Тип: peer-reviewed guidance/review  
Качество: B1  
Статус: abstract_reviewed

Поддерживает отказ от pejorative labels, инклюзивный и person-respecting language.

Не превращает person-first language в универсальное правило: предпочтения групп различаются.

---

## SRC-LANG-014

**Miller, W. R., & Rose, G. S. (2009).**  
*Toward a Theory of Motivational Interviewing.* American Psychologist, 64(6), 527–537.  
DOI: `10.1037/a0016830`  
Тип: theoretical model grounded in MI research  
Качество: B1  
Статус: full_text_available / abstract_reviewed

Поддерживает relational и technical components MI.

Не поддерживает заявление chatbot «использует MI» без fidelity assessment.

---

## SRC-LANG-015

**Liu, X., et al. (2025).**  
*Uncertainty Quantification and Confidence Calibration in Large Language Models: A Survey.* KDD 2025.  
arXiv: `2503.15850`  
Тип: technical survey  
Качество: B1/C1 для быстро развивающегося поля  
Статус: abstract_reviewed

Поддерживает проблему некалиброванной уверенности и разнообразие методов UQ.

Не даёт готового пользовательского языка uncertainty для Garden.

---

## SRC-LANG-016

**Sun, X., et al. (2026).**  
*Seeing the Reasoning: How LLM Rationales Influence User Trust and Decision-Making in Factual Verification Tasks.* CHI EA 2026.  
arXiv: `2603.07306`  
Тип: controlled HCI experiment, N=68  
Качество: A2/C1 recent  
Статус: full_text_reviewed

Поддерживает влияние certainty framing и rationale correctness на trust, confidence и advice adoption.

Ограничения: factual verification, небольшая выборка, не wellbeing-контекст.

---

## Реестр рисков R-004

| Risk ID | Риск | Источники |
|---|---|---|
| LR-001 | ложная позитивность активирует контраргументы | SRC-LANG-008 |
| LR-002 | директивность вызывает reactance | SRC-LANG-009 |
| LR-003 | язык выбора маскирует отсутствие выбора | SRC-LANG-010, 011 |
| LR-004 | заботливый тон становится инфантилизацией | SRC-LANG-012 |
| LR-005 | уверенный AI language создаёт overtrust | SRC-LANG-015, 016 |
| LR-006 | внешняя фраза присваивается как внутренняя истина | требует исследования Garden |
