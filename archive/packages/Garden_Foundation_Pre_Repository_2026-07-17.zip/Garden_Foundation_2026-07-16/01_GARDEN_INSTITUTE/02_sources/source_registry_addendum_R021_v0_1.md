# Source Registry Addendum — R-021

**Дата:** 16 июля 2026

## Authoritative and research sources

- CIE International Lighting Vocabulary — perceived colour and its attributes.
- CIE publications on colour appearance and stimulus size.
- W3C WCAG 2.2 — Use of Color, Contrast Minimum and Non-text Contrast.
- Elliot, A. J. (2015). Color and psychological functioning: review.
- Jonauskaite et al. (2025). Systematic review of colour-emotion associations.
- Jonauskaite et al. (2016). Object context and colour preferences.
- Álvaro et al. (2015). Colour preference in red–green dichromats.
- Al-Rasheed et al. and related cross-cultural colour-preference studies.
- Kawai et al. (2022). Cross-cultural implicit colour-valence associations.
- Leonard et al. (2025). Pastel colours and emotional response.

## Evidence cautions

- Many colour studies use small patches under controlled conditions.
- Screen, illumination and surround vary in real products.
- Cultural group averages do not justify personal inference.
- Emotion associations do not establish durable mood effects.
- Accessibility simulations do not replace user testing.
