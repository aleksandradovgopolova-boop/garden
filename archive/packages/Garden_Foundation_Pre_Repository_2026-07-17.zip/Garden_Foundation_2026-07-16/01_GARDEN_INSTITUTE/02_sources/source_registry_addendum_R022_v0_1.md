# Source Registry Addendum — R-022

**Дата:** 16 июля 2026

## Sources

- CIE publications on colour vision, brightness and lightness.
- W3C WCAG 2.2.
- W3C Understanding SC 2.3.3 Animation from Interactions.
- W3C technique C39 for `prefers-reduced-motion`.
- Madan et al. (2024), Restorative effects of daylight in indoor environments: systematic review.
- Karaman-Madan et al. (2026), Natural dynamics without nature? Motion type in light patterns.
- CIBSE research insight on circadian lighting.

## Evidence cautions

- physical-light findings do not directly transfer to screen rendering;
- daylight studies concern actual indoor light, not digital imagery;
- circadian effects require photometric and temporal exposure data;
- dynamic-light research is emerging;
- accessibility standards define minimum requirements, not complete comfort.
