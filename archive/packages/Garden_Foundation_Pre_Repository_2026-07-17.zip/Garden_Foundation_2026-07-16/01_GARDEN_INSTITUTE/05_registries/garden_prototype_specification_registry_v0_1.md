# Garden Prototype Specification Registry

| ID | Document | Status |
|---|---|---|
| S-001 | Screen Inventory | proposed |
| S-002 | Detailed Wireflows | proposed |
| S-003 | Content and Microcopy | proposed |
| S-004 | Responsive Rules | proposed |
| S-005 | Place Renderer Specification | proposed |
| S-006 | AI Preview and Diff | proposed |
| S-007 | Error, Empty and Recovery States | proposed |
| S-008 | Analytics Event Taxonomy | proposed |
| S-009 | Prototype Build Plan | proposed |
| S-010 | Research Script | proposed |
