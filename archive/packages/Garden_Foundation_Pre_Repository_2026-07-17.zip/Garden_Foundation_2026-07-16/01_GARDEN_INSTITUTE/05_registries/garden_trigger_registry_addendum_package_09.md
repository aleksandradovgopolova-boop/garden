# Trigger Registry — Package 09

| Research | Accepted | Rejected |
|---|---|---|
| R-035 | private and revocable | implied consent |
| R-036 | contextual presence | social graph |
| R-037 | first-person expression | diagnosis |
| R-038 | quiet by default | retention pressure |
| R-039 | begin with one place | profiling |
| R-040 | narrow vertical slice | feature-complete world |
