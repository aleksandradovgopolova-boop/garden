# Garden Visual Direction Registry

| ID | Document | Status |
|---|---|---|
| V-001 | Visual Territories | proposed |
| V-002 | References and Anti-references | proposed |
| V-003 | Color System | proposed |
| V-004 | Typography | proposed |
| V-005 | Spatial Language | proposed |
| V-006 | UI Surfaces | proposed |
| V-007 | Motion | proposed |
| V-008 | Visual Accessibility | proposed |
| V-009 | Alpha UI Kit | proposed |
| V-010 | Initial Screen Specifications | proposed |
