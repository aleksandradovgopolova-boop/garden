# Product Architecture Registry

| ID | Document | Status |
|---|---|---|
| P-001 | Information Architecture | proposed |
| P-002 | Core User Flows | proposed |
| P-003 | Interaction Model | proposed |
| P-004 | Visual Language | proposed |
| P-005 | Design System | proposed |
| P-006 | Entity Schemas | proposed |
| P-007 | AI Runtime | proposed |
| P-008 | Privacy and Security | proposed |
| P-009 | Frontend Architecture | proposed |
| P-010 | Prototype and Testing | proposed |
