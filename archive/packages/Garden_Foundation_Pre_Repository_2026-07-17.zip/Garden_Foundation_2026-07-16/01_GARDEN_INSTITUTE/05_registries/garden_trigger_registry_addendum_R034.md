# Garden Trigger Registry Addendum — R-034

| Research | Deck | Trigger | Hypothesis | Outcome |
|---|---|---|---|---|
| R-034 | Human-centric | А что если убрать всё лишнее? | Keep only functional relation types | accepted architecture |
| R-034 | Графический дизайн | А что если работать с композицией? | Composition replaces graph topology | accepted metaphor |
| R-034 | Инновации | А что если ограничение — преимущество? | Enumerated links prevent feature drift | accepted boundary |
| R-034 | Бизнес-дизайн | А что если два продукта не должны сливаться? | Garden and «Нити» stay separate | accepted strategic decision |
| R-034 | Нейминг | А что если назвать буквально? | Use concrete relation labels | accepted language direction |
