# Garden Trigger Registry v0.1

| Research | Deck | Trigger | Hypothesis | Outcome |
|---|---|---|---|---|
| R-029 | Human-centric | А что если идея ограничивает выбор? | Запрет autonomous persistent changes | accepted boundary |
| R-029 | Графический дизайн | А что если упростить до крайности? | Ambient-only aliveness | Alpha experiment |
| R-029 | Инновации | А что если до решения один клик или тап? | One-click scene presets | candidate |
| R-029 | Сторителлинг | А что если повествование скачет во времени? | Snapshot time travel | accepted direction |
| R-029 | Бизнес-дизайн | А что если бросить вызов главному тренду? | Отказ от live-service decay | strategic hypothesis |

Карточки не являются доказательствами. Реестр хранит также отклонённые интерпретации.
