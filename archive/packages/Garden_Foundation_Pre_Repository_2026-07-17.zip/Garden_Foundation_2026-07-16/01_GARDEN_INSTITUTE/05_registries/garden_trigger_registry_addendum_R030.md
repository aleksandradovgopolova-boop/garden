# Garden Trigger Registry Addendum — R-030

| Research | Deck | Trigger | Hypothesis | Outcome |
|---|---|---|---|---|
| R-030 | Инновации | А что если до решения один клик или тап? | Direct open for every important entity | accepted principle |
| R-030 | Human-centric | А что если идея ограничивает выбор? | Equal spatial and direct navigation | accepted boundary |
| R-030 | Графический дизайн | А что если создать структуру? | Garden → Place → Object → Content hierarchy | candidate |
| R-030 | Сторителлинг | А что если поделить на части? | Place-by-place experience | accepted direction |
| R-030 | Бизнес-дизайн | А что если людям нравится работать за вас? | User-created shortcuts and home places | candidate |
