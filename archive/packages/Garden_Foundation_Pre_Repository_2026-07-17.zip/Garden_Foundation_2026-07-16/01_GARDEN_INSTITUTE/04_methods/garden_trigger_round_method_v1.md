# Garden Trigger Round Method v1

Triggers are a divergence layer.

They are not evidence, principles, user needs or automatic product decisions.

## Workflow

1. Formulate the problem.
2. Select 3–6 relevant cards from different decks.
3. Translate each into a Garden hypothesis.
4. Check against philosophy, evidence, autonomy, safety, accessibility and scope.
5. Record the outcome: experiment, design question, proposed decision, deferred or rejected.

```yaml
trigger_use:
  research_id:
  problem:
  deck:
  card_prompt:
  garden_hypothesis:
  conflicts:
  evidence_needed:
  outcome:
  rationale:
```

> A trigger earns attention, not authority.
