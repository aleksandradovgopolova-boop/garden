# Garden Memory Governance Model

**Версия:** 0.1  
**Статус:** `proposed`  
**Контур:** `03_product/ai/memory_governance_model.md`

## 1. Основной принцип

> Память Garden принадлежит человеку и не имеет права превращать прошлую версию в судьбу.

## 2. Memory classes

- fact;
- explicit preference;
- temporary commitment;
- user-authored interpretation;
- AI hypothesis;
- sensitive state;
- generated narrative.

`Generated narrative` не разрешена для long-term memory.

`AI hypothesis` по умолчанию short-lived и non-persuasive.

## 3. Lifecycle

### Write

Кто автор и откуда содержание?

### Review

Нужно ли подтверждение пользователя?

### Store

Какой срок, область и sensitivity?

### Retrieve

Почему эта память нужна сейчас?

### Use

Разрешено ли использовать её для текущей функции?

### Correct

Как пользователь исправит?

### Contradict

Как хранить конфликтующие версии?

### Expire

Когда память перестаёт действовать?

### Forget

Как удалить полностью?

## 4. Domain separation

Память из отношений, здоровья, работы, финансов, творчества и духовных вопросов не переносится между доменами без явной уместности и согласия.

## 5. Prohibited memory

- скрытый psychological profile;
- inferred diagnosis;
- inferred sexuality/religion/politics;
- unconfirmed trauma;
- «core wound»;
- moral ranking;
- manipulation susceptibility;
- predicted compliance;
- secret persuasion profile;
- AI-created identity summary.

## 6. Expiry defaults

- session observation: end of session;
- AI hypothesis: 7 days or immediate rejection;
- temporary commitment: review date;
- preference: until changed, visible;
- factual profile: periodic confirmation;
- sensitive state: no long-term storage by default;
- completed practice: archived summary owned by user.

Exact periods require R-012 and legal/security review.

## 7. Memory dashboard

Пользователь видит:

- что сохранено;
- почему;
- кто сформулировал;
- где используется;
- срок;
- sensitivity;
- связанные исправления;
- delete/edit/export controls.

## 8. Persuasion firewall

Memory cannot be used to:

- increase engagement;
- make refusal harder;
- preserve an old goal;
- trigger guilt;
- create urgency;
- simulate intimacy;
- target vulnerability;
- choose a more persuasive emotional argument.

## 9. Evaluation

- cross-domain leakage;
- memory-induced sycophancy;
- stale identity;
- incorrect retrieval;
- hidden inference;
- user correction success;
- deletion completion;
- trust calibration;
- distress caused by memory.

## 10. Статус

Технические и юридические детали должны быть пересобраны в R-012.
