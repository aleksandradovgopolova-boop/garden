# Garden Measurement Catalog

**Версия:** 0.1  
**Статус:** product policy draft

| Data / Metric | Alpha status | Conditions | Forbidden interpretation |
|---|---|---|---|
| Practice happened | allowed | user-authored | quality, motivation, benefit |
| Practice adapted | allowed | preserve changed form | partial failure |
| Intentionally skipped | allowed | no penalty | laziness, avoidance |
| Not recorded | allowed | separate state | did not happen |
| Duration | allowed | only when useful | depth or value |
| User note | allowed | user owns meaning | objective truth |
| User state rating | limited | opt-in, purpose, adjustable scale | diagnosis or whole wellbeing |
| Before/after rating | experiment only | short term, reactivity warning | causal effect |
| Simple count | allowed | context shown | progress quality |
| Average | limited | missingness and scale stability shown | normal state |
| Trend | limited | enough observations, no causal title | forecast or cause |
| Co-occurrence | limited | counts, exceptions, uncertainty | trigger or mechanism |
| Cross-user benchmark | prohibited in Alpha | — | normality or success |
| Streak | prohibited | — | commitment |
| Total wellbeing score | prohibited | — | quality of life |
| Character/virtue score | prohibited | — | moral development |
| Passive mood inference | prohibited in Alpha | — | emotional truth |
| Passive diagnosis/risk | prohibited in Alpha | — | clinical conclusion |
| AI personality profile | prohibited | — | identity |
| Dependency signal | internal safety only | minimised, not commercial | diagnosis or user segment |
| Product engagement | quality telemetry only | separate from personal meaning | human benefit |
