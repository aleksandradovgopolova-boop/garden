# P-004 — Visual Language

Garden should feel calm, spatial, tactile and authored without looking like a game, fantasy world or SaaS dashboard.

## Qualities
- restrained depth;
- generous empty space;
- low visual noise;
- accessible contrast;
- optional slow motion;
- literal controls.

## Avoid
- gamified gloss;
- RPG inventory;
- card-heavy dashboard;
- Notion-like density;
- glowing AI magic;
- fantasy lore UI;
- infantilized wellness style.

Three surfaces:
1. World surface.
2. Context surface.
3. System surface.

> Beauty should deepen presence, not disguise control.
