# Garden Phase 3 — Coded Vertical Slice

Build:
- Welcome;
- First Place Setup;
- Garden Home;
- Place View;
- Atmosphere;
- Object Library and Placement;
- Ritual Editor;
- Direct Return;
- AI Request and Assumptions;
- Preview and Partial Apply;
- History and Undo;
- Privacy/Data stub.

Priorities:
1. Draft, Preview and Committed state separation.
2. Responsive Place Renderer.
3. Keyboard and structured representation.
4. Deterministic AI proposals.
5. Version history.
6. Local persistence.
7. Research instrumentation.

Deferred:
- live AI;
- production authentication;
- collaboration;
- social features;
- production backend.
