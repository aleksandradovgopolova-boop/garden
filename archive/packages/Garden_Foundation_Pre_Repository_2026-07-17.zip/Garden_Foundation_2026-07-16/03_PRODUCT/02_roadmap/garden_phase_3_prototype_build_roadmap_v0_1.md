# Garden Phase 3 — Prototype Build Roadmap

## Package 12 — Visual Direction and UI Foundations
- mood and reference analysis;
- visual territories;
- typography;
- color;
- spatial language;
- motion principles;
- initial UI kit.

## Package 13 — Coded Vertical Slice
- Welcome;
- First Place;
- Place Renderer;
- Object placement;
- Ritual;
- Direct Return;
- AI Preview;
- Apply and Undo.

## Package 14 — Research Round One
- moderated sessions;
- issue log;
- category-confusion analysis;
- accessibility findings;
- Alpha scope revision.

## Development decision
After Package 14:
- continue prototype;
- start technical Alpha;
- revise concept;
- stop a weak direction.
