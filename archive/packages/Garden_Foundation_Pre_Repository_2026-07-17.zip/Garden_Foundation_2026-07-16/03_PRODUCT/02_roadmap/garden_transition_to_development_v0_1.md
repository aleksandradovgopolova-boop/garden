# Transition to Development

Week 1: approve Alpha Constitution, create information architecture and core flow, freeze entities and AI actions.

Week 2: build HTML prototype and test first-session, first-return and Preview/Apply/Undo.

Week 3: revise scope, define technical architecture, build threat model and begin vertical slice.

Development starts after five to eight users complete the first-place flow and privacy, deletion, AI approval, versions and Undo are stable.
