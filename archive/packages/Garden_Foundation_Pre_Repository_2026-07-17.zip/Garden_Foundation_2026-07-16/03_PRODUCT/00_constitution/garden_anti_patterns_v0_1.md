# Garden Anti-patterns v0.1

Garden must not become a second brain, knowledge graph, notes app, productivity tracker, streak habit app, life simulator, RPG, social network, public identity platform, marketplace, AI therapist, autonomous life manager or Tamagotchi that punishes absence.
