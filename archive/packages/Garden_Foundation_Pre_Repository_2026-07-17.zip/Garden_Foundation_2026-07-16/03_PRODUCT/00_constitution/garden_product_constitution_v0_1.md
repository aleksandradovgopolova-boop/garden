# Garden Product Constitution v0.1

Garden protects authorship, privacy, continuity, silence, reversibility, literal meaning and voluntary return.

Garden refuses pressure, ranking, social performance, autonomous rewriting, emotional diagnosis, knowledge-graph drift and punishment for absence.

Every feature must answer:
1. Does it increase authorship?
2. Can it be refused?
3. Can it be undone?
4. Does it interpret the person?
5. Does it create pressure to return?
6. Does it move Garden toward game, tracker, network or second brain?
7. Can the value be delivered more quietly?
