# Garden Alpha Definition of Done

Done means: user value testable; no hard exclusion violated; keyboard path exists; empty/loading/offline/error states exist; privacy effect known; AI scope visible; destructive consequences explained; changes versioned; Undo present; telemetry minimal; no guilt copy; security tests pass; export/deletion documented.
