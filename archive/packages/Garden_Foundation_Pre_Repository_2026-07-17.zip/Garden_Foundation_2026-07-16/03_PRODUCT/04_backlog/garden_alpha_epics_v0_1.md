# Garden Alpha Epics

1. First Garden
2. Place Composition
3. Ritual Without Pressure
4. Direct Return
5. AI Co-creation
6. History and Undo
7. Privacy and Data Rights
8. Accessibility
9. Safety and Security
10. Prototype Research
