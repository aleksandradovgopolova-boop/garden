# Garden Next Work Plan

**Дата:** 16 июля 2026  
**Статус:** active roadmap

## Phase 1 — Canon freeze

- review Living Canon v1;
- mark accepted/amended sections;
- update older philosophy docs;
- create Canon change log.

## Phase 2 — Product model

- Ritual schema;
- Garden Object schema;
- lifecycle;
- review;
- memory;
- support;
- visual transformation rules.

## Phase 3 — UX architecture

- end-to-end flow;
- screen map;
- state map;
- empty states;
- error/safety states;
- accessibility;
- literal/metaphor toggle.

## Phase 4 — Visual world

- art direction;
- object families;
- garden spaces;
- animation principles;
- sound;
- day/night;
- customization rules;
- anti-score design.

## Phase 5 — AI behavior

- prompts;
- modes;
- epistemic labels;
- refusal/boundary behavior;
- memory rules;
- fixation tests;
- structural-context guardrails.

## Phase 6 — Alpha prototype

- clickable prototype;
- concierge backend;
- minimal persistence;
- review flow;
- delete/export;
- study instrumentation.

## Phase 7 — Research

- Stage 0 visual comprehension;
- Stage 1 longitudinal;
- Stage 2 comparator;
- build / narrow / stop decision.


## R-018 amendment

Before final UX architecture, test ritual-first and place-first creation models and define spatial continuity, safe departure and world ownership.
