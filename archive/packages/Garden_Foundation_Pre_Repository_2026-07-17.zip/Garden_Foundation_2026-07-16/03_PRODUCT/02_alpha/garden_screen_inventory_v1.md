# Garden Screen Inventory v1

**Статус:** `working inventory`

| ID | Screen | Alpha | Core purpose |
|---|---|---:|---|
| WF-01 | Welcome | Yes | Explain Garden and ownership |
| WF-02 | Garden Setup | Yes | Create initial world |
| WF-03 | Garden Home | Yes | Primary personal place |
| WF-04 | Create Menu | Yes | Start ritual/place/object |
| WF-05 | Current Direction | Yes | Name what matters |
| WF-06 | Ritual Design | Yes | Define ritual |
| WF-07 | Garden Form | Yes | Choose object |
| WF-08 | Placement | Yes | Place object |
| WF-09 | Place Creation | Variant | Test place-first |
| WF-10 | Place Detail | Yes | Manage place |
| WF-11 | Ritual Detail | Yes | Manage ritual |
| WF-12 | Review | Yes | Bounded reflection |
| WF-13 | Lifecycle Decision | Yes | Continue/adapt/rest/complete |
| WF-14 | Transformation | Yes | Choose visual outcome |
| WF-15 | Archive | Yes | Preserve selected history |
| WF-16 | Memory & Privacy | Yes | Data control |
| WF-17 | Settings | Yes | World/accessibility/data |
| WF-18 | Literal Mode | Yes | Full non-metaphor mode |
| WF-19 | Safety Mode | Yes | High-risk boundary |
