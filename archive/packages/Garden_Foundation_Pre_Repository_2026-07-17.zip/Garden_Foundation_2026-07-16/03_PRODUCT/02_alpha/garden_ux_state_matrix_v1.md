# Garden UX State Matrix v1

**Статус:** `working matrix`

| Entity | State | Visual behavior | User actions | Forbidden behavior |
|---|---|---|---|---|
| Garden | New | Mostly empty | Create place/ritual, explore | Pressure to fill |
| Garden | Active | User-authored | Edit, observe, create | Score overlay |
| Garden | Quiet | Unchanged | Return, edit, leave | Decay |
| Place | Active | Normal | Add/edit/archive | Psychological label |
| Place | Quiet | Unchanged | Resume/edit | Neglect state |
| Ritual | Seeded | Neutral | Activate/edit/delete | “Incomplete” warning |
| Ritual | Active | User-selected | Review/adapt/rest | Growth requirement |
| Ritual | Adapting | Chosen transformation | Confirm/revert | Automatic AI change |
| Ritual | Resting | Unchanged or chosen marker | Resume/complete | Wilting |
| Ritual | Integrated | Landscape object optional | Keep/archive | Forced removal |
| Ritual | Completed | Memorial/decorative optional | Restore/archive/delete | “Stopped streak” |
| Ritual | Released | User-selected outcome | Delete/archive/keep | Shame copy |
| Object | Normal | Stable | Move/edit/delete | Rarity status |
| Object | Decorative | Stable | Re-link/archive | Loss of meaning |
| Object | Archived | Hidden from garden | Restore/delete | Irreversible lock |
