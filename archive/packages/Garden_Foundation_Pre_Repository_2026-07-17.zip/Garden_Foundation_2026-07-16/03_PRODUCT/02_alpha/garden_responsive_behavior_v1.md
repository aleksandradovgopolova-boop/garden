# Garden Responsive Behavior v1

**Статус:** `working specification`

## Desktop ≥ 1280

- persistent sidebar;
- full garden canvas;
- contextual right panel;
- drag-and-drop editing;
- multi-column creation flows.

## Small desktop / tablet landscape 1024–1279

- compact sidebar;
- context panel overlays;
- edit mode may reduce canvas;
- creation uses modal/sheet.

## Tablet portrait 768–1023

- rail navigation;
- full-screen detail;
- simplified object placement;
- two-step editor.

## Mobile ≤ 767

- bottom navigation;
- canvas first;
- full-screen flows;
- bottom sheets;
- list alternative;
- preset move/scale controls;
- no hover dependencies.

## Accessibility override

At any width:

- list mode available;
- reduced motion respected;
- keyboard alternative available;
- sound optional;
- no drag-only task.
