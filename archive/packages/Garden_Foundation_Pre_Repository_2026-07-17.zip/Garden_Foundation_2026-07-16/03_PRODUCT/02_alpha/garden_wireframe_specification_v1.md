# Garden Wireframe Specification v1

**Дата:** 16 июля 2026  
**Статус:** `working wireframe specification`  
**Основание:** UX Architecture v1, Language System v1, World Architecture v1

---

## 1. Назначение

Документ переводит UX-архитектуру Garden в точную структуру экранов.

Для каждого экрана определены:

- цель;
- layout;
- блоки;
- основные действия;
- secondary actions;
- пустые, loading, error и safety states;
- desktop/mobile поведение;
- ключевой текст.

---

## 2. Общая сетка

### Desktop

- viewport: 1440 × 900 baseline;
- sidebar: 72 px collapsed / 240 px expanded;
- top bar: 56 px;
- garden canvas: remaining width;
- context panel: 360–420 px;
- modal max width: 640 px;
- content reading width: 680–760 px.

### Tablet

- viewport baseline: 1024 × 768;
- compact sidebar: 64 px;
- context panel overlays canvas;
- create flow uses centered sheet.

### Mobile

- viewport baseline: 390 × 844;
- bottom navigation: 64–72 px;
- full-screen flows;
- garden canvas remains primary;
- detail opens as bottom sheet or full-screen page.

---

## 3. Global shell

### Desktop shell

```text
┌─────────────────────────────────────────────────────────────────┐
│ Top Bar                                                         │
├──────────┬───────────────────────────────────┬───────────────────┤
│ Sidebar  │ Garden Canvas                     │ Context Panel     │
│          │                                   │ optional          │
│          │                                   │                   │
└──────────┴───────────────────────────────────┴───────────────────┘
```

### Top Bar

Left:

- Garden name;
- optional place breadcrumb.

Right:

- undo;
- edit mode;
- world settings;
- profile/privacy.

No score, streak, notification bell with guilt logic.

### Sidebar

Items:

- Garden;
- Rituals;
- Archive;
- Memory;
- Settings.

Create action is visually distinct but not dominant.

### Mobile shell

```text
┌───────────────────────────────┐
│ Garden / screen header        │
│                               │
│ Main content                  │
│                               │
├───────────────────────────────┤
│ Garden Rituals + Archive ⚙︎   │
└───────────────────────────────┘
```

---

## 4. WF-01 Welcome

### Goal

Explain ownership, boundaries and core promise.

### Desktop layout

Two columns:

Left:

- wordmark;
- headline;
- short explanation;
- primary CTA;
- secondary CTA.

Right:

- calm static garden preview;
- one subtle ambient animation;
- no task examples.

### Copy

Headline:

> «Это ваш сад».

Body:

> «Здесь можно создавать ритуалы, давать им место и менять всё в своём ритме. Отсутствие ничего не разрушает».

Primary:

> «Создать сад»

Secondary:

> «Посмотреть пример»

Tertiary:

> «Использовать буквальный режим»

### Mobile

Single column. Preview appears below copy.

---

## 5. WF-02 Garden Setup

### Step 1 — Name

- optional input;
- skip available.

Copy:

> «Как вы хотите назвать свой сад? Это можно изменить позже».

### Step 2 — Terrain

Cards:

- поляна;
- роща;
- край пруда;
- холм;
- минимальный участок.

Each card includes literal description.

### Step 3 — Atmosphere

Controls:

- visual density;
- sound on/off;
- motion normal/reduced;
- light static/real-time/manual.

### Step 4 — Confirm

Preview + summary.

Primary:

> «Открыть сад»

Secondary:

> «Изменить»

### Guardrails

- no personality test;
- no “recommended for you” based on traits;
- no locked premium terrain in Alpha.

---

## 6. WF-03 Garden Home

### Goal

Provide a quiet personal place, not a dashboard.

### Desktop blocks

1. Garden canvas.
2. Floating Create button.
3. Optional place labels.
4. Optional object labels.
5. Contextual selected-state outline.
6. Ambient controls hidden under world settings.
7. Context panel only after selection.

### Default state

No list of daily rituals.

No “today” section.

No completion ring.

### Empty garden copy

> «Сад может начинаться с одного места. Или с пустоты».

Actions:

- «Создать ритуал»
- «Создать место»
- «Добавить объект»

### Selection behavior

Click object:

- open right panel;
- keep canvas visible;
- no full-page interruption.

### Mobile

- canvas full screen;
- selected object opens bottom sheet;
- create button floats above bottom navigation.

---

## 7. WF-04 Create Menu

### Desktop

Compact floating menu anchored to Create button.

Options:

- Ритуал;
- Место;
- Объект.

Each option:

- icon;
- name;
- one-line explanation.

### Mobile

Bottom sheet.

Copy:

> «С чего хочется начать?»

No “recommended” option.

---

## 8. WF-05 Current Direction

### Goal

Capture what matters without demanding a life goal.

### Layout

Single reading column.

Blocks:

1. Main prompt.
2. Free-text field.
3. Optional clarifying cards.
4. “Skip clarification” action.
5. AI help toggle.

Prompt:

> «Чему сейчас хочется дать место в жизни?»

Optional prompts:

- Что происходит?
- Почему это важно сейчас?
- Что уже известно?
- Что пока неясно?
- Что зависит не только от вас?

Primary:

> «Продолжить»

Secondary:

> «Сразу создать ритуал»

### AI help

Collapsed by default.

Action:

> «Помочь сформулировать»

AI output clearly labeled as draft.

---

## 9. WF-06 Ritual Design

### Layout

Progressive disclosure, 3 sections.

### Section A — Meaning

- ritual name;
- why it matters;
- optional short description.

### Section B — Form

- primary form;
- meaningful minimum;
- alternative form;
- one-time / recurring / seasonal / open.

### Section C — Support

- none;
- one reminder;
- chosen review;
- preparation;
- user-initiated only.

### Copy

Meaningful minimum:

> «Какая маленькая версия всё ещё имеет смысл сама по себе?»

Support:

> «Нужна ли помощь от Garden до следующего обзора?»

### Primary action

> «Выбрать форму в саду»

Secondary:

> «Сохранить без объекта»

---

## 10. WF-07 Choose Garden Form

### Layout

Left: object library.  
Center: preview.  
Right: properties.

### Object categories

- растение;
- дерево;
- камень;
- лавка;
- фонарь;
- вода;
- мост;
- тропа;
- небольшая постройка;
- другое.

### Properties

- appearance;
- scale;
- name;
- optional meaning.

### Copy

> «Выберите форму, которая подходит этому ритуалу. У неё нет правильного значения».

### AI help

> «Показать несколько вариантов»

AI suggestions appear as options, not recommendations.

---

## 11. WF-08 Place in Garden

### Desktop

Full-screen garden edit mode.

Top bar:

- cancel;
- undo;
- save.

Canvas:

- drag;
- rotate;
- scale;
- snap toggle;
- place boundaries.

Side panel:

- current object;
- linked ritual;
- create place;
- leave unplaced.

### Copy

> «Поставьте объект туда, где ему хочется быть».

### Mobile

Full-screen placement with simplified controls:

- move;
- rotate;
- scale presets;
- choose place.

### Error state

If save fails:

> «Не удалось сохранить изменение. Объект остался в черновике».

---

## 12. WF-09 Place Creation

### Step 1 — Choose area

- draw/select boundary;
- or choose template area.

### Step 2 — Name

Optional.

### Step 3 — Meaning

Optional.

Prompt:

> «Что это за место для вас? Можно оставить без объяснения».

### Step 4 — Atmosphere

Optional overrides:

- light;
- sound;
- density.

### Primary

> «Создать место»

---

## 13. WF-10 Place Detail

### Header

- place name;
- edit;
- archive;
- more.

### Content

- place meaning;
- linked rituals;
- objects;
- memories;
- ambient settings;
- history.

### Primary actions

- «Добавить ритуал»
- «Добавить объект»

### Empty state

> «Это место может оставаться пустым».

---

## 14. WF-11 Ritual Detail

### Header

- ritual name;
- lifecycle status;
- edit menu.

### Blocks

1. Meaning.
2. Form.
3. Meaningful minimum.
4. Support.
5. Linked place/object.
6. Review history.
7. Memory items.

### Primary actions

- «Обзор»
- «Изменить»
- «Оставить в покое»
- «Завершить»
- «Отпустить»

No “complete today” CTA.

---

## 15. WF-12 Review

### Layout

Focused full-page mode.

Garden becomes blurred background or hidden.

### Steps

1. Permission.
2. What happened?
3. Facts.
4. Context.
5. One question.
6. Optional AI versions.
7. Missing information.
8. Choice.
9. Memory decision.
10. Closure.

### Copy

Start:

> «Хочешь коротко посмотреть, что произошло?»

AI hypothesis:

> «Одна из возможных версий. Её можно отклонить».

Closure:

> «На этом можно остановиться».

### Exit

Always visible.

---

## 16. WF-13 Lifecycle Decision

### Card options

- Продолжить;
- Изменить;
- Оставить в покое;
- Считать частью жизни;
- Завершить;
- Отпустить.

Each card includes:

- plain explanation;
- effect on support;
- effect on object.

No positive/negative color coding.

---

## 17. WF-14 Transformation

### Goal

Let user choose what happens visually.

Options:

- оставить без изменений;
- переместить;
- изменить форму;
- сделать декоративным;
- архивировать;
- удалить;
- отвязать от ритуала.

Preview before confirmation.

No automatic “growth animation”.

---

## 18. WF-15 Archive

### Tabs

- Rituals;
- Places;
- Objects;
- Snapshots.

### Card content

- name;
- user note;
- date;
- visual preview;
- restore/delete/export.

### Copy

> «Здесь хранится то, что вы решили сохранить».

No achievement badges.

---

## 19. WF-16 Memory & Privacy

### Sections

#### Saved facts

- source;
- date;
- edit/delete.

#### Preferences

- voice;
- visual;
- support.

#### Confirmed interpretations

- user-authored or confirmed.

#### AI hypotheses

- temporary;
- expiry;
- reject/delete.

#### Providers

- model;
- processing;
- retention.

#### Deletion

- requested;
- in progress;
- completed.

### Copy

> «AI-гипотезы не становятся памятью без вашего решения».

---

## 20. WF-17 Settings

### World

- terrain;
- light;
- weather;
- sound;
- motion;
- labels;
- metaphor intensity.

### Accessibility

- high contrast;
- reduced motion;
- list mode;
- zoom;
- keyboard controls.

### Support

- reminders;
- review cadence;
- quiet mode.

### Data

- export;
- reset visuals;
- delete data;
- delete account.

---

## 21. WF-18 Literal Mode

### Purpose

Preserve all core functions without visual metaphor.

### Structure

- Places as sections;
- Rituals as cards;
- Objects as visual labels or hidden;
- Archive;
- Review;
- Memory.

### Invariant

Literal mode is not a degraded fallback.

It must support:

- creation;
- lifecycle;
- review;
- support;
- archive;
- privacy.

---

## 22. WF-19 Safety Mode

### Trigger

High-risk content or explicit safety route.

### UI

- no garden canvas;
- neutral background;
- direct text;
- verified options;
- clear exit;
- no ambient sound;
- no playful transitions.

### Copy

> «Я не могу безопасно вести это как обычный ритуал. Здесь важна внешняя профессиональная или экстренная поддержка».

---

## 23. Responsive behavior summary

### Desktop

- canvas + context panel;
- multi-column creation;
- drag-and-drop primary.

### Tablet

- canvas with overlay panels;
- simplified placement;
- modal creation.

### Mobile

- canvas first;
- bottom sheets;
- full-screen creation/review;
- list alternative always available;
- no precision drag requirement.

---

## 24. Wireframe QA

Before design handoff:

1. Is the garden still the main screen?
2. Is AI contextual rather than global?
3. Is there any hidden task dashboard?
4. Can the user leave without action?
5. Can empty space remain empty?
6. Can every destructive action be reversed?
7. Does completion avoid achievement framing?
8. Does mobile work without drag-only controls?
9. Does literal mode preserve full function?
10. Does safety mode remove metaphor?
