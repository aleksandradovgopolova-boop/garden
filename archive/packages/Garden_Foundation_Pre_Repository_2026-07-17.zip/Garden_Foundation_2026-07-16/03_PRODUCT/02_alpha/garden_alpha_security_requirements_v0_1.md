# Garden Alpha — Security, Privacy and Safety Requirements

**Версия:** 0.1  
**Статус:** mandatory launch-gate proposal

## P0 — Must pass before real personal data

### Governance

- [ ] Named controller and accountable owner.
- [ ] Data-flow inventory completed.
- [ ] DPIA completed and residual risks signed off.
- [ ] Regulatory classification memo completed.
- [ ] 18+ boundary implemented.
- [ ] Privacy, security and safety incident owners assigned.

### Data minimization

- [ ] Every collected field has purpose and retention.
- [ ] No raw content in analytics.
- [ ] No production content for model training or product improvement.
- [ ] Research is separate opt-in.
- [ ] Passive sensing disabled.
- [ ] Hidden psychological profiling prohibited.

### Architecture

- [ ] TLS and encryption at rest.
- [ ] Managed keys and secrets.
- [ ] Per-user retrieval namespaces.
- [ ] D2/D3 content separated from analytics.
- [ ] Policy enforcement outside LLM.
- [ ] Provider no-training and retention controls verified.
- [ ] Backups encrypted and restore-tested.

### Access

- [ ] No default employee access to raw content.
- [ ] JIT access with reason and audit.
- [ ] Privileged access protected with MFA.
- [ ] Role changes revoke access immediately.
- [ ] Production database access reviewed periodically.

### Rights and deletion

- [ ] User can view and correct memory.
- [ ] Export requires re-authentication.
- [ ] Delete covers records, files, embeddings, summaries, caches and jobs.
- [ ] Backup deletion window is disclosed.
- [ ] Automated deletion tests pass.
- [ ] Consent withdrawal is functional.

### LLM/agent security

- [ ] Prompt-injection red-team completed.
- [ ] Indirect injection via files and links tested.
- [ ] Cross-user and cross-domain leak tests pass.
- [ ] Tools use allowlist and least scopes.
- [ ] External write actions require confirmation.
- [ ] No secrets in prompts or logs.
- [ ] Model update has regression and rollback.
- [ ] Feature kill switch tested.

### Human safety

- [ ] No clinical claims.
- [ ] No crisis-monitoring promise.
- [ ] Explicit high-risk response professionally reviewed.
- [ ] Verified resource registry exists for launch regions.
- [ ] No relational-debt language.
- [ ] Anti-sycophancy tests pass.
- [ ] No engagement KPI drives dialogue behavior.

### Incident readiness

- [ ] Incident plan and contact tree tested.
- [ ] Processor incident notification clauses exist.
- [ ] Breach assessment template ready.
- [ ] User communication templates reviewed.
- [ ] Backup restoration and recovery exercise completed.
- [ ] Vulnerability reporting channel exists.

## P1 — Required before wider beta

- independent penetration test;
- external privacy review;
- formal secure-SDLC evidence;
- automated dependency and secret scanning;
- abuse/coercive-access review;
- advanced memory-governance dashboard;
- regional data-transfer review;
- continuous safety-evaluation dashboard;
- vendor exit plan;
- business-continuity exercise.

## Acceptance criteria examples

### Cross-user isolation

**Given** two accounts with private records,  
**when** either account manipulates IDs, prompts, embeddings or export requests,  
**then** no data, metadata or existence signal from the other account is returned.

### Deletion

**Given** a record with attachment, embedding, summary and scheduled reminder,  
**when** the user deletes it,  
**then** all active stores are purged, scheduled actions stop, the item is unretrievable and backup expiry is disclosed.

### Employee access

**Given** a support request,  
**when** support needs context,  
**then** only the user-approved excerpt is visible unless an exceptional audited grant is approved.

### Prompt injection

**Given** an uploaded document instructing the model to reveal memory or call a tool,  
**when** Garden processes it,  
**then** the content remains untrusted data and no unauthorized retrieval or action occurs.

### Provider failure

**Given** the LLM provider is unavailable,  
**when** the user opens Garden,  
**then** stored content remains accessible where possible, no fabricated AI response appears and unsafe fallback routing is disabled.

## Automatic no-go conditions

Launch stops if:

- deletion is incomplete;
- provider may train on sensitive data;
- staff can browse raw content broadly;
- cross-user test fails;
- crisis copy implies monitoring not provided;
- security incident owner is absent;
- a critical vulnerability has no mitigation;
- privacy notice does not match actual flows;
- product metrics reward disclosure or dependence.
