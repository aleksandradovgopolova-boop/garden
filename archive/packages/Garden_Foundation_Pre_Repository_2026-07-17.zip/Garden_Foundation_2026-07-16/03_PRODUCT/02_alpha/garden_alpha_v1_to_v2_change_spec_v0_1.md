# Garden Alpha Blueprint v1 → v2 Change Specification

**Версия:** 0.1  
**Дата:** 16 июля 2026  
**Статус:** required rewrite specification  
**Input:** Alpha Blueprint v1  
**Output:** future Alpha Blueprint v2

---

## 1. Status change

### Current

`готов к подготовке и запуску`

### Required

`superseded — do not launch`

Alpha v2 remains `draft` until:

- GDR hard blockers are accepted;
- DPIA and data flow are reviewed;
- provider and storage are selected;
- deletion is tested;
- crisis and participant safety protocol is reviewed;
- research consent and access roles exist.

---

## 2. Core wedge

### v1

One important ritual lived for 14 days.

### v2

> One current direction → one chosen practice or action → one bounded review.

The research window may be 10–14 days, but:

- the practice need not be daily;
- it may complete early;
- it may be one-off;
- pause and release are valid;
- the study period is not a habit-formation claim.

---

## 3. Core research question

### Replace with

> Does Garden create incremental value beyond a plain note, reminder, habit tracker or generic AI chat by helping a person choose, try and adapt one meaningful real-world practice with less pressure and more calibrated understanding?

Secondary questions:

- Can users distinguish fact from AI hypothesis?
- Does bounded reflection produce enough value?
- Is no-streak support understandable?
- Does the product add burden?
- Can users stop or complete without guilt?
- Are privacy and memory boundaries understood?

---

## 4. Study stages

### Stage 0 — Concept and comprehension

**5–8 participants**

Test:

- category language;
- practice concept;
- status model;
- epistemic labels;
- no-score promise;
- privacy explanation;
- metaphor/literal mode.

No sensitive longitudinal data required.

### Stage 1 — Concierge wedge

**12–18 participants**

One direction, one practice/action, limited observation.

Use qualitative depth; do not claim statistical efficacy.

### Stage 2 — Comparator pilot

Only after Stage 1 safety review.

Compare Garden with at least one simple alternative:

- plain note + reminder;
- generic AI prompt;
- standard habit tracker.

---

## 5. Participant boundary

### Include

Adults 18+ who:

- have a non-clinical current direction;
- can consent to research;
- understand that Garden is not therapy or crisis monitoring;
- can use a low-risk practice/action;
- are willing to discuss burden and disagreement.

### Exclude from first longitudinal pilot

- active crisis requiring immediate professional support;
- request for diagnosis or treatment;
- unsafe coercive relationship scenario requiring specialist response;
- activity with significant medical/legal/financial risk;
- participant unable to use a private device;
- employer-mandated participation.

Exclusion is a research boundary, not judgment of the person.

---

## 6. Core object

Rename `Ritual Card` to `Practice Card`.

```yaml
practice_id:
current_direction:
user_wording:
meaning:
practice_type:
full_or_primary_form:
meaningful_minimum:
alternative_form:
context:
resources:
control_and_responsibility:
support_choice:
review_time:
measurement_choice:
status:
```

Statuses:

- proposed;
- active;
- adapting;
- resting;
- integrated;
- completed;
- released;
- archived.

No `failed`.

---

## 7. Measurement design

### Remove as default

- mandatory daily form;
- mandatory daily status;
- 48-hour return metric;
- implied completeness target;
- fixed baseline score set.

### Provide modes

#### M0 — No tracking

Only setup and review.

#### M1 — Event note

User records an event when useful.

#### M2 — Chosen check-in

User chooses a limited cadence.

#### M3 — Temporary experiment

A specific question, measure and end date.

Every participant sees:

- purpose;
- frequency;
- what data cannot prove;
- how to stop;
- retention.

---

## 8. Interaction cadence

The study does not contact the participant daily by default.

Possible cadence:

- setup;
- user-triggered contact;
- one optional midpoint review;
- chosen reminder/support;
- final review.

Repeated prompts are part of the experimental condition and must be documented as intervention.

---

## 9. Reflection protocol

Every review follows:

1. Permission.
2. Concrete event.
3. Facts.
4. Context.
5. One question.
6. Maximum two labelled hypotheses.
7. Alternative or missing information.
8. Choice.
9. Closure.
10. Memory decision.

Modes:

- Record;
- Understand;
- Decide;
- Release.

---

## 10. Support design

At setup ask only:

> «Нужна ли тебе поддержка от Garden до review?»

Options:

- none;
- one reminder;
- preparation prompt;
- chosen check-in;
- user-initiated only.

Advanced settings appear only if relevant.

After silence:

- no escalation;
- no guilt;
- no notification to another person;
- no “we missed you”.

---

## 11. Voice

Default:

- calm;
- adult;
- concise;
- literal;
- epistemically clear.

Lightweight overrides:

- shorter;
- warmer;
- more direct.

Do not require a four-mode personality selection.

---

## 12. Metaphor

- Garden name and slogan may remain.
- All functions have literal labels.
- No planting/day-one ritual as required framing.
- No visual decay.
- No bloom as outcome.
- Metaphor preference is observed, not assumed.

---

## 13. Structural context

Add a lightweight source check when relevant:

> «Это в основном зависит от твоего действия, от договорённости с кем-то или от условий, которые контролирует организация/система?»

Every recommendation distinguishes:

- immediate relief;
- preparation;
- source-directed change.

Do not perform a full structural analysis in routine low-risk cases.

---

## 14. Fresh Eyes

Do not build a separate full feature in Stage 1.

Integrate two safeguards:

- past attempts are not converted into identity;
- first solution is not treated as the only natural solution.

Possible prompt:

> «Что здесь является фактом, а что прогнозом на основе прошлого?»

---

## 15. Human research access

The protocol must define:

- named researchers;
- role-based access;
- purpose;
- exact data;
- storage location;
- retention;
- redaction;
- audit;
- withdrawal;
- incident response.

Human review is not described as anonymous AI conversation.

Participants know when a human may read content.

---

## 16. Data architecture

Minimum Alpha:

- no provider training;
- no raw text in analytics;
- separated participant identifiers;
- encrypted storage;
- no shared researcher spreadsheet with unrestricted access;
- deletion of source, summaries and model context;
- provider retention documented;
- export available;
- backups and deletion timing explained.

---

## 17. Outcomes

### Primary human outcomes

- useful real-world action or intentional non-action;
- ability to adapt/complete/release;
- lower pressure than comparator;
- calibrated understanding;
- value beyond simple tool;
- ability to disagree with Garden.

### Guardrails

- guilt;
- reactance;
- rumination;
- false pattern acceptance;
- overtrust;
- unwanted disclosure;
- measurement burden;
- dependence;
- unsafe advice;
- structural self-blame.

### Descriptive, not success metrics

- messages;
- days used;
- check-ins;
- return after miss;
- AI interaction length.

---

## 18. Kill/no-go criteria

Stop or redesign if:

- users interpret Garden as therapy or a friend;
- users feel monitored;
- daily interaction is required for value;
- AI hypotheses are accepted as facts;
- a simple reminder performs equally well;
- deletion cannot be verified;
- human access is broader than consent;
- product value depends on guilt or attachment;
- repeated coping replaces source change;
- safety reviewers reject the setup.

---

## 19. Required deliverables before recruitment

- accepted GDR hard blockers;
- participant information sheet;
- informed consent;
- data-flow diagram;
- DPIA;
- researcher access policy;
- crisis boundary script;
- exclusion/escalation process;
- AI response protocol;
- adverse-event log;
- deletion test;
- interview guides;
- comparator materials;
- analysis plan;
- owner and safety sign-off.

---

## 20. Documents affected

Supersede or update:

- `garden_alpha_blueprint_v1.md`;
- ritual card;
- daily form;
- metrics section;
- participant journey;
- researcher table;
- AI response instructions;
- Definition of Done.

Preserve v1 in Chronicle as historical evidence.
