# Garden UX Flow Map v1

**Статус:** `working flow map`

## Ritual-first flow

```text
Garden Home
→ Create
→ Ritual
→ Current Direction
→ Ritual Design
→ Support
→ Garden Form
→ Placement
→ Ritual Detail
→ Exit to Life
→ Review
→ Lifecycle
→ Transformation
→ Garden Home
```

## Place-first flow

```text
Garden Home
→ Create
→ Place
→ Select Area
→ Name / Meaning
→ Add Object or Ritual
→ Placement
→ Place Detail
→ Garden Home
```

## Completion flow

```text
Ritual Detail
→ Complete
→ What should happen to the object?
   ├── Keep
   ├── Transform
   ├── Archive
   ├── Delete
   └── Detach
→ Optional note
→ Garden Home
```

## Rest flow

```text
Ritual Detail
→ Rest
→ Choose support behavior
   ├── No prompts
   ├── Review later
   └── User initiated
→ Object remains unchanged
→ Garden Home
```

## Safe exit flow

```text
Settings
→ Export
→ Disable support
→ Archive or keep garden
→ Delete account optional
→ Confirm deletion scope
→ Show deletion status
```
