# Garden Alpha v2 — Visual Ritual Garden Amendment

**Дата:** 16 июля 2026  
**Статус:** required amendment to Alpha v2 design

## What Alpha must test

Alpha must test two inseparable hypotheses:

1. The ritual method helps a person move from meaning to action without pressure.
2. A personal visual garden creates emotional value, ownership and desire to shape the experience.

Testing only a text flow tests the method, not Garden.

## Minimum visual garden

Alpha does not need a full farm simulation.

It needs:

- one personal garden space;
- one ritual represented as a place, plant or object;
- user-controlled placement;
- at least two visual customization choices;
- visible transformation chosen by the user;
- completion/archive without death or decay;
- empty space preserved;
- no performance score.

## Suggested Alpha loop

1. Name what matters now.
2. Create a ritual.
3. Choose its form in life.
4. Choose what it becomes in the garden.
5. Place it.
6. Live the ritual outside the product.
7. Return at a chosen time.
8. Continue, change, rest, complete or transform.
9. Let the garden preserve the chosen story.

## Evaluation

In addition to agency and real-world action, test:

- sense of ownership;
- emotional attachment to the space rather than obligation to the system;
- delight;
- creative expression;
- whether the garden makes meaning clearer;
- whether visual state is misread as judgment;
- whether users want to rearrange without performing;
- whether absence creates anxiety.

## No-go mechanics

- dying plants;
- wilt after miss;
- lost crops;
- streak-dependent rewards;
- countdown harvesting;
- red failure states;
- AI deciding object transformations;
- locked deletion;
- irreversible placement;
- paid recovery from absence.
