# Garden World Alpha Test Plan

**Статус:** `research draft`

## A — Ritual-first

> «Создай один ритуал и найди для него место в саду».

Measure comprehension, ownership, pressure and visual delight.

## B — Place-first

> «Создай место, которое хочется сделать своим. Затем реши, что там может жить».

Measure spatial imagination, meaning, confusion and ritual creation.

## C — Empty garden

> «Оставь сад таким, каким тебе комфортно».

Check whether emptiness feels valid or unfinished.

## D — Absence

Scenario: user did not open Garden for 10 days.

Show unchanged garden and measure relief, guilt and ownership.

## E — Completion

Scenario: ritual is no longer needed.

Test:

- complete;
- transform;
- archive;
- delete.

## F — Safe exit

Test:

- export snapshot;
- disable reminders;
- delete object;
- leave Garden.

## Success criteria

- users distinguish place from ritual;
- empty does not read as failure;
- no expectation of decay;
- visual world adds value over cards;
- completion is shame-free;
- one creation model shows a clear advantage;
- return desire is not driven by fear.
