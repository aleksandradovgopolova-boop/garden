# Garden UX Architecture v1

**Дата:** 16 июля 2026  
**Статус:** `working UX architecture`  
**Основание:** Living Canon v1, Garden Constitution v1, Laws of Garden v1, World Architecture v1

---

## 1. Цель

UX Architecture переводит законы Garden в конкретную навигацию, экраны, состояния и пользовательские сценарии.

Главная задача:

> сделать сад главным пространством продукта, не превратив его в task dashboard, а AI — в обязательного проводника.

---

## 2. Главная навигационная модель

Garden использует модель `world-first navigation`.

Главный экран — сад.

Из сада пользователь может перейти в:

- место;
- ритуал;
- создание;
- review;
- архив;
- память и приватность;
- настройки мира.

### Primary navigation

```text
Garden Home
├── Create
├── Places
├── Rituals
├── Review
├── Archive
└── Settings
```

Навигация не должна визуально конкурировать с садом.

### Desktop

- сад занимает основной viewport;
- компактный левый sidebar;
- contextual right panel;
- верхняя строка только для world actions.

### Mobile

- garden canvas;
- bottom navigation:
  - Garden;
  - Rituals;
  - Create;
  - Archive;
  - Settings.

---

## 3. Основные пользовательские пути

### Path A — Ritual-first

```text
Garden Home
→ Create
→ What matters now
→ Ritual design
→ Choose support
→ Choose visual form
→ Place in garden
→ Ritual created
→ Close and live outside Garden
→ Review
→ Lifecycle decision
→ Garden transformation
```

### Path B — Place-first

```text
Garden Home
→ Create place
→ Choose terrain area
→ Name or leave unnamed
→ Define optional meaning
→ Add object or ritual
→ Place created
→ Later attach ritual
```

### Path C — Return to garden

```text
Open Garden
→ Observe
→ Optional object/place interaction
→ Optional review
→ Leave
```

No mandatory checklist appears on entry.

### Path D — Complete or release

```text
Ritual detail
→ Complete / Release
→ Choose object outcome
→ Archive / Transform / Keep / Delete
→ Optional note
→ Return to garden
```

---

## 4. Screen map

### 4.1. Welcome

Purpose:

- explain what Garden is;
- explain what it is not;
- show ownership;
- set privacy expectations;
- allow literal or visual mode.

Content:

- «Это ваш сад».
- «Ритуалы можно менять и завершать».
- «Отсутствие ничего не разрушает».
- «AI не принимает решения за вас».

Actions:

- Create garden;
- Explore example;
- Use literal mode;
- Read privacy summary.

---

### 4.2. Garden setup

User chooses:

- garden name;
- terrain;
- visual density;
- sound preference;
- motion preference;
- default metaphor level.

Rules:

- no personality quiz;
- no “what type of person are you”;
- no pre-filled psychological garden;
- skip available.

---

### 4.3. Garden Home

Main elements:

- garden canvas;
- placed objects;
- places and paths;
- ambient world;
- subtle create button;
- contextual access to selected entity.

Must not show by default:

- completion percentage;
- streak;
- overdue count;
- red states;
- total ritual count as achievement;
- emotional score.

Optional overlays:

- place names;
- ritual labels;
- edit mode;
- accessibility list mode.

---

### 4.4. Create menu

Options:

- Create ritual;
- Create place;
- Add object;
- Add memory;
- Change garden.

Alpha:

- ritual;
- place;
- object.

---

### 4.5. Current Direction

Prompt:

> «Чему сейчас хочется дать место в жизни?»

Fields:

- title;
- user words;
- why now;
- known;
- assumed;
- unknown;
- context.

AI can help clarify, but user may skip.

---

### 4.6. Ritual Design

Fields:

- ritual name;
- meaning;
- primary form;
- meaningful minimum;
- alternative form;
- cadence;
- start timing;
- support mode;
- review timing.

UX rule:

- progressive disclosure;
- no long contract form;
- no “ideal consistency”.

---

### 4.7. Choose Support

Options:

- none;
- one reminder;
- chosen check-in;
- preparation message;
- user-initiated only.

Copy:

> «Поддержка не обязательна. Её можно изменить в любой момент».

---

### 4.8. Choose Garden Form

User chooses:

- object category;
- appearance;
- name;
- optional meaning;
- whether to link object to ritual.

AI may suggest, never assign.

---

### 4.9. Place in Garden

Canvas actions:

- drag;
- rotate;
- resize;
- preview;
- undo;
- place elsewhere;
- create new place;
- leave unplaced.

Unplaced ritual remains valid.

---

### 4.10. Place Detail

Shows:

- place name;
- user meaning;
- rituals;
- objects;
- memories;
- ambient settings;
- edit history.

Actions:

- rename;
- edit meaning;
- add ritual;
- move objects;
- archive place;
- delete place.

Deleting place requires destination decisions for linked entities.

---

### 4.11. Ritual Detail

Shows:

- name;
- meaning;
- current form;
- meaningful minimum;
- support;
- lifecycle;
- linked place/object;
- review history;
- memory entries.

Primary actions:

- Do nothing;
- Edit;
- Review;
- Rest;
- Complete;
- Release.

No primary CTA labeled “Complete today”.

---

### 4.12. Review

Structure:

1. Permission.
2. Concrete event.
3. Facts.
4. Context.
5. One question.
6. Maximum two AI hypotheses.
7. Missing information.
8. Choice.
9. Memory decision.
10. Closure.

Modes:

- Record;
- Understand;
- Decide;
- Release.

---

### 4.13. Lifecycle Decision

Options:

- Continue;
- Adapt;
- Rest;
- Integrate;
- Complete;
- Release.

Each option explains impact without moral framing.

---

### 4.14. Transformation

After lifecycle decision, user decides object outcome:

- keep unchanged;
- move;
- change appearance;
- transform;
- make decorative;
- archive;
- delete.

No automatic transformation after review.

---

### 4.15. Archive

Contains:

- completed rituals;
- released rituals;
- archived places;
- archived objects;
- snapshots.

Actions:

- view;
- restore;
- export;
- delete.

Archive copy:

> «Здесь хранится то, что вы решили сохранить».

Not:

> «Ваши достижения».

---

### 4.16. Memory and Privacy

Shows:

- facts saved;
- preferences;
- confirmed interpretations;
- AI hypotheses;
- sensitive items;
- expiry;
- data providers;
- deletion status.

Actions:

- edit;
- confirm;
- reject;
- expire;
- delete;
- export.

---

### 4.17. World Settings

Sections:

- visuals;
- sound;
- motion;
- weather;
- time;
- metaphor intensity;
- labels;
- accessibility;
- reset;
- export.

---

## 5. Interaction modes

### Observe mode

Default.

- no task pressure;
- world is primary;
- subtle labels.

### Edit mode

Explicitly entered.

- grid/snap optional;
- object handles;
- undo;
- save/cancel.

### Reflection mode

World fades into background.

- literal interface;
- one question at a time;
- clear exit.

### Safety mode

- metaphor disabled;
- direct copy;
- no ambient distraction;
- clear external options;
- no playful animation.

---

## 6. State architecture

### Garden states

- new;
- active;
- quiet;
- archived;
- reset pending.

No “neglected” state.

### Place states

- active;
- quiet;
- archived.

### Ritual states

- seeded;
- active;
- adapting;
- resting;
- integrated;
- completed;
- released;
- archived.

### Object states

- normal;
- transformed;
- decorative;
- archived.

No failure or decay state.

---

## 7. Empty states

### No rituals

> «Сад может жить без активных ритуалов».

### No places

> «Можно начать с ритуала, места или просто осмотреться».

### No archive

> «Здесь пока ничего нет».

### No memory

> «Garden пока ничего не сохраняет о вас».

---

## 8. Error states

### Save failed

- preserve local draft;
- show retry;
- no loss language.

### Sync conflict

- compare versions;
- user selects;
- no silent overwrite.

### AI unavailable

- garden and rituals remain usable;
- literal flow continues.

### Object render failed

- show accessible placeholder;
- preserve data.

### Delete pending

- explain backend status;
- do not imply completion before actual deletion.

---

## 9. Safety states

### High-risk content detected

Garden:

- pauses normal reflection;
- states limitation;
- offers verified human resources;
- allows user to close;
- does not continue ritual design;
- does not automatically disclose.

### Coercive relationship scenario

- no shared practice prompt;
- no suggestion to explain better;
- no partner access;
- safety-oriented language.

### Medical/legal/financial high stakes

- mark uncertainty;
- recommend qualified support;
- avoid executable advice beyond low-risk preparation.

---

## 10. Accessibility architecture

### Visual

- high contrast;
- zoom;
- reduced detail;
- simplified terrain;
- no color-only state.

### Motor

- keyboard movement;
- list-based placement;
- large targets;
- no drag-only action.

### Cognitive

- literal labels;
- progressive disclosure;
- consistent vocabulary;
- no hidden gestures.

### Sensory

- sound off;
- volume categories;
- reduced motion;
- no sudden effects.

---

## 11. Information architecture

```text
Garden
├── Home
├── Places
│   └── Place Detail
├── Rituals
│   └── Ritual Detail
├── Create
│   ├── Ritual
│   ├── Place
│   └── Object
├── Review
├── Archive
├── Memory & Privacy
└── Settings
```

---

## 12. Alpha navigation recommendation

### Desktop

Left sidebar:

- Garden;
- Rituals;
- Archive;
- Settings.

Create as floating primary action.

Right panel appears only after selection.

### Mobile

Bottom bar:

- Garden;
- Rituals;
- Create;
- Archive;
- Settings.

No permanent AI chat tab.

AI appears contextually inside creation/review.

---

## 13. AI entry points

Allowed:

- Clarify current direction;
- Help design ritual;
- Suggest visual forms;
- Help review;
- Fresh view;
- Explain privacy/memory.

Not allowed:

- global proactive companion;
- unsolicited daily chat;
- invisible intervention;
- AI home-screen character.

---

## 14. UX success criteria

- Garden is understood as place, not dashboard.
- User knows ritual can end.
- User can leave garden empty.
- User finds editing safe and reversible.
- AI is useful without being central.
- Review ends.
- Archive feels like history, not achievement.
- Absence creates no anxiety.
- Literal mode preserves full function.
- User says “мой сад” without feeling judged.

---

## 15. UX no-go list

- red overdue badges;
- completion rings;
- “today” task queue by default;
- daily check-in pop-up;
- pet waiting animation;
- plant decay;
- AI greeting implying relationship;
- “your garden needs you”;
- forced naming;
- hidden gestures;
- deleting ritual also deleting object without choice;
- archive labeled “past failures”.

---

## 16. Next design outputs

1. Sitemap.
2. Flow diagrams.
3. Wireframes.
4. State matrix.
5. Responsive behavior.
6. Accessibility variants.
7. Alpha clickable prototype.
