# V-005 — Spatial Language

Primitives:
- field;
- threshold;
- layer;
- anchor;
- opening;
- path;
- cluster;
- edge;
- depth;
- pause.

A Place uses one dominant field, a small number of anchors, clear negative space and readable foreground/background.

Avoid collectible grids, icon carpets, hidden hotspots and game maps.

Every spatial composition has an equal structured representation:

Place
- Atmosphere
- Objects
- Rituals
- Memories

> Space provides orientation, not hierarchy of personal importance.
