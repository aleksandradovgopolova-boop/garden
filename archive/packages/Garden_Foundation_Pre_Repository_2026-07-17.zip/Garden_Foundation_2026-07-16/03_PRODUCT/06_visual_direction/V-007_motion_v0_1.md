# V-007 — Motion

Motion supports continuity and orientation.

Allowed:
- entering or leaving a Place;
- object movement;
- atmosphere transition;
- Preview comparison;
- panel opening;
- save and sync state.

Forbidden:
- confetti;
- streak celebration;
- pulsing retention prompts;
- AI magic sparkle;
- animated guilt;
- distracting idle loops.

Reduced motion removes parallax, zoom and ambient movement while preserving state through labels and focus management.

> Motion shows continuity. It does not manufacture excitement.
