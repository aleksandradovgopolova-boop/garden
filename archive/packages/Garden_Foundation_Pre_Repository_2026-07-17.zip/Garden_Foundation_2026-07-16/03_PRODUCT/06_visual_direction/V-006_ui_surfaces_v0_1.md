# V-006 — UI Surfaces

## World Surface
The Place itself. Visually primary and directly manipulable.

## Context Surface
Selected object, ritual or memory. Compact, contextual and dismissible.

## System Surface
History, privacy, export, deletion and settings. Literal and stable.

## Proposal Surface
AI scope, assumptions, Preview and Diff. Visibly separate from committed state.

Only one surface should dominate at a time.

> The interface must reveal whether the user is inhabiting, editing or operating the system.
