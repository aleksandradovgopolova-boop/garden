# V-004 — Typography

Use a highly legible contemporary sans serif for navigation, controls, history, privacy and AI scope.

An optional restrained serif or humanist text face may be used for longer user-authored memories.

Rules:
- no mystical display type in functional UI;
- no all-caps primary hierarchy;
- readable minimum size;
- 45–75 character reading width;
- visible attribution of AI-generated text;
- user-authored content visually outranks system explanation.

> Typography should help the user hear their own words before hearing the system.
