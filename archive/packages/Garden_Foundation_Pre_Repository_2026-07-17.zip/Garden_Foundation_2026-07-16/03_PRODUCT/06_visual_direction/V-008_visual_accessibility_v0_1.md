# V-008 — Visual Accessibility

Requirements:
- keyboard-complete flows;
- visible focus;
- screen-reader labels;
- reduced motion;
- high-contrast compatibility;
- zoom resilience;
- non-color state indicators;
- non-drag object placement;
- text alternatives for atmosphere.

Example atmosphere description:
“Warm low light, quiet rain sound, little background movement.”

Not:
“A healing and emotionally safe atmosphere.”

Spatial and structured interaction have equal product status.
