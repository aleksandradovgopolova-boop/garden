# V-001 — Visual Territories

Garden combines three visual territories.

## Quiet Spatial Modernism
Architectural calm, clear geometry, restrained surfaces, negative space and light as orientation.

## Soft Domestic Presence
Human scale, familiar objects, tactile warmth and subtle imperfection without decorative excess.

## Atmospheric Abstraction
Light, haze, depth and sound create place without demanding full realism.

## Recommended direction
Use modernist structure, domestic intimacy and abstract atmosphere.

Avoid:
- cozy-game inventory;
- fantasy world UI;
- productivity dashboard;
- mystical wellness;
- social feed;
- smart-home control panel.

> Garden should feel inhabitable without pretending to be a complete world.
