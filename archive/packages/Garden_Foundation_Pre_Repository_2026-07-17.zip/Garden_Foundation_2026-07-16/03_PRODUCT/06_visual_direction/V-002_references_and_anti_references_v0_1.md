# V-002 — References and Anti-references

Use references by quality, not imitation.

Look for:
- thresholds and framed views;
- light as orientation;
- editorial hierarchy;
- quiet digital instruments;
- ambient media without reward.

Anti-references:
- Animal Crossing inventory;
- Stardew Valley task loop;
- Tamagotchi care pressure;
- Notion workspace;
- Obsidian graph;
- Pinterest moodboard;
- meditation gradients;
- AI sparkle;
- metaverse lobby;
- SaaS dashboard.

Every reference must be checked for authorship, pressure, progression, accessibility and clarity of system state.
