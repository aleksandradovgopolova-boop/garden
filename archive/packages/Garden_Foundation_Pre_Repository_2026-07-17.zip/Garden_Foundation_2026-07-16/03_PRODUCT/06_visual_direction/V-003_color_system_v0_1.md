# V-003 — Color System

Color creates atmosphere but never diagnoses emotion.

Core roles:
- canvas;
- surface;
- raised surface;
- primary and secondary text;
- borders;
- focus;
- action;
- success;
- warning;
- danger;
- selection;
- preview.

Direction:
- mineral neutrals;
- muted warm and cool variants;
- restrained botanical accents;
- one functional accent;
- one preview color;
- one danger color.

Avoid neon AI purple, reward green, fantasy jewel palettes and beige-on-beige ambiguity.

All states require WCAG-compliant contrast and non-color indicators.
