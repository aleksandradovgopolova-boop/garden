# V-009 — Alpha UI Kit

Foundations:
- color;
- type;
- spacing;
- radius;
- elevation;
- motion;
- breakpoints;
- focus;
- state overlays.

Core components:
- Garden Shell;
- Place Canvas;
- Direct Navigation;
- Search;
- Object Inspector;
- Ritual and Memory cards;
- Atmosphere Controls;
- AI Scope Selector;
- Assumptions Panel;
- Preview and Diff;
- Partial Apply;
- Version Timeline;
- Undo;
- Privacy;
- Export/Delete;
- Empty, Error and Offline states.

Every component documents default, focus, selected, disabled, loading, error, draft, preview and committed states.

> The UI kit is a product-behavior library, not only a visual library.
