# Garden Social Consent and Access Matrix

**Версия:** 0.1  
**Статус:** working safety standard

| Data / action | Listener | Practical helper | Witness | Co-practitioner | Small circle |
|---|---:|---:|---:|---:|---:|
| Selected message | Explicit | Explicit | Explicit | Explicit | Explicit |
| Practice title | No default | If needed | Explicit | Shared object | Explicit |
| Schedule | No | If needed | No | Shared object | Explicit |
| Completion event | No | No default | Explicit | Joint event only | No default |
| Missed event | No | No | No | No automatic sharing | No |
| Personal note | No | No | Explicit item only | No | Explicit post |
| Mood/state | No | No | Explicit item only | No | No default |
| AI hypothesis | No | No | No | No | No |
| Full journal | No | No | No | No | No |
| Other practices | No | No | No | No | No |
| Location | No | One-time explicit only | No | Event location if necessary | No |
| Send reminder | No | User-requested only | No | Agreed coordination | Moderator only for group events |
| Prompt after miss | No | No | No | Pre-agreed neutral option | No |
| Invite others | No | No | No | Mutual approval | Role-dependent |
| Export shared data | Own message | Own request | Own received item | Shared-object rules | Community policy |
| View access history | Own interactions | Own interactions | Own interactions | Both | Admin + user log |

## Invariants

- no blanket Garden access;
- no hidden visibility;
- no consent by relationship status;
- no automatic miss disclosure;
- no AI-generated concern messages;
- no employer/insurer/school access;
- no crisis disclosure in Alpha;
- revocation is immediate for future access.
