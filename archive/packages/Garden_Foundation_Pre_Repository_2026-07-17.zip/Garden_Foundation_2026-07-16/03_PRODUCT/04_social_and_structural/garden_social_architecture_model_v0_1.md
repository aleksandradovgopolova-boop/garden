# Garden Social Architecture Model

**Версия:** 0.1  
**Статус:** `proposed`  
**Контур:** `03_product/social/social_architecture.md`

---

## 1. Core principle

> Share the coordination, not the interior.

Garden social features expose a narrow shared object, not the user’s whole Garden.

---

## 2. Levels

### S0 — Solo

No social data or invites.

### S1 — Prepared connection

AI helps formulate an offline request. Nothing is sent.

### S2 — One-time share

A selected message, practice or request is shared once.

### S3 — Trusted person

A person receives a narrowly defined role and limited data.

### S4 — Shared practice

Joint coordination object; each participant retains private space.

### S5 — Small circle

Requires moderation model and group governance.

### S6 — Community

Requires discovery safety, content moderation and professional operations.

### S7 — Public network

Feed, rankings and broad social graph.

**Alpha boundary:** S1–S3.  
S4 after dedicated testing. S5–S7 excluded.

---

## 3. Trusted-person roles

- listener;
- practical helper;
- witness;
- co-practitioner;
- selected difficult-moment contact.

No role grants full-profile access.

---

## 4. Support Request

```yaml
request_id:
recipient:
support_type:
message:
specific_action:
what_not_to_do:
time_window:
response_required: false
shared_data:
expiry:
```

---

## 5. Shared Practice

```yaml
shared_practice_id:
participants:
joint_definition:
individual_reasons_private:
coordination_data:
private_data:
notification_rules:
miss_rules:
conflict_rules:
start_at:
review_at:
end_at:
```

---

## 6. Permission rules

Permissions are:

- per object;
- per person;
- per data type;
- per action;
- time-limited;
- revocable.

No relationship-level permission such as `partner can view Garden`.

---

## 7. Separation

Leaving must:

- stop access immediately;
- revoke links/tokens;
- retain personal private data;
- stop notifications;
- prevent repeated invites;
- show audit history;
- allow shared-object deletion process.

---

## 8. No social comparison

No:

- leaderboards;
- public streaks;
- percentiles;
- reactions as status;
- garden rankings;
- follower counts;
- «people like you».

---

## 9. Community gate

Community cannot launch without:

- trained human moderation;
- rules and appeals;
- response coverage;
- crisis/escalation boundaries;
- misinformation policy;
- harassment handling;
- co-rumination design;
- moderator wellbeing;
- privacy model;
- independent safety review.

---

## 10. Success

- requested support was received;
- both people retained autonomy;
- no unexpected disclosure;
- offline relationship benefited;
- helper burden remained acceptable;
- exit was safe;
- product mediation became unnecessary.

---

## 11. Status

Does not enter Garden Bible before GDR-014.
