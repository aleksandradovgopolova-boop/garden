# Garden Problem Location and Intervention Matrix

**Версия:** 0.1  
**Статус:** working standard

| Situation | Likely levels | Personal practice can do | Source-directed options | Major risk |
|---|---|---|---|---|
| Sleep loss from late scrolling | L1 + product environment | reduce immediate friction, prepare sleep | app limits, device environment | overpsychologizing |
| Sleep loss from night shifts | L1 + L3 | protect available rest | schedule/staffing/occupational route | blaming routine |
| Impossible workload | L1 + L3 | restore capacity, prepare request | workload, priority, staffing, exit | resilience substitution |
| Bullying manager | L2 + L3 | grounding, documentation | formal support, ally, transfer, exit | unsafe confrontation |
| Unequal domestic labor | L2 + L4/L5 | clarify need, restore | redistribution, support services | «better boundaries» only |
| Low income | L4 + L5 | budgeting only within real margin | benefits, wage, debt/legal/community support | poverty as habit failure |
| Discrimination | L2–L5 | record, support | procedure, legal/collective route | denying or overclaiming |
| Abusive relationship | L2 + safety | stabilize, private safety support | specialist support, safe exit | mediation/shared access |
| Chronic illness | L1 + healthcare system | symptom support per professional advice | medical/access/accommodation | wellness cure claims |
| Unsafe neighborhood | L4/L5 | immediate risk reduction | community/infrastructure/policy | mindfulness as safety |
| Caregiving overload | L1–L5 | rest, ask | redistribute, respite, services | self-care burden |
| Skill gap | L1 + L3 | learn and practice | training/resources/role clarity | identity judgment |
| Moral injury | L2/L3/L5 | regulate and clarify values | ethics route, collective/exit | reframing injustice |
| Loneliness | L1/L2/L4 | prepare contact | relationships/community access | AI substitution |

## Required questions

- What happened?
- What is repeated?
- Who controls the condition?
- Who benefits from the current arrangement?
- Who is responsible?
- What resources are needed?
- Is direct action safe?
- What helps today?
- What changes the source?
