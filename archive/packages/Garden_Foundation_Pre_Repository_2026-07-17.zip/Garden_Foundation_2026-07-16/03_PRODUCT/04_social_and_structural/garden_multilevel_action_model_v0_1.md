# Garden Multilevel Action Model

**Версия:** 0.1  
**Статус:** `proposed`  
**Контур:** `03_product/action/multilevel_action_model.md`

---

## 1. Core principle

> Help now. Name the source. Do not confuse the two.

---

## 2. Problem levels

- `L1_personal_capacity`
- `L2_relationship`
- `L3_organization`
- `L4_material_community`
- `L5_policy_structure`

Multiple values are allowed.

---

## 3. Action types

- `stabilize`
- `understand`
- `coordinate`
- `change_environment`
- `use_institution`
- `collective_action`
- `exit_or_distance`
- `personal_practice`

---

## 4. Intervention Integrity Labels

- relief;
- adaptation;
- protection;
- preparation;
- navigation;
- relational change;
- organizational change;
- structural change;
- exit.

Every proposal names what it does **and what it does not do**.

---

## 5. Core object

```yaml
issue:
observed_facts:
impact_now:
contributing_levels:
power_map:
responsibility_map:
resource_check:
safety_check:
action_portfolio:
immediate_relief:
source_directed_action:
external_verification:
review_date:
```

---

## 6. Response pattern

1. Acknowledge impact without locating fault.
2. Name possible contributing levels.
3. Ask which level matters now.
4. Show immediate and source-directed options separately.
5. Check cost, power and safety.
6. Help choose a portfolio.
7. Name limits.
8. Review whether conditions changed.

---

## 7. Example

```yaml
issue: chronic overload
levels:
  - L1_personal_capacity
  - L3_organization
relief:
  - stop work for ten minutes
  - cancel nonessential evening task
source_directed:
  - document workload
  - request priority decision
  - negotiate staffing/deadline
limits:
  - rest does not reduce assigned workload
```

---

## 8. Prohibited outputs

- resilience score;
- personal responsibility percentage;
- legal classification;
- discrimination verdict;
- employer report;
- recommendation to confront an unsafe person;
- «mindset» as default root cause;
- coping plan without source analysis in recurring distress.

---

## 9. Success

- less self-blame;
- feasible action;
- responsible actor remains visible;
- immediate safety;
- source-directed change where possible;
- no pressure to fix system alone;
- external support used appropriately.

---

## 10. Status

Does not enter Garden Bible before GDR-015.
