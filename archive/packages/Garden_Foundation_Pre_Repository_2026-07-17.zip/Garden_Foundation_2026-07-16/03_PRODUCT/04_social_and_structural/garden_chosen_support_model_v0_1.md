# Garden Chosen Support Model

**Версия:** 0.1  
**Статус:** `proposed`  
**Контур:** `03_product/mechanics/chosen_support_model.md`

---

## 1. Основной принцип

> Пользователь не отчитывается перед Garden. Garden выполняет выбранный пользователем контракт поддержки.

Контракт:

- создаётся вместе с практикой;
- может отсутствовать;
- ограничен по времени;
- пересматривается;
- отменяется немедленно;
- не связан с наказанием.

---

## 2. Support Contract

```yaml
support_contract_id:
practice_id:
current_reason:
support_mode:
allowed_channels:
timing:
maximum_frequency:
after_miss_response:
forbidden_language:
data_scope:
human_support:
review_date:
auto_expire_date:
status:
```

---

## 3. Support modes

### Memory

Только сохранять решение.

### Visibility

Показывать без push.

### Prompt

Одно согласованное напоминание.

### Preparation

Помочь изменить среду или заранее составить план.

### Witness

Принять короткую отметку без оценки.

### Reflection

Задать один согласованный вопрос.

### Human connection

Помочь обратиться к выбранному человеком участнику поддержки.

Garden не повышает уровень самостоятельно.

---

## 4. После пропуска

Пользователь заранее выбирает:

- молчать;
- показать практику без сообщения;
- спросить, сохраняется ли актуальность;
- помочь адаптировать;
- предложить паузу;
- напомнить исходную причину один раз.

Запрещены:

- вина;
- disappointment;
- «ты обещала»;
- потеря серии;
- автоматическое усиление reminders;
- предложение наверстать.

---

## 5. Review Trigger

Контракт пересматривается, если:

- прошло выбранное время;
- три согласованных prompts остались без ответа;
- условия жизни изменились;
- практика многократно адаптировалась;
- пользователь просит изменить поддержку;
- действие стало автоматичным;
- support cost выше пользы.

Отсутствие ответа ведёт к снижению вмешательства, а не к escalation.

---

## 6. Commitment types

### Intention

Мягкое текущее намерение.

### Experiment

Попробовать определённое число раз и пересмотреть.

### Process commitment

Сделать доступный шаг.

### Human agreement

Договорённость с реальным человеком.

### Environment design

Изменить условия.

В MVP отсутствуют:

- hard commitment;
- financial stakes;
- public pledge;
- punitive loss;
- social leaderboard.

---

## 7. Responsibility Map

Каждая практика может включать:

- under direct control;
- influenceable;
- outside direct control.

Garden отражает только ту ответственность, которая реально принадлежала человеку.

---

## 8. Support Success

Поддержка успешна, если:

- человек действовал в реальной жизни;
- смог изменить план;
- прекратил нерелевантное обязательство;
- научился проектировать среду;
- уменьшил зависимость от prompts;
- честно сообщил о несовпадении;
- способен продолжить без Garden.

---

## 9. Эксперимент

Сравнить:

- user-created support contract;
- standard reminder settings;
- no proactive support.

Измерять:

- action;
- perceived authorship;
- pressure;
- reactance;
- honesty;
- reminder dependence;
- renegotiation;
- disabling support;
- real-life competence;
- beneficial disengagement.

---

## 10. Статус

Модель не входит в Bible до принятия GDR-008.
