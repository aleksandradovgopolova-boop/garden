# Garden Productive Unknowing Model

**Версия:** 0.1  
**Статус:** `proposed`  
**Контур:** `03_product/sensemaking/productive_unknowing_model.md`

## 1. Principle

> Keep knowledge available. Remove its automatic veto.

## 2. Unknown types

### U0 — Unrecognized ignorance

The person/system assumes knowledge without seeing a gap.

### U1 — Declared unknown

The gap is visible.

### U2 — Suspended conclusion

A previous interpretation is temporarily bracketed.

### U3 — Investigable unknown

A bounded probe can create information.

### U4 — Expertise-dependent unknown

Action waits for qualified input.

### U5 — Currently unknowable

No useful answer is available now; decision must use values, risk and reversibility.

## 3. Constraint classes

```yaml
hard:
  - safety
  - consent
  - law
  - irreversible harm
  - verified technical limit
soft:
  - convention
  - assumed sequence
  - identity story
  - previous failure
  - social expectation
unknown:
  - actual cost
  - readiness of others
  - probability
  - hidden dependency
```

## 4. Modes

- Learn;
- Question;
- Explore;
- Decide.

Garden shows current mode and does not keep exploration open indefinitely.

## 5. Fresh Eyes Mode

```yaml
memory:
  user_facts: available
  safety_history: available
  past_outcomes: hidden_until_requested
  ai_hypotheses: hidden
  identity_summaries: prohibited
exploration:
  naive_questions_max: 3
  alternative_frames: 3
  first_solution_delay: true
safety:
  hard_constraints_visible: true
  expertise_gate: true
  affordable_loss_required: true
closure:
  decision_or_probe_required: true
```

## 6. Productive Unknowing Protocol

1. Define the bounded question.
2. Sort fact, convention, prediction, identity and unknown.
3. Preserve hard constraints.
4. Suspend soft constraints.
5. Ask up to three naive questions.
6. Identify needed expertise.
7. Choose reversible probe.
8. Define expected learning.
9. Act outside Garden.
10. Update context, not identity.

## 7. Memory rule

Past outcomes may inform:

- safety;
- design of the next probe;
- resource estimates;
- needed support.

They cannot automatically determine:

- identity;
- desire;
- impossibility;
- future success.

## 8. Stop conditions

Do not explore through action when:

- high-stakes health/legal/financial risk;
- coercion or violence;
- no informed consent;
- irreversible public disclosure;
- dependency of vulnerable third parties;
- unknown cost may be catastrophic;
- no feedback channel;
- experiment repeats known harm.

## 9. Product language

Use:

- `Known`;
- `Assumed`;
- `Unknown`;
- `Needs expertise`;
- `Can be tested`;
- `Not safe to test`;
- `Changed conclusion`.

Never use an ignorance score or beginner identity.

## 10. Success

- assumption becomes visible;
- action is more feasible;
- hard constraint remains protected;
- user seeks expertise appropriately;
- test creates information;
- failed test does not become identity;
- Garden converges or closes.

## 11. Status

Does not enter Garden Bible before GDR-017.
