# Garden Object Architecture v1

**Статус:** implementation proposal

```yaml
garden_object:
  object_id: uuid
  garden_id: uuid
  place_id: uuid | null
  family: rest | passage | orientation | gathering | containment | observation | memory | atmosphere
  type: string
  material_id: string
  scale_class: landmark | place | functional | detail
  position:
    x: number
    y: number
    z: number
  orientation:
    rotation: number
    facing_target_id: uuid | null
  silhouette_id: string
  interaction_level: 0 | 1 | 2 | 3 | 4
  available_actions: [action_id]
  accessibility:
    label: string
    description: string
    list_editable: boolean
    keyboard_editable: boolean
  ritual_ids: [uuid]
  memory_ids: [uuid]
  user_name: string | null
  user_meaning: string | null
  state: placed | transformed | decorative | archived
  provenance:
    source:
    cultural_review:
```

## Инварианты

- состояние объекта не меняется автоматически вслед за ритуалом;
- layout не используется для психологической интерпретации;
- универсальная символика отсутствует;
- пространственные действия имеют не-spatial alternatives;
- AI-generated changes требуют подтверждения.
