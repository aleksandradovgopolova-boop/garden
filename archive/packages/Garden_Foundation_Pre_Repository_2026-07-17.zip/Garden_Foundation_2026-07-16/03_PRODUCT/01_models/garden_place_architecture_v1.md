# Garden Place Architecture v1

**Статус:** `implementation proposal`

```yaml
garden_place:
  place_id: uuid
  garden_id: uuid
  name: string | null
  name_mode: unnamed | literal | poetic | personal | temporary
  template_id: string | null
  geometry:
    bounds:
    elevation:
  boundary:
    type:
    strength:
  center:
    object_id: uuid | null
    point: coordinates | null
  arrival:
    entry_points:
    primary_path_id:
    reveal_style:
  paths: [uuid]
  views:
    primary:
    secondary:
  spatial_qualities:
    openness:
    shelter:
    density:
    enclosure:
  privacy:
    visual_quality:
    data_visibility: private | shared | public_preview
    inherited_permissions: boolean
  atmosphere:
    light_profile:
    sound_profile:
    weather_profile:
  object_ids: [uuid]
  ritual_ids: [uuid]
  memory_ids: [uuid]
  epoch_ids: [uuid]
  user_meaning: string | null
  lifecycle_state: forming | lived | resting | preserved | archived
  snapshots: [uuid]
  accessibility:
    list_navigation: true
    reduced_motion_route: true
    literal_label: string
```

## Invariants

- all Alpha places are private;
- visual enclosure does not alter permissions;
- no automatic lifecycle transition;
- no attachment score;
- no empty-slot prompts;
- exact history remains recoverable;
- AI layout changes require confirmation.
