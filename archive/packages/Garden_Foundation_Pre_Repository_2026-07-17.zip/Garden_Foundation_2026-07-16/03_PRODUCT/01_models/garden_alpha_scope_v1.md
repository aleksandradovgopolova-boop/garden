# Garden Alpha Scope v1

Build: one private Garden, Places, Atmosphere, fixed Objects, Rituals without streaks, direct navigation, AI Preview/Apply/Undo, Snapshots, Versions, export and deletion.

Do not build: collaboration, feed, public profile, economy, marketplace, semantic graph, autonomous AI or emotional diagnosis.
