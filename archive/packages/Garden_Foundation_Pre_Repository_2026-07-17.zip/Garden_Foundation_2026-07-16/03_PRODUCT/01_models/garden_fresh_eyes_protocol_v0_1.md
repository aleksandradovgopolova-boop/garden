# Garden Fresh Eyes Protocol

**Версия:** 0.1  
**Статус:** product protocol draft

## Trigger

Use when the person says:

- «Я уже знаю, что не получится».
- «Так не делают».
- «Я не такой человек».
- «Слишком поздно».
- «Сначала нужно разобраться во всём».
- «Все препятствия очевидны».
- «Прошлый раз доказывает, что бесполезно».

Do not trigger automatically from hidden profiling.

## Conversation

### 1. Permission

> «Хочешь на несколько минут посмотреть на задачу без старых выводов, сохранив факты и реальные риски?»

### 2. Table

| Statement | Type | Keep / Question / Verify |
|---|---|---|
| What is physically or legally true? | Hard fact | Keep |
| What is based on past experience? | Evidence | Use carefully |
| What is “how people do it”? | Convention | Question |
| What predicts rejection/failure? | Prediction | Verify |
| What describes “who I am”? | Identity story | Suspend |
| What is not yet known? | Unknown | Investigate |

### 3. Naive questions

Generate no more than three.

### 4. Expertise gate

> «Есть ли здесь область, где ошибка может дорого стоить и нужен специалист?»

### 5. Affordable probe

Define:

- smallest version;
- time;
- money;
- emotional cost;
- privacy;
- reversibility;
- stop signal.

### 6. Learning

> «Какой результат даст новую информацию, даже если идея не сработает?»

### 7. Closure

- try;
- learn first;
- ask expert;
- stop;
- decide not to pursue.

## Example

User:

> «Я не умею писать песни, потому что не знаю теорию музыки».

Garden:

```yaml
known:
  - user does not yet speak musical terminology confidently
assumed:
  - theory must precede lyric or melody creation
unknown:
  - whether a guided low-stakes draft is enjoyable or useful
expertise_needed:
  - none for a private first sketch
probe:
  - create one verse and chorus with a reference track
affordable_loss:
  - 30 minutes
learning:
  - which part feels alive and which knowledge gap actually blocks progress
```

Garden does not say the user will become a songwriter or that theory is irrelevant.

## Anti-patterns

- forced optimism;
- «everything is possible»;
- ignoring constraints;
- treating expertise as fear;
- running an experiment on another person without consent;
- repeatedly reframing a clear no;
- using Fresh Eyes to preserve an unwanted goal;
- turning curiosity into another daily practice.
