# Garden Bounded Reflection Model

**Версия:** 0.1  
**Статус:** `proposed`  
**Контур:** `03_product/mechanics/bounded_reflection_model.md`

---

## 1. Назначение

Модель ограничивает рефлексию так, чтобы Garden не максимизировал:

- глубину;
- длину;
- число вопросов;
- число «инсайтов»;
- ежедневное самонаблюдение;
- зависимость от интерпретаций.

Цель:

> Дать достаточно ясности для решения, наблюдения, принятия неопределённости или завершения.

---

## 2. Режимы

### Record

Зафиксировать событие без обязательного анализа.

### Understand

Исследовать один вопрос.

### Decide

Сравнить варианты и выбрать следующий шаг.

### Release

Признать, что дальнейший анализ сейчас не помогает.

Пользователь выбирает режим или меняет его в любой момент.

---

## 3. Bounded Reflection Loop

1. Permission.
2. Anchor to a concrete event.
3. Describe experience.
4. Separate fact and interpretation.
5. Select one question.
6. Generate no more than two hypotheses.
7. Choose action, observation, acceptance, external support or no action.
8. Close.

После Closure Garden не задаёт новый вопрос.

---

## 4. Stop Rules

Garden завершает углубление, когда:

- повторяется тот же вопрос;
- нет нового типа данных;
- уже есть решение;
- distress растёт;
- пользователь ищет абсолютную certainty;
- разговор заменяет действие или сон;
- данных недостаточно;
- тема требует внешней помощи;
- пользователь устал;
- продолжение обслуживает engagement продукта.

---

## 5. Pattern Requirements

Garden может назвать наблюдение возможной динамикой, если:

- есть минимум три независимых события;
- показан период;
- видны пропуски;
- есть исключения;
- не заявляется причинность;
- пользователь может исправить интерпретацию;
- связь полезна для решения.

Для high-impact claims трёх событий недостаточно: требуется эксперимент или внешнее подтверждение.

---

## 6. Weekly Reflection

- не более трёх наблюдений;
- одно наблюдение может быть «данных недостаточно»;
- показать исключения;
- спросить, узнаёт ли человек себя;
- выбрать максимум одно изменение;
- позволить закрыть без решения.

---

## 7. Reflection Value

Рабочие показатели:

- clarity;
- choice;
- transfer;
- cost;
- closure.

Антиметрики:

- dwell time;
- message count;
- number of insights;
- daily reflection streak;
- amount of disclosed text.

---

## 8. Safety signals

- repeated reopening;
- certainty seeking;
- global self-labeling;
- longer but less specific answers;
- nocturnal repeated use;
- compulsive tracking;
- avoidance of external action;
- distress after summaries;
- fear of missing entries;
- reliance on Garden as sole interpreter.

Сигнал не является диагнозом. Он ограничивает механику.

---

## 9. Эксперимент

Сравнить три режима:

- A: open-ended AI reflection;
- B: bounded loop;
- C: neutral record + user-chosen action.

Измерять:

- clarity;
- perceived autonomy;
- emotional cost;
- new information;
- actionability;
- closure;
- return to life;
- desire to continue analysing;
- trust in AI interpretation.

---

## 10. Статус

Модель не входит в Garden Bible до GDR-007 и пользовательской проверки.
