# Garden Authoring Architecture v1

**Статус:** `implementation proposal`

```yaml
garden_authoring:
  garden_id: uuid
  mode: view | edit
  ai_intensity: off | on_request | assistive | collaborative
  current_draft_id: uuid | null
  active_proposal_id: uuid | null
  undo_stack: [uuid]
  version_ids: [uuid]
  recovery_policy:
    trash_retention:
    auto_snapshot_before_bulk_change: true
```

```yaml
ai_proposal:
  proposal_id: uuid
  garden_id: uuid
  user_intent_id: uuid
  assumptions: [string]
  scope: [uuid]
  changes: [change_id]
  alternatives: [proposal_id]
  preserved_entities: [uuid]
  removed_entities: [uuid]
  reversible: boolean
  status: generated | viewed | edited | accepted | partially_accepted | rejected | archived
  provenance:
    model:
    created_at:
```

## Invariants

- no proposal auto-applies;
- every destructive change has recovery information;
- rejected proposals do not reappear automatically;
- manual creation remains available;
- restoring a version creates a new current state;
- provenance is preserved.
