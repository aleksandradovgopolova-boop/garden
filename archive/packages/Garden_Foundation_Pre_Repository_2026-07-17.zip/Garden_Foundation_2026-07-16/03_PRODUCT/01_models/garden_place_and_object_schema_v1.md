# Garden Place and Object Schema v1

**Статус:** `implementation draft`

## Place

```yaml
place_id: uuid
garden_id: uuid
name: string | null
type: clearing | grove | pond_edge | quiet_corner | path_area | structure_area | custom
position:
  x: number
  y: number
boundary:
  width: number
  height: number
user_meaning: string | null
ritual_ids: [uuid]
object_ids: [uuid]
memory_ids: [uuid]
ambient:
  light: inherit | custom
  weather: inherit | custom
  soundscape: inherit | custom
visibility: visible | archived
created_at: datetime
updated_at: datetime
```

## Garden Object

```yaml
object_id: uuid
garden_id: uuid
place_id: uuid | null
type: plant | tree | stone | bench | lantern | water | bridge | path_detail | structure | decoration | relic | ambient_marker
appearance_id: string
position:
  x: number
  y: number
rotation: number
scale: number
z_index: integer
name: string | null
user_meaning: string | null
ritual_id: uuid | null
memory_id: uuid | null
state: active | resting | integrated | completed | released | archived
created_by: user | ai_suggestion
created_at: datetime
updated_at: datetime
```

## Rules

- AI suggestions require explicit confirmation.
- `user_meaning` is never inferred.
- Deleting an object does not delete a ritual by default.
- Deleting a ritual does not delete an object by default.
- Archive preserves user ownership.
- Destructive actions require undo or confirmation.
