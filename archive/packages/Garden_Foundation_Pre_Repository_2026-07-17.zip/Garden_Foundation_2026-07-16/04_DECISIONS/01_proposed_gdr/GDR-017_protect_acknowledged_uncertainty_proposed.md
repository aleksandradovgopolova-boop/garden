# GDR-017 — Garden protects acknowledged uncertainty, not blind ignorance

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Context

R-017 showed:

- prior knowledge can create fixation;
- expertise also provides deep representation and safety;
- curiosity benefits from bounded, visible gaps;
- intellectual humility is compatible with conviction and action;
- unrecognized ignorance can create overconfidence;
- small reversible probes can create knowledge under uncertainty;
- deliberate ignorance of project risk is often costly;
- Garden memory can become a personal Einstellung effect;
- AI can accelerate premature convergence.

## Options

### A. Pattern-driven personalization

Use past behavior and expert knowledge to recommend the most likely path.

Risk: identity lock-in and predictable solutions.

### B. Naive optimism

Encourage action before thinking about constraints.

Risk: anti-expertise, preventable harm and planning fallacy.

### C. Productive unknowing

Keep verified knowledge and safety boundaries, suspend soft assumptions and use bounded experiments.

## Proposed decision

Choose C.

Garden:

- distinguishes recognized and unrecognized ignorance;
- separates hard from soft constraints;
- includes Learn, Question, Explore and Decide modes;
- offers optional Fresh Eyes Mode;
- delays personal-history retrieval during divergence;
- prevents identity conclusions from blocking experiments;
- requires expertise gates for high-stakes domains;
- uses affordable loss and reversibility;
- asks what will be learned;
- closes exploration;
- never markets ignorance as superior to competence.

## Consequences

- implement Productive Unknowing Model;
- add Fresh Eyes Protocol;
- add constraint classification;
- update memory retrieval order;
- add AI fixation tests;
- include `Unknown` as valid outcome;
- train Garden language to admit uncertainty;
- prevent Fresh Eyes in unsafe contexts;
- incorporate R-017 into Alpha experimentation.

## Reconsider if

- hiding history causes repeated harm;
- users misread the mode as motivational optimism;
- Garden misclassifies hard constraints;
- Fresh Eyes increases reckless action;
- users feel their experience is being dismissed;
- expertise gate becomes excessive friction;
- divergent options worsen paralysis;
- generic brainstorming provides equal value.

## Status

`accepted` only after explicit owner decision.
