# GDR-051 — Garden is inhabitable, not simulated

The visual system creates a sense of place without a maintenance-heavy simulated world.
