# GDR-008 — Garden поддерживает выбранное обязательство, но не владеет им

**Дата:** 15 июля 2026  
**Статус:** `proposed`

## Контекст

R-008 показало, что accountability способна помогать действию, но цифровой продукт легко превращает её в adherence к себе.

Особый риск Garden:

- тёплый AI воспринимается как моральный свидетель;
- обещание сохраняется после изменения обстоятельств;
- engagement принимается за пользу;
- напоминания усиливаются после молчания;
- Garden начинает защищать прежнюю цель от текущего решения человека.

## Варианты

### A. AI accountability partner

Пользователь отчитывается перед Garden.

Риск: ложные отношения, вина, dependency и product-centered adherence.

### B. Никакой активной поддержки

Риск: продукт не помогает преодолеть intention–action gap.

### C. Chosen Support Contract

Человек выбирает форму поддержки, Garden выполняет её в прозрачных пределах и регулярно возвращает право пересмотра.

## Предлагаемое решение

Выбрать вариант C.

Принципы:

- обязательство принадлежит человеку;
- support opt-in;
- expectations process-oriented;
- no hard commitments;
- no punishment;
- no escalation after silence;
- current choice can override past choice;
- changed conditions are considered;
- engagement is not the outcome;
- Garden teaches self-nudging and environment design;
- support should become less necessary.

## Последствия

- создать Chosen Support Model;
- пересобрать reminders;
- добавить support contract в Practice;
- определить beneficial disengagement;
- убрать «ты обещала»;
- запретить financial/social stakes в ранней версии;
- добавить human-support handoff;
- измерять reactance, guilt и dependence.

## Что заставит пересмотреть

- контракт слишком сложен;
- пользователи не понимают настройки;
- no-support condition даёт равную пользу;
- support contract повышает planning burden;
- пользователи всё равно воспринимают AI как судью;
- снижение intervention after silence пропускает нужную помощь;
- human connection создаёт privacy и coercion risks.

## Статус решения

`accepted` только после явного утверждения владельца проекта.
