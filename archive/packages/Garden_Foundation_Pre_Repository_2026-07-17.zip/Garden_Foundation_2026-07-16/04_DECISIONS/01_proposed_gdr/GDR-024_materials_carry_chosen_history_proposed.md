# GDR-024 — Materials carry chosen history, never punishment

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden uses a materially legible stylised world.

Materials communicate through:

- light;
- texture;
- motion;
- sound;
- shape;
- contextual behavior.

## Boundaries

- no automatic decay after absence;
- no rust, cracks, dirt or fading as ritual feedback;
- patina and repair are user-chosen;
- material age is not lifecycle state;
- “natural” is not described as inherently ethical or therapeutic;
- no status economy based on rare materials in Alpha;
- reduced-detail and accessible modes remain aesthetically complete.

## Core formula

> Objects may remember chosen use. They never accuse the owner of neglect.
