# GDR-013 — Метафора сада является опциональной линзой, а не моделью человека

**Дата:** 15 июля 2026  
**Статус:** `proposed`

## Контекст

R-013 показало:

- metaphors can shape reasoning;
- effect depends on context;
- one metaphor can empower and disempower;
- garden language highlights care, process and environment;
- it can also impose growth, moralize nature and hide structural causes;
- immersive metaphor can become a disguised score;
- AI gardener framing can assign the system excessive authority.

## Варианты

### A. Fully immersive garden ontology

Every practice, state and person is represented through plant life.

Риск: distortion, infantilization, moral status, low accessibility.

### B. Brand-only metaphor

Garden remains only a name and visual identity.

Риск: loss of distinctive language and useful context framing.

### C. Layered optional metaphor

Literal core is always available. Brand atmosphere remains. Deeper mappings are explicit, user-controlled and reversible.

## Предлагаемое решение

Выбрать вариант C.

Garden:

- keeps its name and central slogan;
- provides full literal mode;
- does not represent the user as a plant;
- does not position AI as gardener of the person;
- does not use decay, weeds, pests or disease as feedback;
- does not equate bloom with success;
- does not require growth;
- preserves systemic explanations;
- labels Mycorrhiza as metaphor;
- stores AI-suggested metaphors only after confirmation;
- allows complete metaphor exit without function loss.

## Последствия

- implement Layered Metaphor Model;
- audit all interface copy and visuals;
- replace hidden plant-state scoring;
- create literal labels;
- test metaphors cross-culturally;
- add structural-context prompts;
- clarify AI Gardener role;
- red-team grief, abuse, disability and non-growth scenarios.

## Что заставит пересмотреть

- literal mode destroys product comprehension;
- user tests show metaphor causes material confusion;
- brand atmosphere alone creates unwanted evaluation;
- users cannot distinguish metaphor from claim;
- optional settings create excessive complexity;
- AI Gardener name produces relational dependence;
- cultural adaptation requires separate brand expressions.

## Статус

`accepted` только после явного решения владельца проекта.
