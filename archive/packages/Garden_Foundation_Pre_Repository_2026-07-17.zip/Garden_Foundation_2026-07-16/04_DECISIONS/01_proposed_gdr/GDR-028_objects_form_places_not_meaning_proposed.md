# GDR-028 — Objects help form places; they do not assign meaning

**Дата:** 17 июля 2026  
**Статус:** proposed

## Решение

Garden рассматривает места как основную единицу композиции мира.

Объекты:

- поддерживают пространственные отношения;
- дают контекстные возможности;
- могут оставаться декоративными;
- могут связываться с ритуалами и памятью;
- получают значение от пользователя.

## Требования

- нет универсальной символики;
- нет personality inference по layout;
- lifecycle объекта и ритуала разделены;
- не каждый объект интерактивен;
- landmarks ограничены и стабильны;
- есть доступное не-spatial editing;
- нет object economy в Alpha;
- AI suggestions требуют подтверждения.

> **Objects make places possible. People make places meaningful.**
