# GDR-046 — HTML prototype before full backend

Validate the vertical slice with a coded prototype first.
