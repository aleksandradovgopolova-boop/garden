# GDR-045 — Design system encodes ethics

Reversibility, privacy, silence and accessibility are component-level rules.
