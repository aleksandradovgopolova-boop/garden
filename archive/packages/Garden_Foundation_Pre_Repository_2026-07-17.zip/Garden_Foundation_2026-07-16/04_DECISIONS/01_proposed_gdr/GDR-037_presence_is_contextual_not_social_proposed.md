# GDR-037 PRESENCE IS CONTEXTUAL NOT SOCIAL

Presence is contextual, not social.
