# GDR-022 — Colour belongs to the world, not to a psychological score

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden uses colour for:

- atmosphere;
- materials;
- interaction;
- hierarchy;
- user expression.

Garden does not use colour to infer or judge:

- mood;
- wellbeing;
- discipline;
- success;
- failure;
- ritual value.

## Requirements

- no colour-only information;
- no green/good and red/bad lifecycle;
- palette families rather than personality palettes;
- light and dark worlds have equal status;
- high-contrast mode is aesthetically complete;
- preference is explicit, not demographic;
- archive is not automatically grey;
- no premium-only dignity.
