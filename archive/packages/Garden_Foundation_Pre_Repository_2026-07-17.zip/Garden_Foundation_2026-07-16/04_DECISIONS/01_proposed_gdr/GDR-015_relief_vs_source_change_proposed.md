# GDR-015 — Garden distinguishes relief from source-directed change

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Context

R-015 showed:

- wellbeing is shaped across personal, relational, organizational, material and structural levels;
- individual advice can drift away from recognized upstream causes;
- personal practices can still provide real relief and capacity;
- cause, control and responsibility are different;
- burnout is an occupational phenomenon, not simply an individual resilience deficit;
- digital products can reproduce inequity and become institutional avoidance tools.

## Options

### A. Personal practice product

Garden limits itself to what the individual can do.

Risk: victim blaming and lifestyle drift.

### B. Structural analysis product

Garden foregrounds systems and avoids individual actions.

Risk: helplessness, excessive scope and false expertise.

### C. Multilevel action model

Garden names levels, separates relief from resolution and helps choose right-sized actions without claiming structural authority.

## Proposed decision

Choose C.

Garden:

- maps L1–L5;
- distinguishes cause, control and responsibility;
- labels interventions;
- always separates immediate support from source change;
- runs power, resource and safety checks;
- includes relational, organizational, institutional, collective and exit actions;
- does not provide legal verdicts;
- does not become employer resilience surveillance;
- keeps no-tracking and external-resource paths;
- treats structural recognition as part of agency, not as a reason for passivity.

## Consequences

- implement Multilevel Action Model;
- add Problem Location Protocol;
- create Intervention Integrity Labels;
- red-team recurring coping loops;
- add current external-resource verification capability;
- block employer individual data;
- include organizational/system scenarios in Alpha tests;
- update Garden Language.

## Reconsider if

- level mapping overwhelms users;
- structural framing increases helplessness;
- AI frequently misclassifies problems;
- users prefer direct personal action without analysis;
- external resources cannot be safely maintained;
- Intervention Labels appear moralistic;
- model scope becomes indistinguishable from legal/social work advice.

## Status

`accepted` only after explicit owner decision.
