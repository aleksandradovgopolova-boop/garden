# GDR-034 — Garden memory is not a second brain

**Статус:** proposed

Garden memory supports places, rituals and lived experience without becoming a knowledge graph, notes system or external-memory architecture.

Requirements:

- no graph view;
- no arbitrary semantic linking;
- no automatic related memories;
- no importance ranking;
- no unsolicited resurfacing;
- no inferred emotional meaning;
- search-first retrieval;
- one primary place link in Alpha;
- later reflections do not overwrite originals;
- user-controlled hide, archive, export and delete;
- explicit boundary from «Нити».

> Garden holds what the person chooses to keep. It does not turn a life into a database.
