# GDR-030 — The world may vary; persistent evolution requires authorship

**Статус:** proposed

Garden allows autonomous ambient variation but forbids autonomous persistent evolution in Alpha.

Requirements:

- no autonomous growth;
- no decay;
- no absence effects;
- reversible presets;
- Manual and Frozen modes;
- persistent changes require confirmation;
- snapshots and variants;
- visible change log;
- migrations preserve authored worlds;
- AI cannot silently transform the world.

> The world may change around the user. It must not change the user’s world without them.
