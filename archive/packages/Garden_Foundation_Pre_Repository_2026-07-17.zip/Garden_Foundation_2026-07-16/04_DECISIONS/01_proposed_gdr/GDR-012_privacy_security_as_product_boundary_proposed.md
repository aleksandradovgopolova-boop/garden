# GDR-012 — Privacy and security are product boundaries, not compliance layers

**Дата:** 15 июля 2026  
**Статус:** `proposed`

## Контекст

Garden handles intimate free text, inferred memory and potentially health, relationship, belief, sexuality, violence and crisis information. AI and long-term memory increase usefulness and simultaneously increase surveillance, manipulation and breach risk.

A privacy notice cannot compensate for unnecessary collection, uncontrolled employee access, provider training, incomplete deletion or crisis promises the service cannot fulfil.

## Варианты

### A. Build full personalization first, add compliance before launch

Fast discovery, but creates data architecture and incentives that are costly to reverse.

### B. Store minimal records without AI memory

Lower risk but limits some proposed value.

### C. Privacy- and safety-bounded architecture

Functions launch only after need, data flow, access, deletion, provider and failure modes are proven.

## Предлагаемое решение

Choose C.

Garden adopts:

- privacy by default;
- 18+ Alpha;
- no clinical claims;
- no crisis-monitoring promise;
- no provider training on production content;
- no raw-content analytics;
- no default employee reading;
- no hidden psychological/persuasion profile;
- no passive mental-state inference;
- user-visible memory provenance and deletion;
- deterministic authorization outside the LLM;
- DPIA before real-data pilot;
- threat-model and red-team launch gates;
- the right to remove or postpone an unsafe feature.

## Consequences

- personalization will be narrower;
- some workflows require extra confirmation;
- local/on-device options require technical research;
- analytics will contain less behavioral detail;
- Alpha scope becomes smaller;
- security/privacy/safety owners are needed before pilot;
- vendor choice is constrained by retention and training contracts;
- a crisis-aware feature cannot ship from copy alone.

## What would trigger reconsideration

- independent review finds controls disproportionate or ineffective;
- local processing enables a materially safer architecture;
- clinical or child-focused product strategy is deliberately adopted with a new regulatory program;
- a provider cannot meet contractual controls and architecture changes;
- user research shows a control causes serious new safety harm.

## Status

`accepted` only after explicit owner decision and named accountable privacy/security reviewers.
