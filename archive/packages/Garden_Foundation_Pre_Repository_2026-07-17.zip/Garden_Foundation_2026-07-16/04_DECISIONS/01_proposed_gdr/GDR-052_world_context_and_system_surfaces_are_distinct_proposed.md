# GDR-052 — World, context and system surfaces are distinct

The interface shows whether the person is inhabiting, editing or operating system controls.
