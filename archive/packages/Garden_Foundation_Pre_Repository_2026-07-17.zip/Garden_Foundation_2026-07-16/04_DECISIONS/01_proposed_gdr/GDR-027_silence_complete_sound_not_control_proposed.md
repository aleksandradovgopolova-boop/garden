# GDR-027 — Silence is a complete Garden; sound creates presence, not emotional control

**Дата:** 17 июля 2026  
**Статус:** `proposed`

## Decision

Garden separates:

- ambience;
- music;
- interaction sounds;
- accessibility audio.

## Requirements

- Silent mode has full functionality;
- no essential meaning through sound alone;
- sound layers controlled independently;
- music off by default in review;
- no inferred mood soundtrack;
- no obvious short loops;
- no animal attention calls;
- safety mode disables decorative audio;
- accessibility speech has priority;
- no microphone analysis or environmental listening.

## Core formula

> Sound may make the world present. It must not decide how the person should feel.
