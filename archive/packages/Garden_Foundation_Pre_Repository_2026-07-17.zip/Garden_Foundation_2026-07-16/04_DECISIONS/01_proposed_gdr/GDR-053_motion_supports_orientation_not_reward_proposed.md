# GDR-053 — Motion supports orientation, not reward

Motion may show continuity but cannot celebrate compliance or create urgency.
