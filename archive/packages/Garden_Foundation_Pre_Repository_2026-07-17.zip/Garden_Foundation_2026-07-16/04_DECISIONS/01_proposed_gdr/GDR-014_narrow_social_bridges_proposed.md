# GDR-014 — Garden creates narrow social bridges, not a network around inner life

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Context

R-014 showed:

- support has multiple forms and must match need;
- dyadic interventions use distinct mechanisms;
- digital peer support has potential but mixed evidence and meaningful harms;
- social accountability can become surveillance;
- comparison preferences vary;
- co-rumination can increase closeness and distress simultaneously;
- moderation is operationally necessary;
- unequal relationships make formal consent insufficient.

## Options

### A. Social Garden

Profiles, friends, shared progress, feed and public/community layer.

Risk: surveillance, comparison, disclosure pressure and moderation burden.

### B. Fully solo Garden

Strong privacy, but no help transferring reflection into human relationships.

### C. Narrow social bridges

Prepare requests, one-time sharing and limited trusted-person roles. No feed or broad social graph.

## Proposed decision

Choose C.

Garden:

- does not require social participation;
- shares specific objects, not whole profiles;
- provides S1–S3 in Alpha;
- treats S4 shared practices as later tested function;
- excludes groups/community/feed from Alpha;
- has no leaderboards or public streaks;
- never discloses misses automatically;
- requires consent from both parties;
- supports safe exit;
- separates each person’s AI context;
- helps connection move into real life.

## Consequences

- implement Social Architecture Model;
- build consent/access matrix;
- test prepared offline request as baseline;
- build Trusted Person roles;
- no contact upload or friend graph;
- no community before moderation program;
- red-team coercive control and separation;
- measure helper burden and relationship friction.

## Reconsider if

- prepared offline requests provide no value;
- trusted-person role produces pressure;
- granular permissions are misunderstood;
- shared practice creates conflict;
- users need peer community for core value;
- safe moderation becomes operationally feasible;
- social functionality increases dependence on Garden rather than real relationships.

## Status

`accepted` only after explicit owner decision.
