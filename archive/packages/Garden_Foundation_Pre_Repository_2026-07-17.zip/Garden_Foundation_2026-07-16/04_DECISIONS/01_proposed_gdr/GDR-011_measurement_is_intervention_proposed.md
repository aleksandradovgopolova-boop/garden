# GDR-011 — Измерение Garden является вмешательством, а не нейтральным наблюдением

**Дата:** 15 июля 2026  
**Статус:** `proposed`

## Контекст

R-011 показало:

- repeated assessment может менять внимание и поведение;
- Personal Informatics не гарантирует insight или action;
- self-report meaning может изменяться со временем;
- validated scales зависят от construct, context, population and use;
- passive sensing не даёт объективной психологической истины;
- measure, превращённое в target, искажает поведение;
- общий score скрывает ценностные решения.

## Варианты

### A. Rich Quantified Garden

Собирать много данных, строить scores и персональные patterns.

Риск: surveillance, false certainty, burden, Goodhart effects and moralization.

### B. No measurement

Максимальная осторожность, но теряется память и возможность проверять гипотезы.

### C. Minimal Purpose-Bound Measurement

No-tracking является полноценным режимом. Измерение включается для конкретного вопроса, ограничивается по времени и не создаёт total score.

## Предлагаемое решение

Выбрать вариант C.

Garden:

- предлагает no-tracking mode;
- использует Measurement Contract;
- различает `not recorded`, `did not happen` и `intentionally skipped`;
- не создаёт общий Garden Score;
- не использует streaks и cross-user ranking;
- показывает missingness, exceptions and uncertainty;
- не наследует validation после изменения шкалы;
- не выводит psychological states из passive data в Alpha;
- предпочитает временные эксперименты постоянному мониторингу;
- позволяет продолжать практику после отключения measurement;
- оценивает burden and harm alongside value.

## Последствия

- внедрить Garden Measurement Model;
- создать Measurement Catalog;
- пересобрать dashboards;
- убрать moral color encoding;
- добавить no-tracking comparator в Alpha;
- отделить product telemetry от personal meaning;
- завести review gate для каждого derived metric;
- R-012 должен определить privacy/security architecture.

## Что заставит пересмотреть

- minimal record не даёт достаточной пользы;
- Measurement Contract создаёт слишком высокую нагрузку;
- пользователи не понимают missingness;
- временные эксперименты редко завершаются;
- отсутствие scores ухудшает понимание;
- passive sensor data демонстрируют проверенную пользу с приемлемым risk;
- no-tracking mode не позволяет выполнить ключевой use case.

## Статус решения

`accepted` только после явного утверждения владельца проекта.
