# GDR-032 — AI proposes; the user commits

**Дата:** 17 июля 2026  
**Статус:** `proposed`

## Decision

AI-generated changes remain proposals until explicitly accepted.

## Requirements

- clear View/Edit modes;
- complex changes begin as drafts;
- before/after preview;
- visible assumptions;
- partial acceptance;
- immediate undo;
- version history;
- trash and recovery;
- provenance;
- manual creation complete;
- AI intensity controlled by user;
- no autonomous apply.

## Core formula

> AI can help imagine the garden. Only the person decides what grows into reality.
