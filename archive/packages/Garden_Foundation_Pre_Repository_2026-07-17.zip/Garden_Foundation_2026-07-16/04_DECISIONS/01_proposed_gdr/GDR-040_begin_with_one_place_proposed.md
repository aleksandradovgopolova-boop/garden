# GDR-040 BEGIN WITH ONE PLACE

Onboarding begins with one place.
