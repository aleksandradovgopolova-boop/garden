# GDR-023 — Light creates space and atmosphere, not a state of the person

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden uses light for:

- depth;
- materials;
- atmosphere;
- time;
- focus;
- user expression.

It does not use light to infer or indicate:

- wellbeing;
- success;
- failure;
- neglect;
- crisis;
- productivity.

## Requirements

- separate world and UI lighting;
- optional real-time synchronization;
- complete night usability;
- reduced-motion and static-light modes;
- no circadian or therapeutic claims;
- no lifecycle mapped to brightness;
- user control of local lights;
- safety mode removes ambient transitions.
