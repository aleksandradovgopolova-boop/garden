# GDR-036 PRIVACY IS STARTING CONDITION

Privacy is the starting condition of Garden.
