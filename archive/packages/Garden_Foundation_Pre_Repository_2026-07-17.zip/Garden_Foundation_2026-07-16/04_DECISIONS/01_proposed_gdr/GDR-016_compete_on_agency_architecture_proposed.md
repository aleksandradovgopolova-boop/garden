# GDR-016 — Garden competes on agency architecture, not an AI-journal feature bundle

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Context

R-016 found a crowded and converging market:

- AI journals already offer prompts, voice, memory, patterns and habits;
- self-care apps combine routines, mood and content;
- meditation platforms add AI companions;
- mental-health AI offers long-term conversation;
- trackers offer correlations and experiments;
- PKM tools offer AI thought partners;
- general AI can imitate many isolated features.

## Options

### A. Better AI journal

Compete on prompt quality, insights, memory and voice.

Risk: crowded, copyable and contrary to epistemic boundaries.

### B. Broad wellbeing super-app

Combine journal, tracker, content, community and companion.

Risk: scope, generic positioning, regulatory and dependency risk.

### C. Agency-preserving practice system

Compete on a distinctive object model, constraints and real-world outcomes.

## Proposed decision

Choose C.

Garden:

- uses practice as core object;
- has bounded rather than endless reflection;
- restricts AI interpretation;
- governs memory;
- separates relief from source change;
- makes measurement optional;
- excludes streaks and public comparison;
- designs social features as narrow bridges;
- includes completion and product exit as success;
- launches with one-direction/one-practice wedge.

## Consequences

- category copy must not lead with AI journal;
- Alpha scope remains narrow;
- competitor roadmap is tracked quarterly;
- general AI is a required comparator;
- no content-library arms race;
- no companion persona;
- business model must not require dependence;
- privacy/safety become differentiating operations, not only messaging.

## Reconsider if

- users cannot understand the category;
- closest competitors adopt the full model;
- generic AI matches outcomes;
- users will not pay for bounded support;
- no-streak practice underperforms;
- off-product success makes business unsustainable;
- safety differentiation is not visible or trusted.

## Status

`accepted` only after explicit owner decision.
