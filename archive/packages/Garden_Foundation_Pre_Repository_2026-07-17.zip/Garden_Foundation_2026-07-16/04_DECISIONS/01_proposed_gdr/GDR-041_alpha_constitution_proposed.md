# GDR-041 ALPHA CONSTITUTION

Alpha tests meaningful return without obligation.
