# GDR-021 — Garden learns from garden histories without becoming a cultural collage

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden may use spatial and interaction principles learned from historical garden traditions.

It must not combine identifiable cultural motifs as a generic “calm garden” aesthetic without documenting origin, meaning and transformation.

## Requirements

- Cultural Borrowing Protocol;
- Atlas provenance;
- fictional core world rather than direct replica;
- cultural review for identifiable motifs;
- user choice of aesthetics;
- no tradition described as universally calming, natural or humane.

## Core position

> Garden knows the history of gardens but does not pretend to be one of them.
