# GDR-042 — Two equal navigation systems

Spatial and direct navigation are equal.
