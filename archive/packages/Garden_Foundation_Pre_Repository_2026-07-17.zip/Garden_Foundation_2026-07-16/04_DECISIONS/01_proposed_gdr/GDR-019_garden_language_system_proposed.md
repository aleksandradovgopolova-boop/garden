# GDR-019 — Garden language preserves adult agency and world coherence

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden adopts a formal language system.

User-facing language:

- uses Ritual, Garden, Place, Review, Rest, Complete and Release;
- avoids task, streak, failure, achievement and optimization framing;
- marks AI uncertainty;
- never creates emotional debt;
- always offers literal equivalents for metaphor;
- ends conversations when sufficient clarity appears.

## Consequences

- all UX copy must pass Language QA;
- AI prompts must encode epistemic labels;
- notifications require separate review;
- safety mode disables metaphor;
- product analytics names remain internal;
- “AI coach”, “AI friend” and “AI therapist” are prohibited positioning.
