# GDR-043 — Preview is a separate state

Preview cannot mutate committed Garden state.
