# GDR-054 — Visual accessibility has equal status

Structured non-spatial interaction, reduced motion and keyboard access are first-class modes.
