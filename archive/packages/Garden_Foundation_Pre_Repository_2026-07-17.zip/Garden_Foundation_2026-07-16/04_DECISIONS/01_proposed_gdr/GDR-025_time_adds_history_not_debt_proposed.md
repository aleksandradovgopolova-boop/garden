# GDR-025 — Time adds history, never debt

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden may use:

- calendar dates;
- ambient time;
- user-selected seasons;
- world cycles;
- personal epochs.

It must not use time to create:

- decay;
- streak loss;
- backlog;
- guilt;
- forced urgency;
- limited-time status;
- automatic ritual failure.

## Requirements

- optional time modes;
- exact dates recoverable;
- user-created epochs;
- no AI-generated life chapter without confirmation;
- freeze time;
- no lifecycle transition from inactivity;
- no seasonal FOMO;
- unchanged return after absence.

## Core formula

> Time in Garden adds history, never debt.
