# GDR-048 — Non-spatial representation is equal

Every spatial Place has a structured, keyboard- and screen-reader-accessible representation with equal functional status.
