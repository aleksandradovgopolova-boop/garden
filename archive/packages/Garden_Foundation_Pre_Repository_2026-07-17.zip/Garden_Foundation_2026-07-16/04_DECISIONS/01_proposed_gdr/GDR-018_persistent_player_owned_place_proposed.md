# GDR-018 — Garden is a persistent player-owned place, not a decorated dashboard

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision

Garden should be designed as a persistent personal place.

It must provide:

- stable spatial continuity;
- meaningful empty space;
- user naming and customization;
- persistent reversible traces;
- user-controlled history;
- safe absence;
- safe departure.

## It must not

- auto-decorate the user’s identity;
- infer psychology from layout;
- use decay to force return;
- make ambient animals dependent;
- make weather a mood score;
- use artificial scarcity or FOMO;
- destroy value after cancellation or absence.

## Open decision

The product must test whether the dominant creation model is:

- ritual-first;
- place-first;
- hybrid.

## Alpha consequence

Add a place-first prototype and measure ownership separately from task completion.
