# GDR-038 GARDEN WITNESSES BUT DOES NOT DIAGNOSE

Garden witnesses expression but does not diagnose.
