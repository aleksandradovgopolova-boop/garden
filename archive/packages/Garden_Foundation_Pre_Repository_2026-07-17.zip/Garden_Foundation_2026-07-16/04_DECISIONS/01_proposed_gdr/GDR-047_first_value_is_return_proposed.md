# GDR-047 — First value is return

The first value moment is not finishing setup. It is leaving and returning to a preserved place.
