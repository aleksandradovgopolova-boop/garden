# GDR-031 — Movement is optional; access is direct

**Дата:** 17 июля 2026  
**Статус:** `proposed`

## Decision

Garden supports equal spatial and direct navigation.

## Requirements

- every destination has direct access;
- search is primary;
- no forced walking;
- no travel time;
- no fog of war;
- no completion map;
- user-controlled entry point;
- neutral return after absence;
- clear mode and privacy context;
- list/tree accessibility;
- reduced motion;
- one-place usage is complete.

## Core formula

> You may wander. You may also arrive directly. Both are Garden.
