# GDR-010 — AI Gardener предлагает версии, но не владеет интерпретацией

**Дата:** 15 июля 2026  
**Статус:** `proposed`

## Контекст

R-010 показало:

- люди часто следуют AI-совету даже без доказанной долгосрочной пользы;
- LLMs склонны к social sycophancy;
- персонализация и позитивный persuasive language повышают доверие;
- relational affordances способны создавать emotional dependence;
- long-term memory усиливает cross-domain leakage и sycophancy;
- связный AI-нарратив может стать ложной идентичностью.

## Варианты

### A. AI Insight Engine

Garden самостоятельно выявляет скрытые паттерны и сообщает выводы.

Риск: overtrust, identity fixation, sycophancy и ложная причинность.

### B. Только хранение без интерпретации

Безопаснее, но теряется значительная часть ценности AI.

### C. Bounded Co-Interpretation

Garden показывает данные, предлагает ограниченные версии, ищет альтернативы, принимает исправление и возвращает право значения человеку.

## Предлагаемое решение

Выбрать вариант C.

AI Gardener:

- не является главным толкователем;
- не производит identity or diagnosis claims;
- маркирует epistemic level;
- предлагает максимум две гипотезы;
- включает alternative and disconfirming evidence;
- не сохраняет AI hypothesis как fact;
- принимает correction без спора;
- не использует memory для persuasion;
- не создаёт relational debt;
- предлагает human bridge;
- умеет завершать и забывать.

## Последствия

- внедрить AI Interpretation Protocol;
- создать Memory Governance Model;
- добавить epistemic UI;
- создать correction/deletion flow;
- запретить AI-generated psychological profile;
- отделить support from endorsement;
- измерять overtrust, sycophancy and dependence;
- ограничить anthropomorphic copy;
- high-stakes recommendation требует external verification.

## Что заставит пересмотреть

- пользователи не понимают epistemic markers;
- альтернативы увеличивают тревогу;
- protocol делает Garden бесполезно осторожным;
- correction flow редко используется;
- bounded hypotheses всё равно становятся identity labels;
- memory controls слишком сложны;
- neutral non-interpretive mode даёт равную пользу с меньшим риском;
- human bridge недоступен или вызывает давление.

## Статус решения

`accepted` только после явного утверждения владельца проекта.
