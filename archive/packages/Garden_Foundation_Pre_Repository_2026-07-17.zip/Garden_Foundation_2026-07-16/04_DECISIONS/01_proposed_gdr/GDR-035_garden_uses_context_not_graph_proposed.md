# GDR-035 — Garden uses context, not a knowledge graph

**Дата:** 17 июля 2026  
**Статус:** `proposed`

## Decision

Garden uses a small enumerated set of functional relations and does not develop a semantic graph.

## Requirements

- no graph view;
- no backlinks;
- no arbitrary relation types;
- no semantic clusters;
- no automatic related content;
- no inferred themes;
- spatial composition as primary organizing model;
- user meaning remains text;
- Garden and «Нити» keep separate schemas;
- any future transfer is explicit and user-controlled.

## Core formula

> Garden holds things in context. «Нити» may connect ideas. They are not the same work.
