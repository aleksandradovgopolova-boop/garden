# GDR-029 — Garden creates conditions for place, not attachment

**Дата:** 17 июля 2026  
**Статус:** `proposed`

## Decision

Place is the primary spatial unit of Garden.

Garden supports:

- boundaries;
- centers;
- paths;
- views;
- spatial qualities;
- atmosphere;
- use;
- history;
- optional naming.

## Requirements

- attachment is not measured or optimized;
- all Alpha places are private;
- no universal prospect/refuge prescription;
- no identity inference from layouts;
- emptiness is allowed;
- direct accessible navigation;
- visual privacy separated from permissions;
- templates contain no personality or wellbeing claims;
- lifecycle and changes remain user-controlled.

## Core formula

> Garden creates conditions for place. The person creates belonging.
