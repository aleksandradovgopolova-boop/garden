# GDR-020 — Garden uses designed incompleteness rather than finished perfection

**Дата:** 16 июля 2026  
**Статус:** `proposed`

## Decision candidate

The initial garden should be:

- visually coherent;
- cared for;
- incomplete enough to invite authorship;
- free of implied missing progress.

The product should not present a fully decorated canonical garden as the ideal.

## Alpha test

Compare polished pre-decoration with designed incompleteness. Measure beauty, ownership, fear of changing, desire to create, cultural fit, accessibility and perceived judgment.
