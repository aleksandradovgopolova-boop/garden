# GDR-049 — Analytics excludes private content

Raw memories, rituals, emotional text and AI prompts are not collected in product analytics by default.
