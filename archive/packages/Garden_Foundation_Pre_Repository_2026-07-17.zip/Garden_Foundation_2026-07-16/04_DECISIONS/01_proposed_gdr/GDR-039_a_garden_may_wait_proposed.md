# GDR-039 A GARDEN MAY WAIT

A Garden may wait; no retention pressure.
