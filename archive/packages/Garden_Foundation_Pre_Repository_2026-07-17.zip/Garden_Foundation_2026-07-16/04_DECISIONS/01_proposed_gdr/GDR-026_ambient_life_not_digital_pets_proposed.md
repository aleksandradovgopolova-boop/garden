# GDR-026 — Garden contains independent ambient life, not dependent digital pets

**Дата:** 17 июля 2026  
**Статус:** proposed

## Decision

Alpha uses ambient wildlife only.

Living beings:

- do not need care;
- do not suffer;
- do not respond to absence;
- do not speak for AI;
- are not collectible;
- do not create rarity or status;
- can be disabled;
- may appear and leave independently.

## Deferred

- cats and dogs;
- named companions;
- persistent individual animals;
- feeding;
- following;
- petting;
- breeding;
- loss;
- animal memory;
- educational catalogue.

> **Life exists in the garden without becoming another responsibility.**
