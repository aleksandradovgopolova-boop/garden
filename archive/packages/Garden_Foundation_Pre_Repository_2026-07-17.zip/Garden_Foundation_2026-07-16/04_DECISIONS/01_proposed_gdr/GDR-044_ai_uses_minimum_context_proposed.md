# GDR-044 — AI uses minimum context

Full-Garden context is prohibited by default.
