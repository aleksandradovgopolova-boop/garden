# GDR-033 — Rituals are recognized, not enforced

**Дата:** 17 июля 2026  
**Статус:** `proposed`

## Decision

Garden supports meaningful practices without streak, failure states or required logging.

## Requirements

- distinguish task, habit, routine and ritual;
- no streak;
- no failed occurrence;
- completion optional;
- logging optional;
- no quality score;
- no frequency morality;
- lineage;
- retrospective creation;
- lifecycle controlled by user;
- ending is legitimate;
- AI pattern detection opt-in;
- no ritual inferred or created without confirmation.

## Core formula

> A ritual is not something Garden makes the person obey. It is something the person may choose to recognize as their own.
