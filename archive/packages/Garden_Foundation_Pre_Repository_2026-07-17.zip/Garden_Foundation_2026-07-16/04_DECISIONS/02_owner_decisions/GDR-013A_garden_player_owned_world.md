# GDR-013A — The garden is the core player-owned world, not a score

**Дата:** 16 июля 2026  
**Статус:** `accepted`  
**Supersedes:** GDR-013 proposed framing

## Decision

Garden keeps the garden metaphor as a central visual, emotional and gameplay world.

The garden is not merely optional decoration. It is part of why the product exists and why a person may want to return.

At the same time:

- the user owns the garden;
- the garden does not diagnose;
- the garden does not judge;
- the garden does not decay after absence;
- bloom does not equal wellbeing;
- empty space is valid;
- literal accessibility labels remain available;
- the user can customize the level of metaphor without losing ownership.

## Game logic

Garden may borrow from cozy farming and sandbox games:

- building;
- collecting;
- arranging;
- discovering;
- decorating;
- transforming;
- remembering.

Garden must not borrow:

- crop loss for absence;
- countdown pressure;
- energy scarcity engineered for purchases;
- guilt loops;
- forced daily return;
- social ranking;
- pay-to-protect mechanics.

## Core formula

> **The person does not serve the garden. The garden serves the person.**
