# GDR-006A — Ritual is the user-facing core; Practice is the internal parent model

**Дата:** 16 июля 2026  
**Статус:** `accepted`  
**Supersedes user-language portion of:** GDR-006

## Decision

- `Ritual` is the canonical user-facing entity.
- `Practice` may remain the internal technical parent type.
- Not every ritual must repeat or become a habit.
- A ritual may rest, transform, complete or be released.
- No ritual has a failed state.
- The slogan «Маленькие ритуалы. Большой сад» remains canonical.

## Why

`Practice` is precise for architecture but emotionally generic.

`Ritual` communicates that an action:

- has personal meaning;
- belongs to the person;
- is more than a task;
- can create atmosphere and identity without becoming a fixed identity judgment.

## Guardrails

Ritual must not mean:

- compulsory repetition;
- magical efficacy;
- moral superiority;
- clinical intervention;
- obedience to Garden.
